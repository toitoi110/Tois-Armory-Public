tag @s add toisarm.exhaustion_applied
scoreboard players operation @s[scores={toisarm.exhaustion=1..}] toisarm.exhaustion_remaining = @s toisarm.exhaustion
execute store result score @s toisarm.foodsat_remove_queue store result score @s toisarm.prev_food store result score @s toisarm.exhaustion run data get entity @s foodLevel
execute store result score @s _ run data get entity @s foodSaturationLevel
scoreboard players operation @s toisarm.foodsat_remove_queue -= @s _
scoreboard players operation @s toisarm.exhaustion += @s _
scoreboard players remove @s toisarm.exhaustion 6
item replace entity @s[scores={toisarm.exhaustion=1..}] saddle with saddle[enchantments={vanishing_curse:1,binding_curse:1,"toisarm:apply_exhaustion":1},equippable={slot:"saddle",equip_sound:"intentionally_empty",dispensable:false,swappable:false,damage_on_hurt:false}]
