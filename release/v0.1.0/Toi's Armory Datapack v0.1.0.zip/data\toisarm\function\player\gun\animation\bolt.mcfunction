    item modify entity @s weapon toisarm:gun/set_custom_model_data/3
    execute if score @s toisarm.timer.bolt_move_anim matches 0.. unless entity @s[scores={toisarm.state.bolt_hold_open=1,toisarm.chamber=0}] unless entity @s[scores={toisarm.state.bolt_hold_open=1,toisarm.ammo_remaining=0,toisarm.chamber=-1}] run scoreboard players remove @s toisarm.timer.bolt_move_anim 1
    tag @s remove toisarm.update_bolt_move_anim
