tag @s remove toisarm.exhaustion_applied
scoreboard players operation @s toisarm.prev_food -= @s toisarm.exhaustion
execute store result storage toisarm:temp macro.level float 1 run scoreboard players remove @s toisarm.prev_food 7
function toisarm:player/food_control/apply_saturation_macro with storage toisarm:temp macro
scoreboard players add @s toisarm.prev_food 1
scoreboard players operation @s toisarm.prev_food *= 2 num
scoreboard players operation @s toisarm.foodsat_remove_queue < @s toisarm.prev_food
scoreboard players operation @s[scores={toisarm.foodsat_remove_queue=..-1}] toisarm.foodsat_remove_queue = @s toisarm.exhaustion_remaining
scoreboard players operation @s toisarm.exhaustion = @s toisarm.foodsat_remove_queue
item modify entity @s[tag=!SUCCESS] saddle {"type":"minecraft:set_enchantments","enchantments":{"toisarm:apply_exhaustion":0}}
tag @s remove SUCCESS
tag @s add toisarm.remove_saturation_queue
