    tag @s remove toisarm.update_item_name
    data modify storage toisarm:temp update_name set value []
    data modify storage toisarm:temp update_name append from storage toisarm:temp this_player.data.gun.display_name
    data modify storage toisarm:temp update_name append value " < "
    data modify storage toisarm:temp update_name append from storage toisarm:temp this_player.mode_display
    data modify storage toisarm:temp update_name append value " | "
    execute if score @s toisarm.state.chamber matches 1 run data modify storage toisarm:temp update_name append value "a"
    execute if score @s toisarm.state.chamber matches 1 store result storage toisarm:temp update_name[-1] int 1 run scoreboard players get @s toisarm.chamber
    execute if score @s toisarm.state.chamber matches 1 run data modify storage toisarm:temp update_name append value " · "
    data modify storage toisarm:temp update_name append value "a"
    execute store result storage toisarm:temp update_name[-1] int 1 run scoreboard players get @s toisarm.ammo_remaining
    execute unless score @s toisarm.state.reload_loop matches 0.. if score @s toisarm.timer.reload matches 1.. run data modify storage toisarm:temp update_name append value "ᴿ"
    execute unless score @s toisarm.state.reload_loop matches 0.. unless score @s toisarm.timer.reload matches 1.. run data modify storage toisarm:temp update_name append value ""
    execute if score @s toisarm.state.reload_loop matches 0.. run function toisarm:player/gun/item_name/reload_loop
    data modify storage toisarm:temp update_name append value " / "
    data modify storage toisarm:temp update_name append from storage toisarm:temp this_player.data.gun.state.ammo_capacity
    data modify storage toisarm:temp update_name append value " >"
    execute if score @s toisarm.state.chamber matches 1 run item modify entity @s weapon toisarm:gun/update_name/closed_bolt
    execute if score @s toisarm.state.chamber matches ..0 run item modify entity @s weapon toisarm:gun/update_name/no_chamber
    execute if entity @s[scores={toisarm.state.chamber=-1,toisarm.chamber=0}] run item modify entity @s weapon toisarm:gun/update_name/open_bolt
    data remove storage toisarm:temp update_name
