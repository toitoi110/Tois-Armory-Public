scoreboard players operation #id _ = @s toisarm.bullet.owner
tag @p[predicate=toisarm:match_id] remove HIT
execute as @e[tag=HIT] run function toisarm:bullet/check_already_hit with entity @s
execute if entity @n[tag=HIT] run tag @p[predicate=toisarm:match_id] add toisarm.hit_own_bullet
$execute as @e[tag=HIT,tag=CRIT_HIT] run damage @s $(crit_damage) toisarm:bullet by @p[predicate=toisarm:match_id]
$execute as @e[tag=HIT,tag=!CRIT_HIT] run damage @s $(damage) toisarm:bullet by @p[predicate=toisarm:match_id]
tag @e remove HIT
tag @a remove HIT
tag @e remove CRIT_HIT
tag @a remove CRIT_HIT
