    scoreboard players remove @s toisarm.timer.reload_loop 1
    execute if score @s toisarm.timer.reload_loop = @s toisarm.state.reload_loop_success run function toisarm:player/gun/reload/add_ammo with storage toisarm:temp this_player.data.gun.state
    execute if score @s toisarm.timer.reload_loop matches 0 unless score @s toisarm.state.ammo_capacity = @s toisarm.ammo_remaining if score @s toisarm.timer.empty_reload matches 0.. run return run scoreboard players operation @s toisarm.timer.reload = @s toisarm.state.empty_reload_loop_start
    execute if score @s toisarm.timer.reload_loop matches 0 unless score @s toisarm.state.ammo_capacity = @s toisarm.ammo_remaining run scoreboard players operation @s toisarm.timer.reload = @s toisarm.state.reload_loop_start
