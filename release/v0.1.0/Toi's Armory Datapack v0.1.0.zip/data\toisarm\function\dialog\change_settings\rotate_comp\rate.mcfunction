execute if score @s toisarm.settings.rotate_comp.rate matches 200.. run return run scoreboard players set @s toisarm.settings.rotate_comp.rate 5
execute if score @s toisarm.settings.rotate_comp.rate matches ..95 run return run scoreboard players add @s toisarm.settings.rotate_comp.rate 5
scoreboard players add @s toisarm.settings.rotate_comp.rate 10
scoreboard players add @s toisarm.settings.rotate_comp.rate 5
