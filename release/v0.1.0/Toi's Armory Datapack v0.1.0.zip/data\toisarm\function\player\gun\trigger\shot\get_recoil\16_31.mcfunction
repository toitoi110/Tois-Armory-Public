execute if score @s toisarm.recoil.pattern_index matches 16..23 run function toisarm:player/gun/trigger/shot/get_recoil/16_23
execute if score @s toisarm.recoil.pattern_index matches 24..31 run function toisarm:player/gun/trigger/shot/get_recoil/24_31
