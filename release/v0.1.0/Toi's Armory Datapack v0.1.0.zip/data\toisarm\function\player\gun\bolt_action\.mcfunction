    execute if score @s toisarm.state.chamber matches 1 run return run function toisarm:player/gun/bolt_action/closed_bolt/
    function toisarm:player/gun/bolt_action/open_bolt/
