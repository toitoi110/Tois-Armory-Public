execute if score @s toisarm.recoil.pattern_index matches 0..31 run function toisarm:player/gun/trigger/shot/get_recoil/0_31
execute if score @s toisarm.recoil.pattern_index matches 32..63 run function toisarm:player/gun/trigger/shot/get_recoil/32_63
