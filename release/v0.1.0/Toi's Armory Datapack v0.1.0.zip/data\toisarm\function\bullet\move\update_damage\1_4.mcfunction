execute if score @s toisarm.bullet.distance_damage_index matches 1..2 run return run function toisarm:bullet/move/update_damage/1_2
function toisarm:bullet/move/update_damage/3_4
