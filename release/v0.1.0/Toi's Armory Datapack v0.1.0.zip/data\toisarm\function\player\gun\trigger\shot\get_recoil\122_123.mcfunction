execute if score @s toisarm.recoil.pattern_index matches 122 run function toisarm:player/gun/trigger/shot/get_recoil/122
execute if score @s toisarm.recoil.pattern_index matches 123 run function toisarm:player/gun/trigger/shot/get_recoil/123
