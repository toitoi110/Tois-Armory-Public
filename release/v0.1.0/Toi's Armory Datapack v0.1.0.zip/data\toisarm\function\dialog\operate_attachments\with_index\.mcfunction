$data modify storage toisarm:dialog attachment_item_slot set from storage toisarm:temp this_player.dialog.attachment_item_slot[$(count)]
