execute if score @s toisarm.recoil.pattern_index matches 12 run function toisarm:player/gun/trigger/shot/get_recoil/12
execute if score @s toisarm.recoil.pattern_index matches 13 run function toisarm:player/gun/trigger/shot/get_recoil/13
