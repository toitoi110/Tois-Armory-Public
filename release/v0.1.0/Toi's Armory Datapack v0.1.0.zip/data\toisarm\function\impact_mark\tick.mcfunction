scoreboard players operation @s toisarm.impact_mark.r *= 9 num
scoreboard players operation @s toisarm.impact_mark.r /= 10 num
scoreboard players operation @s toisarm.impact_mark.g *= 9 num
scoreboard players operation @s toisarm.impact_mark.g /= 10 num
scoreboard players operation @s toisarm.impact_mark.b *= 9 num
scoreboard players operation @s toisarm.impact_mark.b /= 10 num
scoreboard players operation @s toisarm.impact_mark.color = @s toisarm.impact_mark.r
scoreboard players operation @s toisarm.impact_mark.color *= 65536 num
scoreboard players operation @s _ = @s toisarm.impact_mark.g
scoreboard players operation @s _ *= 256 num
scoreboard players operation @s toisarm.impact_mark.color += @s _
scoreboard players operation @s toisarm.impact_mark.color += @s toisarm.impact_mark.b
scoreboard players add @s toisarm.impact_mark.age 1
execute if score @s toisarm.impact_mark.age matches 100.. run function toisarm:impact_mark/fading
scoreboard players operation @s _ = @s toisarm.impact_mark.alpha
scoreboard players operation @s _ *= 16777216 num
execute store result entity @s background int 1 run scoreboard players operation @s _ += @s toisarm.impact_mark.color
