execute if score @s toisarm.recoil.pattern_index matches 16 run function toisarm:player/gun/trigger/shot/get_recoil/16
execute if score @s toisarm.recoil.pattern_index matches 17 run function toisarm:player/gun/trigger/shot/get_recoil/17
