    execute store result storage toisarm:temp ammo_remaining int 1 run scoreboard players operation @s toisarm.ammo_remaining = @s toisarm.state.ammo_capacity
    item modify entity @s weapon.mainhand toisarm:gun/apply_ammo_remaining
    scoreboard players set @s toisarm.shootable 1
    tag @s add toisarm.update_item_name
