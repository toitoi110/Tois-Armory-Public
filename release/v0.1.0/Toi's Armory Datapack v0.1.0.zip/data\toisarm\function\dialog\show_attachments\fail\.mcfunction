tellraw @s {"translate":"message.toisarm.no_compatible_attachment","color":"red","fallback":"You don't have a compatible attachment!"}
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 1 0
scoreboard players set @s toisarm.trigger.input 1
