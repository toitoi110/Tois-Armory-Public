data modify storage toisarm:import gun append value \
{\
    "id": "mp5",\
    "display_name":"MP5",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"BURST","value":3},{"display":"SEMI","value":2}],\
        "ammo_type": "9x19mm",\
        "ammo_capacity": 30,\
        "ammo_count": 30,\
        "chamber": 1,\
        "round_per_minute": 800,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.9x19mm",\
        "trail_id": "trail.default_gunpack.small",\
        "bullet_velocity": 18,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.004,\
        "damage_by_distance": [\
            {"distance":10,"damage":3.2,"crit_damage":4.2},\
            {"distance":22,"damage":2.7,"crit_damage":3.5},\
            {"distance":40,"damage":2.4,"crit_damage":3.1},\
            {"distance":65,"damage":1.8,"crit_damage":2.35},\
        ],\
        "max_range": 90,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.15,0.75],\
        "trail_offset": [-0.12,-0.225,0.75],\
        \
        "reload_time": 61,\
        "empty_reload_time": 61,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 14,\
        "swap_time": 14,\
        "ads_time": 6,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 5,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 2,\
        "bolt_hold_open": 0,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 80,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.38,\
        "bloom_max": 90,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.75,\
        "sway_yaw": 1.3,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.04,\
        "shake_pitch": -0.15,\
        "shake_yaw_random": 0.2,\
        "shake_pitch_random": 0.02,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.02, "pitch": -0.55},\
            {"yaw": 0.03, "pitch": -0.58},\
            {"yaw": 0.01, "pitch": -0.52},\
            {"yaw": -0.02, "pitch": -0.55},\
            {"yaw": -0.04, "pitch": -0.58},\
            {"yaw": -0.05, "pitch": -0.55},\
            {"yaw": -0.03, "pitch": -0.52},\
            {"yaw": 0.00, "pitch": -0.55},\
            {"yaw": 0.04, "pitch": -0.58},\
            {"yaw": 0.07, "pitch": -0.55},\
            {"yaw": 0.09, "pitch": -0.52},\
            {"yaw": 0.10, "pitch": -0.55},\
            {"yaw": 0.08, "pitch": -0.57},\
            {"yaw": 0.05, "pitch": -0.55},\
            {"yaw": 0.02, "pitch": -0.52},\
            {"yaw": -0.01, "pitch": -0.55},\
            {"yaw": -0.03, "pitch": -0.57},\
            {"yaw": -0.04, "pitch": -0.55},\
            {"yaw": -0.03, "pitch": -0.55},\
            {"yaw": -0.01, "pitch": -0.56},\
            {"yaw": 0.01, "pitch": -0.58},\
            {"yaw": 0.02, "pitch": -0.55},\
            {"yaw": 0.01, "pitch": -0.52},\
            {"yaw": -0.01, "pitch": -0.55},\
            {"yaw": -0.02, "pitch": -0.57},\
            {"yaw": -0.01, "pitch": -0.50},\
            {"yaw": 0.01, "pitch": -0.52},\
            {"yaw": 0.02, "pitch": -0.55},\
            {"yaw": 0.00, "pitch": -0.53, "repeat": {} }\
        ],\
        "yaw_recoil_multiplier": 5.05,\
        "pitch_recoil_multiplier":1.85,\
        "recoil_apply_tick": 2,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/mp5/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/mp5/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/mp5/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/mp5/reload",\
            "duration": 209,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 33},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 2 0", "time": 87},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 123},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.9 0", "time": 182},\
                {"command": "playsound minecraft:block.iron_door.close master @a ~ ~ ~ 0.15 2 0", "time": 182},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.15 0", "time": 207},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/mp5/empty_reload",\
            "duration": 186,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0","time": 12},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.5 0", "time": 55},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.8 0", "time": 118},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.9 0", "time": 150},\
                {"command": "playsound minecraft:block.iron_door.close master @a ~ ~ ~ 0.15 2 0", "time": 150},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.15 0","time": 183},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 183},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/mp5/bolt_action",\
            "duration": 49,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.9 0", "time": 23},\
                {"command": "playsound minecraft:block.iron_door.close master @a ~ ~ ~ 0.15 2 0", "time": 23},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 23},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/mp5/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/mp5/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.25 1.9 0","time": 49},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 49},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/mp5/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/mp5/sprint",\
            "duration": 34,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"muzzle", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}