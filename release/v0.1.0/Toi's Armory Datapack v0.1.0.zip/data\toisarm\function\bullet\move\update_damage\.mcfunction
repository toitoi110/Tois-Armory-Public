execute if score @s toisarm.bullet.distance_damage_max_index <= @s toisarm.bullet.distance_damage_index run return 0
scoreboard players add @s toisarm.bullet.distance_damage_index 1
execute if entity @s[tag=!toisarm.bullet.shots_divide_damage,scores={toisarm.bullet.distance_damage_index=1..4}] run return run function toisarm:bullet/move/update_damage/1_4
execute if entity @s[tag=!toisarm.bullet.shots_divide_damage] run return run function toisarm:bullet/move/update_damage/5_8
execute if entity @s[scores={toisarm.bullet.distance_damage_index=1..4}] run return run function toisarm:bullet/move/update_damage/shots_divide_damage/1_4
function toisarm:bullet/move/update_damage/shots_divide_damage/5_8
