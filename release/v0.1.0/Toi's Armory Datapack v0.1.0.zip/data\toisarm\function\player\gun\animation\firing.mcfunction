    item modify entity @s weapon toisarm:gun/set_custom_model_data/2
    execute if score @s toisarm.timer.firing_anim matches 0.. run scoreboard players remove @s toisarm.timer.firing_anim 1
