execute if score @s toisarm.settings.move_comp.enable matches 1 if entity @n[type=marker,tag=DELAY_MARKER,distance=0.01..] run function toisarm:player/gun/trigger/move
execute if score @s toisarm.settings.rotate_comp.enable matches 1 run function toisarm:player/gun/trigger/delay_comp
scoreboard players set @s _ 0
execute at @s anchored eyes positioned ^ ^ ^ run function toisarm:player/gun/trigger/shot/
execute unless entity @s[scores={toisarm.settings.rotate_comp.enable=0,toisarm.settings.move_comp.enable=0}] run tp @s ~ ~ ~ ~ ~
