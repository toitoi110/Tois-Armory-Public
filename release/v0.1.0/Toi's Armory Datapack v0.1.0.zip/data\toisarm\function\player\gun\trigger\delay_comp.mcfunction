execute if entity @s[scores={toisarm.fire_mode=2,toisarm.settings.rotate_comp.enable_semi=0}] run return 0
scoreboard players operation @s toisarm.util.rotate_yaw = @s toisarm.smooth_diff_y  
scoreboard players operation @s toisarm.util.rotate_yaw *= @s toisarm.settings.rotate_comp.rate
scoreboard players operation @s toisarm.util.rotate_yaw /= 100 num
scoreboard players operation @s toisarm.util.rotate_pitch = @s toisarm.smooth_diff_p  
scoreboard players operation @s toisarm.util.rotate_pitch *= @s toisarm.settings.rotate_comp.rate
scoreboard players operation @s toisarm.util.rotate_pitch /= 100 num
scoreboard players operation @s _ = @s toisarm.settings.rotate_comp.max
scoreboard players operation @s _ *= 100 num
execute if score @s toisarm.util.rotate_yaw > @s _ run scoreboard players operation @s toisarm.util.rotate_yaw = @s _
execute if score @s toisarm.util.rotate_pitch > @s _ run scoreboard players operation @s toisarm.util.rotate_pitch = @s _
scoreboard players operation @s _ *= -1 num
execute if score @s toisarm.util.rotate_yaw < @s _ run scoreboard players operation @s toisarm.util.rotate_yaw = @s _
execute if score @s toisarm.util.rotate_pitch < @s _ run scoreboard players operation @s toisarm.util.rotate_pitch = @s _
execute as @s at @s run function toisarm:util/score_rotate/
