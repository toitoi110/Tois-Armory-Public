    tag @n[type=marker,tag=toisarm.delay_marker,predicate=toisarm:match_id] add DELAY_MARKER
    execute if score @s toisarm.settings.rotate_comp.enable matches 1 run function toisarm:player/gun/delay_comp
    execute if score @s toisarm.timer.swap matches 0.. run scoreboard players remove @s toisarm.timer.swap 1
    execute if entity @s[tag=toisarm.input.lclick,scores={toisarm.after_sprint_ads_speed=..0,toisarm.timer.sprint=1..}] run function toisarm:player/gun/get_after_sprint_ads_speed
    execute if entity @s[scores={toisarm.timer.reset_recoil_pattern=0..,toisarm.timer.trigger=-1}] run scoreboard players remove @s toisarm.timer.reset_recoil_pattern 1
    execute if score @s toisarm.timer.reset_recoil_pattern matches 0 run scoreboard players set @s toisarm.recoil.pattern_index 0
    execute if entity @s[tag=!toisarm.input.reload,scores={toisarm.timer.trigger=3,toisarm.timer.bolt_action_delay=-1,toisarm.input.change_fire_mode=..0,toisarm.timer.reload=-1,toisarm.timer.empty_reload=-1,toisarm.timer.firing=-1,toisarm.shootable=0}] run tag @s add toisarm.input.reload
    execute if entity @s[tag=toisarm.input.lclick,scores={toisarm.timer.empty_reload=-1,toisarm.timer.reload=-1,toisarm.timer.bolt_action=-1,toisarm.timer.bolt_action_delay=-1,toisarm.timer.change_fire_mode=-1,toisarm.input.change_fire_mode=..0}] run tag @s add toisarm.sprint_blocked
    execute if entity @s[scores={toisarm.timer.trigger=0..},predicate=toisarm:is_sprinting] run tag @s add toisarm.sprint_blocked
    execute if entity @s[tag=toisarm.sprint_blocked,tag=!toisarm.sprint_blocked_sprinting] if predicate {type:"entity_properties",entity:"this",predicate:{flags:{is_sprinting:true}}} run function toisarm:player/gun/block_sprint
    execute if entity @s[tag=!toisarm.remove_saturation_queue,tag=toisarm.sprint_blocked,tag=!toisarm.exhaustion_applied] run function toisarm:player/gun/apply_exhaustion
    scoreboard players remove @s[scores={toisarm.timer.bolt_action_delay=1..}] toisarm.timer.bolt_action_delay 1
    execute if entity @s[scores={toisarm.timer.sprint=0,toisarm.timer.swap=-1,toisarm.timer.bolt_action_delay=..0,toisarm.timer.bolt_action=-1,toisarm.timer.reload=-1,toisarm.timer.ads=0,toisarm.timer.reload_loop=-1}] unless score @s toisarm.state.chamber matches 0 run function toisarm:player/gun/bolt_action_check
    execute if score @s toisarm.timer.bolt_action matches 0 run function toisarm:player/gun/bolt_action/
    execute if score @s toisarm.timer.bolt_action matches 0.. run scoreboard players remove @s toisarm.timer.bolt_action 1
    execute if entity @s[scores={toisarm.timer.ads=0,toisarm.input.change_fire_mode=1..,toisarm.timer.sprint=..0,toisarm.input.change_fire_mode=1..,toisarm.timer.swap=-1,toisarm.timer.bolt_action=-1,toisarm.timer.bolt_action_delay=..0,toisarm.timer.change_fire_mode=-1,toisarm.timer.reload=-1,toisarm.timer.reload_loop=-1}] run function toisarm:player/gun/change_fire_mode_start
    execute if score @s toisarm.timer.change_fire_mode matches 0 run function toisarm:player/gun/change_fire_mode/
    execute if score @s toisarm.timer.change_fire_mode matches 0.. run scoreboard players remove @s toisarm.timer.change_fire_mode 1
    execute if entity @s[tag=!toisarm.input.reload,tag=toisarm.input.lclick,scores={toisarm.timer.swap=-1,toisarm.timer.bolt_action=-1,toisarm.timer.sprint=..0,toisarm.timer.reload=-1,toisarm.timer.empty_reload=-1,toisarm.input.change_fire_mode=..0,toisarm.timer.change_fire_mode=-1}] if score @s toisarm.state.ads > @s toisarm.timer.ads run function toisarm:player/gun/ads/advance_timer
    execute if score @s toisarm.timer.ads matches 1.. run function toisarm:player/gun/ads/remove_timer
    scoreboard players set @s[scores={toisarm.timer.ads=..-1}] toisarm.timer.ads 0
    scoreboard players set @s toisarm.ads_progress -10000
    scoreboard players operation @s toisarm.ads_progress *= @s toisarm.timer.ads
    scoreboard players operation @s toisarm.ads_progress /= @s toisarm.state.ads
    scoreboard players add @s toisarm.ads_progress 10000
    execute if score @s toisarm.ads_progress matches ..-1 run scoreboard players set @s toisarm.ads_progress 0
    execute if entity @s[tag=!toisarm.zoom] if score @s toisarm.ads_progress <= @s toisarm.state.zoom_ads_progress run function toisarm:player/gun/zoom/on
    execute if entity @s[tag=toisarm.zoom] unless score @s toisarm.ads_progress <= @s toisarm.state.zoom_ads_progress run function toisarm:player/gun/zoom/off
        data modify storage toisarm:temp transformation set value [0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,1.0f]
        execute store result score #target_x _ run data get entity @n[type=marker,tag=DELAY_MARKER] Pos[0] 100
        execute store result score #target_y _ run data get entity @n[type=marker,tag=DELAY_MARKER] Pos[1] 100
        execute store result score #target_z _ run data get entity @n[type=marker,tag=DELAY_MARKER] Pos[2] 100
        tp 0-0-0-0-1ae1e @s
        execute store result score @s _ run data get entity 0-0-0-0-1ae1e Pos[0] 100
        execute store result storage toisarm:temp transformation[0] float 0.01 run scoreboard players operation @s _ -= #target_x _
        execute store result score @s _ run data get entity 0-0-0-0-1ae1e Pos[1] 100
        execute store result storage toisarm:temp transformation[4] float 0.01 run scoreboard players operation @s _ -= #target_y _
        execute store result score @s _ run data get entity 0-0-0-0-1ae1e Pos[2] 100
        execute store result storage toisarm:temp transformation[8] float 0.01 run scoreboard players operation @s _ -= #target_z _
        tp 0-0-0-0-1ae1e 0.0 0.0 0.0 0.0 0.0
        data modify entity 0-0-0-0-1ae1e transformation set from storage toisarm:temp transformation
        data remove storage toisarm:temp transformation
        execute store result score @s _ store result score @s toisarm.distance run data get entity 0-0-0-0-1ae1e transformation.scale[0] 100
        scoreboard players operation @s toisarm.smooth_diff_distance *= 60 num
        scoreboard players operation @s _ *= 40 num
        scoreboard players operation @s toisarm.smooth_diff_distance += @s _
        scoreboard players operation @s toisarm.smooth_diff_distance /= 100 num
    scoreboard players operation @s toisarm.accuracy = @s toisarm.state.accuracy_idle
    scoreboard players operation @s toisarm.accuracy *= @s toisarm.ads_progress
    scoreboard players operation @s toisarm.accuracy /= 10000 num
    execute store result score @s _ run scoreboard players operation @s toisarm.accuracy += @s toisarm.state.accuracy_ads
    scoreboard players operation @s _ *= @s toisarm.smooth_diff_distance
    scoreboard players operation @s _ *= @s toisarm.state.accuracy_multiplier_move
    scoreboard players operation @s _ /= 500 num
    scoreboard players operation @s toisarm.accuracy += @s _
    scoreboard players operation @s _ = @s toisarm.bloom
    scoreboard players operation @s _ *= @s toisarm.ads_progress
    scoreboard players operation @s _ /= 10000 num
    scoreboard players operation @s toisarm.accuracy += @s _
    scoreboard players operation @s toisarm.bloom_decay -= @s toisarm.state.bloom_decay
    execute if score @s toisarm.bloom_decay matches ..-1 run scoreboard players set @s toisarm.bloom_decay 0
    scoreboard players operation @s toisarm.bloom *= @s toisarm.bloom_decay
    scoreboard players operation @s toisarm.bloom /= 100 num
    scoreboard players operation @s _ = @s toisarm.sway_speed
    scoreboard players operation @s _ *= 160 num
    scoreboard players operation @s _ /= 100 num
    execute store result entity 0-0-0-0-1ae1e Rotation[0] float 0.1 run scoreboard players operation @s toisarm.sway_pitch_progress += @s _
    scoreboard players set @s _ 10000
    scoreboard players operation @s _ -= @s toisarm.ads_progress
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z = @s toisarm.state.sway_pitch
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z *= @s _
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z /= 10000 num
    execute as 0-0-0-0-1ae1e at @s rotated ~ 0 run function toisarm:util/score_tp/z
    execute store result score @s toisarm.rotate_pitch_queue run data get entity 0-0-0-0-1ae1e Pos[0] 100
    execute if score @s toisarm.sway_pitch_progress matches 900.. run scoreboard players remove @s toisarm.sway_pitch_progress 3600
    tp 0-0-0-0-1ae1e 0.0 0.0 0.0 0.0 0.0
    execute store result entity 0-0-0-0-1ae1e Rotation[0] float 0.1 run scoreboard players operation @s toisarm.sway_yaw_progress += @s toisarm.sway_speed
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z = @s toisarm.state.sway_yaw
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z *= @s _
    scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_z /= 10000 num
    execute as 0-0-0-0-1ae1e at @s rotated ~ 0 run function toisarm:util/score_tp/z
    execute store result score @s toisarm.rotate_yaw_queue run data get entity 0-0-0-0-1ae1e Pos[0] 100
    execute if score @s toisarm.sway_yaw_progress matches 900.. run scoreboard players remove @s toisarm.sway_yaw_progress 3600
    tp 0-0-0-0-1ae1e 0.0 0.0 0.0 0.0 0.0
    execute if score @s toisarm.timer.ads > @s toisarm.state.ads run scoreboard players operation @s toisarm.timer.ads = @s toisarm.state.ads
    execute if entity @s[scores={toisarm.timer.swap=-1,toisarm.timer.bolt_action=-1,toisarm.timer.ads=0}] run function toisarm:player/gun/sprint/
    execute if score @s toisarm.timer.sprint matches ..-1 run scoreboard players set @s toisarm.timer.sprint 0
    execute if entity @s[tag=toisarm.input.reload,scores={toisarm.timer.swap=-1,toisarm.timer.bolt_action_delay=-1,toisarm.timer.bolt_action=-1,toisarm.timer.ads=0,toisarm.timer.sprint=0,toisarm.timer.reload=-1}] run function toisarm:player/gun/reload_check/
    execute unless entity @s[scores={toisarm.timer.reload=-1,toisarm.timer.empty_reload=-1}] run function toisarm:player/gun/reload/
    execute if score @s toisarm.timer.trigger matches 0.. run scoreboard players remove @s toisarm.timer.trigger 1
    execute unless score @s toisarm.fire_rate matches 100.. run scoreboard players operation @s toisarm.fire_rate += @s toisarm.state.fire_rate
    execute if entity @s[scores={toisarm.shootable=1,toisarm.timer.sprint=0,toisarm.timer.reload=-1,toisarm.timer.empty_reload=-1,toisarm.timer.swap=-1,toisarm.timer.bolt_action_delay=-1,toisarm.timer.bolt_action=-1,toisarm.fire_rate=100..}] run tag @s add SHOOTABLE
    execute if entity @s[tag=SHOOTABLE,scores={toisarm.fire_mode=1,toisarm.timer.trigger=0..}] run function toisarm:player/gun/trigger/
    execute if entity @s[tag=SHOOTABLE,scores={toisarm.fire_mode=2,toisarm.timer.trigger=3}] run function toisarm:player/gun/trigger/
    tag @s remove SHOOTABLE
    execute if entity @s[tag=toisarm.update_item_name] run function toisarm:player/gun/item_name/
    function toisarm:player/gun/animation/
    execute unless entity @s[scores={toisarm.shake_yaw_decay_remain=0,toisarm.shake_pitch_decay_remain=0}] run function toisarm:player/gun/shake_decay
    scoreboard players operation @s toisarm.shake_yaw_decay_remain += @s toisarm.shake_yaw
    scoreboard players operation @s toisarm.shake_pitch_decay_remain += @s toisarm.shake_pitch
    scoreboard players operation @s toisarm.rotate_yaw_queue += @s toisarm.shake_yaw
    scoreboard players operation @s toisarm.rotate_pitch_queue += @s toisarm.shake_pitch
    scoreboard players operation @s toisarm.shake_yaw_decay -= @s toisarm.state.shake_yaw_decay
    scoreboard players operation @s toisarm.shake_pitch_decay -= @s toisarm.state.shake_pitch_decay
    execute if score @s toisarm.shake_yaw_decay matches ..-1 run scoreboard players set @s toisarm.shake_yaw_decay 0
    execute if score @s toisarm.shake_pitch_decay matches ..-1 run scoreboard players set @s toisarm.shake_pitch_decay 0
    scoreboard players operation @s toisarm.shake_yaw *= @s toisarm.shake_yaw_decay
    scoreboard players operation @s toisarm.shake_pitch *= @s toisarm.shake_pitch_decay
    scoreboard players operation @s toisarm.shake_yaw /= 100 num
    scoreboard players operation @s toisarm.shake_pitch /= 100 num
    execute if score @s toisarm.shake_yaw matches 0 if score @s toisarm.shake_yaw_flip matches 1 run scoreboard players reset @s toisarm.shake_yaw_flip
    execute if score @s toisarm.timer.recoil_apply_tick matches 1.. run function toisarm:player/gun/recoil
    scoreboard players operation @s toisarm.util.rotate_yaw = @s toisarm.rotate_yaw_queue
    scoreboard players operation @s toisarm.util.rotate_pitch = @s toisarm.rotate_pitch_queue
    execute unless entity @s[scores={toisarm.util.rotate_yaw=0,toisarm.util.rotate_pitch=0}] run function toisarm:util/score_rotate/
    scoreboard players set @s toisarm.rotate_yaw_queue 0
    scoreboard players set @s toisarm.rotate_pitch_queue 0
    tag @n[type=marker,tag=DELAY_MARKER] remove DELAY_MARKER
    execute unless entity @n[type=marker,tag=toisarm.delay_marker,predicate=toisarm:match_id] run function toisarm:player/gun/summon_delay_marker
    tag @n[type=marker,tag=toisarm.delay_marker,predicate=toisarm:match_id] add KEEP
    tp @n[type=marker,tag=toisarm.delay_marker,predicate=toisarm:match_id] ~ ~ ~ ~ ~
