execute if score @s toisarm.recoil.pattern_index matches 0..15 run function toisarm:player/gun/trigger/shot/get_recoil/0_15
execute if score @s toisarm.recoil.pattern_index matches 16..31 run function toisarm:player/gun/trigger/shot/get_recoil/16_31
