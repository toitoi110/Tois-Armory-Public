execute if score @s toisarm.recoil.pattern_index matches 0..7 run function toisarm:player/gun/trigger/shot/get_recoil/0_7
execute if score @s toisarm.recoil.pattern_index matches 8..15 run function toisarm:player/gun/trigger/shot/get_recoil/8_15
