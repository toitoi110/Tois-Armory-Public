execute if score @s toisarm.recoil.pattern_index matches 112..115 run function toisarm:player/gun/trigger/shot/get_recoil/112_115
execute if score @s toisarm.recoil.pattern_index matches 116..119 run function toisarm:player/gun/trigger/shot/get_recoil/116_119
