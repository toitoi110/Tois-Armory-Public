execute if score @s toisarm.recoil.pattern_index matches 104 run function toisarm:player/gun/trigger/shot/get_recoil/104
execute if score @s toisarm.recoil.pattern_index matches 105 run function toisarm:player/gun/trigger/shot/get_recoil/105
