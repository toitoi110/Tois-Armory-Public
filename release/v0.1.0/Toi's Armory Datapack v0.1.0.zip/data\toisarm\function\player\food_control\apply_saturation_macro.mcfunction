$effect give @s saturation 1 $(level) true
tag @s add SUCCESS
