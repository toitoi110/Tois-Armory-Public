execute if score @s toisarm.recoil.pattern_index matches 124 run function toisarm:player/gun/trigger/shot/get_recoil/124
execute if score @s toisarm.recoil.pattern_index matches 125 run function toisarm:player/gun/trigger/shot/get_recoil/125
