execute if score @s toisarm.settings.keybind.drop matches 2.. run return run scoreboard players set @s toisarm.settings.keybind.drop 1
scoreboard players add @s toisarm.settings.keybind.drop 1
