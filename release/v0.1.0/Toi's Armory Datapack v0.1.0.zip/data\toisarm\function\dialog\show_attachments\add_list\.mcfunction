$data modify storage toisarm:dialog attachment_item_list append value {label:{translate:"item.toisarm.$(id)",fallback:"$(id)"},width:150,action:{type:"minecraft:run_command",command:"trigger toisarm.trigger.operate_attachment set $(count)"}}
data remove storage toisarm:dialog attachment_id[0]
execute unless data storage toisarm:dialog attachment_id[0] run return 0
execute store result storage toisarm:dialog attachment_id[0].count int 1 run scoreboard players add #toisarm.temp _ 1
function toisarm:dialog/show_attachments/add_list/ with storage toisarm:dialog attachment_id[0]
