    execute store result storage toisarm:temp ammo_remaining int 1 run scoreboard players remove @s toisarm.ammo_remaining 1
    item modify entity @s weapon toisarm:gun/apply_ammo_remaining
    item modify entity @s weapon toisarm:gun/set_chamber/1
    scoreboard players set @s toisarm.chamber 1
    tag @s add toisarm.update_item_name
    scoreboard players set @s toisarm.timer.bolt_action_delay -1
    scoreboard players set @s toisarm.shootable 1
