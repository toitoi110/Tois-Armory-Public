execute if score @s toisarm.recoil.pattern_index matches 14 run function toisarm:player/gun/trigger/shot/get_recoil/14
execute if score @s toisarm.recoil.pattern_index matches 15 run function toisarm:player/gun/trigger/shot/get_recoil/15
