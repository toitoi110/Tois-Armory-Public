data modify storage toisarm:dialog attachment_list set from storage toisarm:temp this_player.dialog.attachment_list
data modify storage toisarm:dialog attachment_data set from storage toisarm:temp this_player.dialog.attachment_data
data modify storage toisarm:dialog attachment set from storage toisarm:temp this_player.dialog.attachment
data remove storage toisarm:temp this_player.dialog.attachment
execute store result storage toisarm:dialog temp.count int 1 run scoreboard players get @s toisarm.trigger.get_attachment
function toisarm:dialog/get_attachment_with_id/with_trigger_count/ with storage toisarm:dialog temp
scoreboard players set @s toisarm.trigger.op_input 2
data remove storage toisarm:dialog temp
scoreboard players set @s toisarm.trigger.get_attachment -1
