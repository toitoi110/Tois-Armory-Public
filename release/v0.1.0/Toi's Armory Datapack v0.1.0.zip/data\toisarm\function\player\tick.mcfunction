    tag @s add PLAYER
    execute store result storage toisarm:temp id int 1 run scoreboard players operation #id _ = @s toisarm.id
    function toisarm:player/load_private_storage with storage toisarm:temp
    scoreboard players enable @s toisarm.trigger.input
    scoreboard players enable @s toisarm.trigger.close
    execute unless entity @s[scores={\
    toisarm.trigger.close=-1,\
    toisarm.trigger.input=-1,\
    toisarm.trigger.op_input=-1,\
    toisarm.trigger.get_gun=-1,\
    toisarm.trigger.get_attachment=-1,\
    toisarm.trigger.change_attachment_slot=-1,\
    toisarm.trigger.operate_attachment=-1,\
    toisarm.trigger.settings.keybind.swap=-1,\
    toisarm.trigger.settings.keybind.drop=-1,\
    toisarm.trigger.settings.reload_disable_ads=-1,\
    toisarm.trigger.settings.rotate_comp.enable=-1,\
    toisarm.trigger.settings.rotate_comp.rate=-1,\
    toisarm.trigger.settings.rotate_comp.noise_sup=-1,\
    toisarm.trigger.settings.rotate_comp.max=-1,\
    toisarm.trigger.settings.rotate_comp.enable_semi=-1,\
    toisarm.trigger.settings.move_comp.enable=-1,\
    toisarm.trigger.settings.move_comp.rate=-1,\
    toisarm.trigger.settings.reset=-1,\
    }] run function toisarm:dialog/
    execute if items entity @s weapon.offhand *[minecraft:custom_data~{toisarm:{type:gun}}] positioned 0.0 0.0 0.0 run function toisarm:player/swap_items
    execute if function toisarm:player/check_mainhand_changed/ run tag @s add CHANGED_SELECTED_SLOT
    execute if entity @s[tag=CHANGED_SELECTED_SLOT] run function toisarm:player/mainhand_changed/
    execute if entity @s[tag=toisarm.input] run function toisarm:player/keybind/
    execute if items entity @s weapon.mainhand *[minecraft:custom_data~{toisarm:{type:gun}}] run function toisarm:player/gun/
    execute if entity @s[tag=toisarm.input.drop] run tag @s remove toisarm.input.drop
    execute if entity @s[tag=toisarm.input.swap] run tag @s remove toisarm.input.swap
    execute if entity @s[scores={toisarm.timer.ads=0,toisarm.timer.sprint=0}] run tag @s remove toisarm.input.reload
    execute if score @s toisarm.drop matches 0.. run scoreboard players reset @s toisarm.drop
    execute if score @s toisarm.timer.firing matches 0.. run scoreboard players remove @s toisarm.timer.firing 1
    advancement revoke @s only toisarm:inventory_changed
    tag @s remove PLAYER
    scoreboard players add @s[scores={toisarm.sprint_distance=..-1},predicate=!toisarm:is_sprinting] toisarm.sprint_distance 20
    execute unless entity @s[scores={toisarm.sprint_distance=..0},predicate=!toisarm:is_sprinting] run function toisarm:player/movement/sprinting
    execute if score @s toisarm.timer.sliding matches 0.. run function toisarm:player/movement/sliding
    execute if entity @s[tag=toisarm.remove_saturation_queue] run function toisarm:player/food_control/after_saturation_applied
    execute if entity @s[tag=!toisarm.sprint_blocked,tag=toisarm.exhaustion_applied] run function toisarm:player/food_control/restore_food
    execute if entity @s[tag=!toisarm.sprint_blocked,tag=toisarm.sprint_blocked_sprinting] run function toisarm:player/remove_sprint_block
    execute if entity @s[tag=toisarm.sprint_blocked_sprinting] if predicate {type:"entity_properties",entity:"this",predicate:{flags:{is_sprinting:false}}} run function toisarm:player/remove_sprint_block
    function toisarm:player/save_private_storage with storage toisarm:temp
