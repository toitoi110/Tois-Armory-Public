
data modify storage toisarm:sound {} merge value {max_distance:64,sounds:[\
{id:"minecraft:entity.hoglin.step",volume:0.3,pitch:0.65},\
{id:"minecraft:item.shield.block",volume:0.2,pitch:0.4},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.3,pitch:0.1},\
{id:"minecraft:entity.iron_golem.repair",volume:0.12,pitch:0.95},\
{id:"minecraft:block.packed_mud.hit",volume:1,pitch:0.3},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:32,sounds:[\
{id:"minecraft:entity.hoglin.step",volume:0.3,pitch:0.65},\
{id:"minecraft:block.copper_grate.hit",volume:0.2,pitch:1.15},\
{id:"minecraft:block.wooden_door.close",volume:0.42,pitch:1.45},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
execute at @s run function toisarm:util/ejection/ {motion:"^-0.28 ^0.12 ^-0.2",item_model:"toisarm:other/medium_casing",x:-0.2,y:0,z:0.2,offset:"^-0.2 ^-0.2 ^0.45"}
