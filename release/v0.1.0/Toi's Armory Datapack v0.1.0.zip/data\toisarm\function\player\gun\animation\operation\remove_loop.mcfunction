    data remove storage toisarm:temp this_player.temp.commands[0]
    execute unless data storage toisarm:temp this_player.temp.commands[0] run return 0
    execute store result score @s _ run data get storage toisarm:temp this_player.temp.commands[0].time 1000
    execute if score @s toisarm.animation >= @s _ run function toisarm:player/gun/animation/operation/remove_loop
