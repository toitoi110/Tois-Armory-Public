
data modify storage toisarm:sound {} merge value {max_distance:96,sounds:[\
{id:"minecraft:item.shield.block",volume:0.1,pitch:0.3},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.2,pitch:0.05},\
{id:"minecraft:entity.hoglin.step",volume:0.3,pitch:0.4},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.04,pitch:0.75},\
{id:"minecraft:entity.iron_golem.death",volume:0.025,pitch:1.3},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:item.shield.block",volume:0.35,pitch:0.1},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.32,pitch:0.05},\
{id:"minecraft:entity.hoglin.step",volume:0.5,pitch:0.4},\
{id:"minecraft:entity.iron_golem.repair",volume:0.2,pitch:0.85},\
{id:"minecraft:block.stone_button.click_on",volume:0.8,pitch:1.5},\
{id:"minecraft:block.copper_grate.hit",volume:0.5,pitch:1.85},\
{id:"minecraft:block.wooden_door.close",volume:0.15,pitch:0.25},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.06 0.06 0.06 10000000000 6 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 0 2 force @a
