execute store result score @s _ run scoreboard players operation @s toisarm.shake_yaw_decaying += @s toisarm.state.shake_yaw_decay
execute if score @s _ matches 101.. run scoreboard players set @s _ 100
scoreboard players operation @s _ *= @s toisarm.shake_yaw_decay_remain
scoreboard players operation @s _ /= 100 num
scoreboard players operation @s toisarm.shake_yaw_decay_remain -= @s _
scoreboard players operation @s toisarm.rotate_yaw_queue -= @s _
execute store result score @s _ run scoreboard players operation @s toisarm.shake_pitch_decaying += @s toisarm.state.shake_pitch_decay
execute if score @s _ matches 101.. run scoreboard players set @s _ 100
scoreboard players operation @s _ *= @s toisarm.shake_pitch_decay_remain
scoreboard players operation @s _ /= 100 num
scoreboard players operation @s toisarm.shake_pitch_decay_remain -= @s _
scoreboard players operation @s toisarm.rotate_pitch_queue -= @s _
