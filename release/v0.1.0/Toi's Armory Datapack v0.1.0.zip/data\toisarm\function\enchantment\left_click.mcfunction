execute if entity @s[tag=!toisarm.input.lclick] run return run tag @s add toisarm.input.lclick
tag @s remove toisarm.input.lclick
scoreboard players set @s toisarm.after_sprint_ads_speed 0
