scoreboard players operation @s toisarm.animation = @s toisarm.state.empty_reload
scoreboard players operation @s toisarm.animation -= @s toisarm.timer.empty_reload
execute if score @s toisarm.animation_id matches 6 run scoreboard players set @s toisarm.animation_interrupted 1
execute unless score @s toisarm.animation_id matches 4 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 4
