tellraw @s {"color":"red","translate":"button.dialog.toisarm.change_attachments_tooltip"}
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 1 0
