execute if score @s toisarm.settings.move_comp.enable matches 0 run return run scoreboard players set @s toisarm.settings.move_comp.enable 1
scoreboard players set @s toisarm.settings.move_comp.enable 0
