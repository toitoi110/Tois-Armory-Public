
execute if entity @s[tag=trail.default_gunpack.small] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.2} ~ ~ ~ 0 0 0 0 1 force @a
execute if entity @s[tag=trail.default_gunpack.medium] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.225} ~ ~ ~ 0 0 0 0 1 force @a
execute if entity @s[tag=trail.default_gunpack.large] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.25} ~ ~ ~ 0 0 0 0 1 force @a


# 以降過去の試行錯誤の遺産

#execute rotated as @s facing ^ ^ ^-10 run rotate 0-0-0-0-1ae1e ~ ~
#tag @s add TRAIL
#tag 0-0-0-0-1ae1e add TRAIL
#execute if entity @s[tag=default_gunpack.12gauge] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.19} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x18mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.19} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x19mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.195} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.4.6x30mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.2} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.45acp] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.21} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.7x28mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.215} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.45x39mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.22} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x39mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.22} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.56x45mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.225} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.6.8x51mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.235} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x39mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.24} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x51mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.25} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.357magnum] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.255} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x54mmr] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.265} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.50ae] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.27} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.12.7x55mm] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.28} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.50bmg] as @e[tag=TRAIL] positioned ~ ~ ~ positioned ^ ^ ^0.15 as @e[tag=TRAIL] positioned ^ ^ ^0.075 as @e[tag=TRAIL] positioned ^ ^ ^0.0375 run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.3} ~ ~ ~ 0 0 0 0 1 force @a
#tag @s remove TRAIL
#tag 0-0-0-0-1ae1e remove TRAIL

#execute if entity @s[tag=default_gunpack.12gauge] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.19} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x18mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.19} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x19mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.195} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.4.6x30mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.2} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.45acp] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.21} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.7x28mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.215} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.45x39mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.22} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.9x39mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.22} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.5.56x45mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.225} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.6.8x51mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.235} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x39mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.24} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x51mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.25} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.357magnum] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.255} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.7.62x54mmr] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.265} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.50ae] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.27} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.12.7x55mm] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.28} ~ ~ ~ 0 0 0 0 1 force @a
#execute if entity @s[tag=default_gunpack.50bmg] run return run particle dust_color_transition{from_color:[1.0,0.8,0.5],to_color:[0.92,0.92,0.92],scale:0.3} ~ ~ ~ 0 0 0 0 1 force @a


#execute rotated as @s facing ^ ^ ^-10 run rotate 0-0-0-0-1ae1e ~ ~
#tag @s add TRAIL
#tag 0-0-0-0-1ae1e add TRAIL

#tag @s remove TRAIL
#tag 0-0-0-0-1ae1e remove TRAIL

