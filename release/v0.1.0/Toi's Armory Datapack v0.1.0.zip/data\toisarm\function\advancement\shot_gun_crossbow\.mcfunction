scoreboard players set @s toisarm.timer.trigger 4
kill @n[type=arrow,nbt={PierceLevel:30b}]
advancement revoke @s only toisarm:shot_gun_crossbow
stopsound @a[distance=..16] player minecraft:item.crossbow.shoot
execute if items entity @s weapon.mainhand crossbow run return run item modify entity @s weapon.mainhand {"type":"minecraft:set_components","components":{"minecraft:charged_projectiles":[{"id":"minecraft:arrow","count":1}]}}
return run item modify entity @s weapon.offhand {"type":"minecraft:set_components","components":{"minecraft:charged_projectiles":[{"id":"minecraft:arrow","count":1}]}}
