execute as @e[type=text_display,tag=toisarm.impact_mark] at @s run function toisarm:impact_mark/tick
execute if entity @n[type=text_display,tag=toisarm.impact_mark] run schedule function toisarm:impact_mark/schedule 1t replace
