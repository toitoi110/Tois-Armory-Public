execute if score @s toisarm.recoil.pattern_index matches 108 run function toisarm:player/gun/trigger/shot/get_recoil/108
execute if score @s toisarm.recoil.pattern_index matches 109 run function toisarm:player/gun/trigger/shot/get_recoil/109
