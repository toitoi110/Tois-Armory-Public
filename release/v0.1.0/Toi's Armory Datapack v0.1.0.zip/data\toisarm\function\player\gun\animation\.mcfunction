    execute if score @s toisarm.timer.firing_anim_delay matches 0.. run scoreboard players remove @s toisarm.timer.firing_anim_delay 1
    execute unless entity @s[scores={toisarm.timer.firing_anim=-1}] run function toisarm:player/gun/animation/firing
    execute unless entity @s[scores={toisarm.timer.bolt_move_anim=-1},tag=!toisarm.update_bolt_move_anim] run function toisarm:player/gun/animation/bolt
    item modify entity @s weapon toisarm:gun/set_custom_model_data/4
    item modify entity @s weapon toisarm:gun/set_custom_model_data/5
    execute if data storage toisarm:temp sub_anim_frame run data remove storage toisarm:temp sub_anim_frame
    function toisarm:player/gun/animation/get/
    execute if entity @s[tag=IDLE] run return run tag @s remove IDLE
    execute if score @s toisarm.animation_id matches 0 run return run function toisarm:player/gun/animation/operation/idle/
    execute if score @s toisarm.animation_id matches 1 run return run function toisarm:player/gun/animation/operation/ads/
    execute if score @s toisarm.animation_id matches 2 run return run function toisarm:player/gun/animation/operation/bolt_action/
    execute if score @s toisarm.animation_id matches 3 run return run function toisarm:player/gun/animation/operation/change_fire_mode/
    execute if score @s toisarm.animation_id matches 4 run return run function toisarm:player/gun/animation/operation/empty_reload/
    execute if score @s toisarm.animation_id matches 5 run return run function toisarm:player/gun/animation/operation/reload/
    execute if score @s toisarm.animation_id matches 6 run return run function toisarm:player/gun/animation/operation/reload_loop/
    execute if score @s toisarm.animation_id matches 7 run return run function toisarm:player/gun/animation/operation/sprint/
    execute if score @s toisarm.animation_id matches 8 run return run function toisarm:player/gun/animation/operation/swap/
