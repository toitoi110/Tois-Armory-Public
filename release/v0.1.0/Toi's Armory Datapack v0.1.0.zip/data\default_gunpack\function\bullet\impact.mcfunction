
# smallとlargeを作ってもいいけどTaCZを見るにmediumだけでも違和感はない
function default_gunpack:impact_mark/medium


# 過去の試行錯誤の遺産

#function default_gunpack:bullet/generic/impact with entity @s

#execute if entity @s[tag=default_gunpack.12gauge] run return run function default_gunpack:bullet/12gauge/impact with entity @s
#execute if entity @s[tag=default_gunpack.9x18mm] run return run function default_gunpack:bullet/9x18mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.9x19mm] run return run function default_gunpack:bullet/9x19mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.4.6x30mm] run return run function default_gunpack:bullet/4.6x30mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.45acp] run return run function default_gunpack:bullet/45acp/impact with entity @s
#execute if entity @s[tag=default_gunpack.5.7x28mm] run return run function default_gunpack:bullet/5.7x28mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.5.45x39mm] run return run function default_gunpack:bullet/5.45x39mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.9x39mm] run return run function default_gunpack:bullet/9x39mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.5.56x45mm] run return run function default_gunpack:bullet/5.56x45mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.6.8x51mm] run return run function default_gunpack:bullet/6.8x51mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.7.62x39mm] run return run function default_gunpack:bullet/7.62x39mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.7.62x51mm] run return run function default_gunpack:bullet/7.62x51mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.357magnum] run return run function default_gunpack:bullet/357magnum/impact with entity @s
#execute if entity @s[tag=default_gunpack.7.62x54mmr] run return run function default_gunpack:bullet/7.62x54mmr/impact with entity @s
#execute if entity @s[tag=default_gunpack.50ae] run return run function default_gunpack:bullet/50ae/impact with entity @s
#execute if entity @s[tag=default_gunpack.12.7x55mm] run return run function default_gunpack:bullet/12.7x55mm/impact with entity @s
#execute if entity @s[tag=default_gunpack.50bmg] run return run function default_gunpack:bullet/50bmg/impact with entity @s
