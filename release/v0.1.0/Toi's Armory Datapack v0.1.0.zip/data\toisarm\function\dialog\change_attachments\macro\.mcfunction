$data modify storage toisarm:dialog attachment set from storage toisarm:data gun[{id:$(id)}].attachment
