data modify storage toisarm:import attachment append value \
{\
    "id":"uzi_short_magazine",\
    "slot": "magazine",\
    "item_model":"minecraft:iron_ingot",\
    "display_name":{"translate": "item.toisarm.uzi_short_magazine","fallback": "UZI Short Magazine"},\
}
data modify storage toisarm:import attachment append value \
{\
    "id":"uzi_mini_barrel",\
    "slot": "barrel",\
    "item_model":"minecraft:stick",\
    "display_name":{"translate": "item.toisarm.uzi_mini_barrel","fallback": "UZI Mini Barrel"},\
}
data modify storage toisarm:import attachment append value \
{\
    "id":"uzi_folded_stock",\
    "slot": "stock",\
    "item_model":"minecraft:hopper",\
    "display_name":{"translate": "item.toisarm.uzi_folded_stock","fallback": "UZI Folded Stock"},\
}