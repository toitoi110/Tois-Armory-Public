$$(reload_loop_success_cmd)
    execute store result storage toisarm:temp ammo_remaining int 1 run scoreboard players add @s toisarm.ammo_remaining 1
    item modify entity @s weapon.mainhand toisarm:gun/apply_ammo_remaining
    tag @s add toisarm.update_item_name
