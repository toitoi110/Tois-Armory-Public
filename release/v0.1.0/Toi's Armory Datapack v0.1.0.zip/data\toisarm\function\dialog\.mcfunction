tag @s remove DIALOG
execute if score @s toisarm.trigger.input matches 100 run function toisarm:dialog/open/
execute if score @s toisarm.trigger.input matches 0 run function toisarm:dialog/close/
execute if score @s toisarm.trigger.input matches 1 run function toisarm:dialog/change_attachments/
execute unless entity @s[scores={\
toisarm.trigger.input=-1,\
toisarm.trigger.settings.keybind.swap=-1,\
toisarm.trigger.settings.keybind.drop=-1,\
toisarm.trigger.settings.reload_disable_ads=-1,\
toisarm.trigger.settings.rotate_comp.enable=-1,\
toisarm.trigger.settings.rotate_comp.rate=-1,\
toisarm.trigger.settings.rotate_comp.noise_sup=-1,\
toisarm.trigger.settings.rotate_comp.max=-1,\
toisarm.trigger.settings.rotate_comp.enable_semi=-1,\
toisarm.trigger.settings.move_comp.enable=-1,\
toisarm.trigger.settings.move_comp.rate=-1,\
toisarm.trigger.settings.reset=-1,\
}] unless score @s toisarm.trigger.input matches 0..1 unless score @s toisarm.trigger.input matches 3.. run function toisarm:dialog/change_settings/
execute if score @s toisarm.trigger.op_input matches 0 run function toisarm:dialog/close/
execute if score @s toisarm.trigger.op_input matches 1 run function toisarm:dialog/get_gun/
execute if score @s toisarm.trigger.op_input matches 2 run function toisarm:dialog/get_attachment/
execute if score @s toisarm.trigger.op_input matches 3 run scoreboard players set @s toisarm.trigger.op_input -1
execute if score @s toisarm.trigger.get_gun matches 0.. run function toisarm:dialog/get_gun_with_id/
execute if score @s toisarm.trigger.get_attachment matches 0.. run function toisarm:dialog/get_attachment_with_id/
execute if score @s toisarm.trigger.change_attachment_slot matches 0.. run function toisarm:dialog/show_attachments/
execute if score @s toisarm.trigger.operate_attachment matches 0.. run function toisarm:dialog/operate_attachments/
execute if score @s toisarm.trigger.close matches 0.. run function toisarm:dialog/close/
