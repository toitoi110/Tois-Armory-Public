$function toisarm:dialog/get_attachment_with_id/with_trigger_count/with_id/ with storage toisarm:dialog attachment_data[$(count)]
