tag @s remove BULLET_INIT
data modify entity @s Tags append from storage toisarm:temp this_player.data.gun.state.bullet_id
data modify entity @s Tags append from storage toisarm:temp this_player.data.gun.state.trail_id
scoreboard players operation @s toisarm.bullet.owner = #id _
execute store result score @s toisarm.bullet.distance_damage_max_index run data modify entity @s data.damage_by_distance set from storage toisarm:temp this_player.data.gun.state.damage_by_distance
data modify entity @s data.fire_cmd set from storage toisarm:temp this_player.data.gun.state.fire_cmd
data modify entity @s data.trail_offset set value [0.0f,0.0f,0.0f]
execute store result score @s toisarm.bullet.trail_offset_x run data get storage toisarm:temp this_player.data.gun.state.trail_pos[0] 1000000
execute store result score @s _ run data get storage toisarm:temp this_player.data.gun.state.trail_offset[0] 1000000
scoreboard players operation @s _ -= @s toisarm.bullet.trail_offset_x
scoreboard players operation @s _ /= 10000 num
scoreboard players operation @s _ *= @p[tag=PLAYER] toisarm.ads_progress 
scoreboard players operation @s toisarm.bullet.trail_offset_x += @s _
execute store result score @s toisarm.bullet.trail_offset_y run data get storage toisarm:temp this_player.data.gun.state.trail_pos[1] 1000000
execute store result score @s _ run data get storage toisarm:temp this_player.data.gun.state.trail_offset[1] 1000000
scoreboard players operation @s _ -= @s toisarm.bullet.trail_offset_y
scoreboard players operation @s _ /= 10000 num
scoreboard players operation @s _ *= @p[tag=PLAYER] toisarm.ads_progress 
scoreboard players operation @s toisarm.bullet.trail_offset_y += @s _
execute store result score @s toisarm.bullet.trail_offset_z run data get storage toisarm:temp this_player.data.gun.state.trail_pos[2] 1000000
execute store result score @s _ run data get storage toisarm:temp this_player.data.gun.state.trail_offset[2] 1000000
scoreboard players operation @s _ -= @s toisarm.bullet.trail_offset_z
scoreboard players operation @s _ /= 10000 num
scoreboard players operation @s _ *= @p[tag=PLAYER] toisarm.ads_progress 
scoreboard players operation @s toisarm.bullet.trail_offset_z += @s _
execute if data storage toisarm:temp this_player.data.gun.state{shots_divide_damage:1b} run tag @s add toisarm.bullet.shots_divide_damage
execute store result score @s toisarm.bullet.shots run data get storage toisarm:temp this_player.data.gun.state.projectiles_per_shot
execute store result score @s toisarm.bullet.max_range run data get storage toisarm:temp this_player.data.gun.state.max_range 100
execute store result score @s toisarm.bullet.velocity run data get storage toisarm:temp this_player.data.gun.state.bullet_velocity 100
execute store result score @s toisarm.bullet.drag run data get storage toisarm:temp this_player.data.gun.state.bullet_drag 100
execute store result score @s toisarm.bullet.gravity run data get storage toisarm:temp this_player.data.gun.state.bullet_gravity 100
execute store result score @s toisarm.bullet.weight run data get storage toisarm:temp this_player.data.gun.state.bullet_weight 100
execute store result score @s toisarm.bullet.penetration run data get storage toisarm:temp this_player.data.gun.state.bullet_penetration 10
scoreboard players set @s toisarm.bullet.distance_traveled 0
execute if entity @s[tag=!toisarm.bullet.shots_divide_damage] run function toisarm:player/gun/trigger/shot/set_damage/
execute if entity @s[tag=toisarm.bullet.shots_divide_damage] run function toisarm:player/gun/trigger/shot/set_damage/divide
execute if score @p[tag=PLAYER] toisarm.accuracy matches 0 rotated as @p[tag=PLAYER] run return run rotate @s ~ ~
execute store result score 0-0-0-0-1ae1e toisarm.util.tp_x run random value 0..10000
scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_x %= @p[tag=PLAYER] toisarm.accuracy
execute store result score 0-0-0-0-1ae1e toisarm.util.tp_y run random value 0..10000
scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_y %= @p[tag=PLAYER] toisarm.accuracy
execute store result score @s _ run random value 1..4
execute if score @s _ matches 1..2 run scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_x *= -1 num
execute if score @s _ matches 2..3 run scoreboard players operation 0-0-0-0-1ae1e toisarm.util.tp_y *= -1 num
data modify entity @s data.rotation set from entity @p[tag=PLAYER] Rotation
execute as 0-0-0-0-1ae1e rotated as @p[tag=PLAYER] positioned 0.0 0.0 0.0 run function toisarm:util/score_tp/
execute as 0-0-0-0-1ae1e rotated as @p[tag=PLAYER] positioned as @s run tp @s ^ ^ ^16
execute positioned as 0-0-0-0-1ae1e positioned 0.0 0.0 0.0 facing entity 0-0-0-0-1ae1e feet run rotate @s ~ ~
tp 0-0-0-0-1ae1e 0.0 0.0 0.0
