scoreboard players enable @s toisarm.trigger.op_input
dialog show @s toisarm:op_menu
