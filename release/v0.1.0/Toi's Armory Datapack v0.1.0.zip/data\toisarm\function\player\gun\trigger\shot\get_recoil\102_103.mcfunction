execute if score @s toisarm.recoil.pattern_index matches 102 run function toisarm:player/gun/trigger/shot/get_recoil/102
execute if score @s toisarm.recoil.pattern_index matches 103 run function toisarm:player/gun/trigger/shot/get_recoil/103
