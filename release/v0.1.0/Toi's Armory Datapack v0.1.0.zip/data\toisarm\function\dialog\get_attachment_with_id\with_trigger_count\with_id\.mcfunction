$function toisarm:dialog/get_attachment_with_id/with_trigger_count/with_id/with_data/ with storage toisarm:data attachment[{id:"$(id)"}]
