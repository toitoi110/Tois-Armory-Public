scoreboard players set @s toisarm.trigger.input -1
execute if score @s toisarm.trigger.settings.reload_disable_ads matches 1 run function toisarm:dialog/change_settings/reload_disable_ads 
execute if score @s toisarm.trigger.settings.rotate_comp.enable matches 1 run function toisarm:dialog/change_settings/rotate_comp/enable 
execute if score @s toisarm.trigger.settings.rotate_comp.rate matches 1 run function toisarm:dialog/change_settings/rotate_comp/rate 
execute if score @s toisarm.trigger.settings.rotate_comp.noise_sup matches 1 run function toisarm:dialog/change_settings/rotate_comp/noise_sup 
execute if score @s toisarm.trigger.settings.rotate_comp.max matches 1 run function toisarm:dialog/change_settings/rotate_comp/max 
execute if score @s toisarm.trigger.settings.rotate_comp.enable_semi matches 1 run function toisarm:dialog/change_settings/rotate_comp/enable_semi 
execute if score @s toisarm.trigger.settings.move_comp.enable matches 1 run function toisarm:dialog/change_settings/move_comp/enable 
execute if score @s toisarm.trigger.settings.move_comp.rate matches 1 run function toisarm:dialog/change_settings/move_comp/rate 
execute if score @s toisarm.trigger.settings.keybind.swap matches 1 run function toisarm:dialog/change_settings/keybind/swap 
execute if score @s toisarm.trigger.settings.keybind.drop matches 1 run function toisarm:dialog/change_settings/keybind/drop 
execute if score @s toisarm.trigger.settings.reset matches 1 run tag @s add RESET
execute if score @s toisarm.trigger.settings.reset matches 2 run function toisarm:dialog/change_settings/reset_confirm
scoreboard players set @s toisarm.trigger.settings.reload_disable_ads -1
scoreboard players set @s toisarm.trigger.settings.rotate_comp.enable -1
scoreboard players set @s toisarm.trigger.settings.rotate_comp.rate -1
scoreboard players set @s toisarm.trigger.settings.rotate_comp.noise_sup -1
scoreboard players set @s toisarm.trigger.settings.rotate_comp.max -1
scoreboard players set @s toisarm.trigger.settings.rotate_comp.enable_semi -1
scoreboard players set @s toisarm.trigger.settings.move_comp.enable -1
scoreboard players set @s toisarm.trigger.settings.move_comp.rate -1
scoreboard players set @s toisarm.trigger.settings.keybind.swap -1
scoreboard players set @s toisarm.trigger.settings.keybind.drop -1
scoreboard players set @s toisarm.trigger.settings.reset -1
scoreboard players enable @s toisarm.trigger.settings.reload_disable_ads
scoreboard players enable @s toisarm.trigger.settings.rotate_comp.enable
scoreboard players enable @s toisarm.trigger.settings.rotate_comp.rate
scoreboard players enable @s toisarm.trigger.settings.rotate_comp.noise_sup
scoreboard players enable @s toisarm.trigger.settings.rotate_comp.max
scoreboard players enable @s toisarm.trigger.settings.rotate_comp.enable_semi
scoreboard players enable @s toisarm.trigger.settings.move_comp.enable
scoreboard players enable @s toisarm.trigger.settings.move_comp.rate
scoreboard players enable @s toisarm.trigger.settings.keybind.swap
scoreboard players enable @s toisarm.trigger.settings.keybind.drop
scoreboard players enable @s toisarm.trigger.settings.reset
execute if entity @s[tag=RESET] run return run function toisarm:dialog/change_settings/reset 
function toisarm:dialog/change_settings/merge_dialog/
function toisarm:dialog/change_settings/show with storage toisarm:dialog
data remove storage toisarm:dialog actions
