execute if score @s toisarm.recoil.pattern_index matches 108..109 run function toisarm:player/gun/trigger/shot/get_recoil/108_109
execute if score @s toisarm.recoil.pattern_index matches 110..111 run function toisarm:player/gun/trigger/shot/get_recoil/110_111
