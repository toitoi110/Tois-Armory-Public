scoreboard players add @s toisarm.timer.sprint 100
execute if score @s toisarm.state.sprint < @s toisarm.timer.sprint run scoreboard players operation @s toisarm.timer.sprint = @s toisarm.state.sprint
