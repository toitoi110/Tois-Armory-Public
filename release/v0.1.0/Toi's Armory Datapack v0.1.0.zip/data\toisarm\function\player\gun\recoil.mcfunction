    scoreboard players remove @s toisarm.timer.recoil_apply_tick 1
    scoreboard players operation # _ = @s toisarm.recoil.progress
    scoreboard players operation # _ *= # _
    scoreboard players operation # _ *= -1 num
    scoreboard players add # _ 1000000
    scoreboard players operation # _ /= 1000 num
    scoreboard players operation @s _ = @s toisarm.recoil.total_yaw
    scoreboard players operation @s _ *= # _
    scoreboard players operation @s _ /= 1000 num
    scoreboard players operation @s toisarm.recoil.total_yaw -= @s _
    scoreboard players operation @s toisarm.rotate_yaw_queue += @s _
    scoreboard players operation @s _ = @s toisarm.recoil.total_pitch
    scoreboard players operation @s _ *= # _
    scoreboard players operation @s _ /= 1000 num
    scoreboard players operation @s toisarm.recoil.total_pitch -= @s _
    scoreboard players operation @s toisarm.rotate_pitch_queue += @s _
    scoreboard players operation @s toisarm.recoil.progress -= @s toisarm.recoil.progress_per_tick
