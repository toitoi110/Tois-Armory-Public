execute if score @s toisarm.recoil.pattern_index matches 16..17 run function toisarm:player/gun/trigger/shot/get_recoil/16_17
execute if score @s toisarm.recoil.pattern_index matches 18..19 run function toisarm:player/gun/trigger/shot/get_recoil/18_19
