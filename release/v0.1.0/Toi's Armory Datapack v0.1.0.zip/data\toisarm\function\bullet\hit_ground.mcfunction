execute store result score @s toisarm.bullet.velocity_remaining run scoreboard players operation #raycast.tm toisarm.util.raycast /= 10 num
tag @s add HIT_GROUND
