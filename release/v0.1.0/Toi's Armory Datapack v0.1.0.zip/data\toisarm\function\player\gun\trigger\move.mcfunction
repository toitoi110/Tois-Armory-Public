scoreboard players operation @s toisarm.distance *= @s toisarm.settings.move_comp.rate
execute store result score @s toisarm.util.tp_z run scoreboard players operation @s toisarm.distance /= -200 num
execute facing entity @n[type=marker,tag=DELAY_MARKER] feet run rotate @n[type=marker,tag=DELAY_MARKER] ~ ~
execute rotated as @n[type=marker,tag=DELAY_MARKER] run function toisarm:util/score_tp/_z
execute store result score @s toisarm.util.tp_z run scoreboard players operation @s toisarm.distance *= -1 num
execute positioned as @s rotated as @n[type=marker,tag=DELAY_MARKER] rotated ~180 ~ run function toisarm:util/score_tp/z
