data modify storage toisarm:import attachment append value \
{\
    "id":"scar_h_drum_magazine",\
    "slot": "magazine",\
    "item_model":"minecraft:stick",\
    "display_name":{"translate": "item.toisarm.scar_h_drum_magazine","fallback": "SCAR-H Drum Magazine"},\
}
