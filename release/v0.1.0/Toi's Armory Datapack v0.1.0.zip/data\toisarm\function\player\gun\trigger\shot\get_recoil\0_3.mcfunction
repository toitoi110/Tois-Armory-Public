execute if score @s toisarm.recoil.pattern_index matches 0..1 run function toisarm:player/gun/trigger/shot/get_recoil/0_1
execute if score @s toisarm.recoil.pattern_index matches 2..3 run function toisarm:player/gun/trigger/shot/get_recoil/2_3
