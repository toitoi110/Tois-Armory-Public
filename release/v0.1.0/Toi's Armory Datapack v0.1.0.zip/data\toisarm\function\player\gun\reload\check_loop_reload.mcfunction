    execute unless score @s toisarm.timer.reload_loop matches -1 run return 0
    execute if score @s toisarm.timer.trigger matches 0.. run return 0
    execute unless score @s toisarm.ammo_remaining < @s toisarm.state.ammo_capacity run return 0
    execute if score @s toisarm.timer.empty_reload matches 0.. if score @s toisarm.state.empty_reload_loop_start = @s toisarm.timer.empty_reload run return run scoreboard players operation @s toisarm.timer.reload_loop = @s toisarm.state.reload_loop
    execute if score @s toisarm.timer.empty_reload matches -1 if score @s toisarm.state.reload_loop_start = @s toisarm.timer.reload run scoreboard players operation @s toisarm.timer.reload_loop = @s toisarm.state.reload_loop
