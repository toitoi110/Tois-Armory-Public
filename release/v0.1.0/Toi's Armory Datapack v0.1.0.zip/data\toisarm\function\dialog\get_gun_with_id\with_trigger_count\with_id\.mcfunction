$function toisarm:dialog/get_gun_with_id/with_trigger_count/with_id/with_data/ with storage toisarm:data gun[{id:"$(id)"}]
