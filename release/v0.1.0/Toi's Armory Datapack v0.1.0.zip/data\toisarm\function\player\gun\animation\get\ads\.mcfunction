scoreboard players operation @s toisarm.animation = @s toisarm.timer.ads
execute unless score @s toisarm.animation_id matches 1 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 1
