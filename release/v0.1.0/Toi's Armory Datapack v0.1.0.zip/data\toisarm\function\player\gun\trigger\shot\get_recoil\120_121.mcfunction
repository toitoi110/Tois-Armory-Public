execute if score @s toisarm.recoil.pattern_index matches 120 run function toisarm:player/gun/trigger/shot/get_recoil/120
execute if score @s toisarm.recoil.pattern_index matches 121 run function toisarm:player/gun/trigger/shot/get_recoil/121
