execute if score @s toisarm.bullet.distance_damage_index matches 5..6 run return run function toisarm:bullet/move/update_damage/5_6
function toisarm:bullet/move/update_damage/7_8
