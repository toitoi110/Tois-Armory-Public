data modify storage toisarm:import attachment append value \
{\
    "id":"svd_long_barrel",\
    "slot": "barrel",\
    "item_model":"minecraft:stick",\
    "display_name":{"translate": "item.toisarm.svd_long_barrel","fallback": "SVD Long Barrel"},\
}
