$particle minecraft:trail{color:[0.149,0.137,0.122],duration:600,target:$(Pos)} ~ ~ ~ 0 0 0 1 0 force @a
