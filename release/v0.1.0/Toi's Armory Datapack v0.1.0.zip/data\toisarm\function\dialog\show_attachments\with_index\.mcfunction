$function toisarm:dialog/show_attachments/with_index/with_id/ with storage toisarm:temp this_player.dialog.attachment_data[$(count)].list[0]
$data remove storage toisarm:temp this_player.dialog.attachment_data[$(count)].list[0]
$execute if data storage toisarm:temp this_player.dialog.attachment_data[$(count)].list[0] run return run function toisarm:dialog/show_attachments/with_index/ with storage toisarm:dialog temp
$function toisarm:dialog/show_attachments/with_index/add_remove_button/ with storage toisarm:temp this_player.dialog.attachment_data[$(count)]
data modify storage toisarm:temp this_player.dialog.attachment_item_slot set from storage toisarm:dialog attachment_item_slot
execute if data storage toisarm:temp this_player.dialog.attachment_item_slot[] run return 0
data modify storage toisarm:temp this_player.dialog.attachment_item_slot append value {Slot:0b,components:{"minecraft:custom_data":{toisarm:{}}}}
$data modify storage toisarm:temp this_player.dialog.attachment_item_slot[0].components."minecraft:custom_data".toisarm.slot set from storage toisarm:temp this_player.dialog.attachment_data[$(count)].slot
