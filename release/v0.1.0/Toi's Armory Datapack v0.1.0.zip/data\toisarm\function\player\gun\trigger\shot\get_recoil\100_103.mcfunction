execute if score @s toisarm.recoil.pattern_index matches 100..101 run function toisarm:player/gun/trigger/shot/get_recoil/100_101
execute if score @s toisarm.recoil.pattern_index matches 102..103 run function toisarm:player/gun/trigger/shot/get_recoil/102_103
