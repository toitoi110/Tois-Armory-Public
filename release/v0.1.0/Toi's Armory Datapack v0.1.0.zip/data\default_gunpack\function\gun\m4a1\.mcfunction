data modify storage toisarm:import gun append value \
{\
    "id": "m4a1",\
    "display_name":"M4A1",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"SEMI","value":2}],\
        "ammo_type": "5.56x45mm",\
        "ammo_capacity": 30,\
        "ammo_count": 30,\
        "chamber": 1,\
        "round_per_minute": 800,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.5.56x45mm",\
        "trail_id": "trail.default_gunpack.medium",\
        "bullet_velocity": 30,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.005,\
        "damage_by_distance": [\
            {"distance":20,"damage":4.5,"crit_damage":5.8},\
            {"distance":55,"damage":4.1,"crit_damage":5.3},\
            {"distance":70,"damage":3.7,"crit_damage":4.8},\
            {"distance":120,"damage":3.5,"crit_damage":4.5},\
        ],\
        "max_range": 125,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.225,0.9],\
        "trail_offset": [-0.12,-0.285,1.2],\
        \
        "reload_time": 38,\
        "empty_reload_time": 54,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 25,\
        "swap_time": 12,\
        "ads_time": 8,\
        "end_ads_time": -1,\
        "sprint_time": 6,\
        "end_sprint_time": 6,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 1,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 87,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.28,\
        "bloom_max": 120,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.85,\
        "sway_yaw": 1.7,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.05,\
        "shake_pitch": -0.07,\
        "shake_yaw_random": 0.15,\
        "shake_pitch_random": 0.02,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.2, "pitch": -1.1},\
            {"yaw": 0.19, "pitch": -1.15},\
            {"yaw": 0.175, "pitch": -1.14},\
            {"yaw": 0.15, "pitch": -1.12},\
            {"yaw": 0.12, "pitch": -1.1},\
            {"yaw": -0.05, "pitch": -1.0},\
            {"yaw": -0.15, "pitch": -0.9},\
            {"yaw": -0.2, "pitch": -0.82},\
            {"yaw": -0.05, "pitch": -0.7},\
            {"yaw": -0.12, "pitch": -0.56},\
            {"yaw": -0.13, "pitch": -0.47},\
            {"yaw": -0.15, "pitch": -0.45},\
            {"yaw": -0.17, "pitch": -0.46},\
            {"yaw": -0.19, "pitch": -0.56},\
            {"yaw": -0.2, "pitch": -0.78},\
            {"yaw": -0.19, "pitch": -0.9},\
            {"yaw": -0.15, "pitch": -1.12},\
            {"yaw": -0.14, "pitch": -1.25},\
            {"yaw": -0.05, "pitch": -1.32},\
            {"yaw": 0.05, "pitch": -1.23},\
            {"yaw": 0.1, "pitch": -1.05},\
            {"yaw": 0.12, "pitch": -0.97},\
            {"yaw": 0.18, "pitch": -0.93, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 4.15,\
        "pitch_recoil_multiplier":1.15,\
        "recoil_apply_tick": 1,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/m4a1/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/m4a1/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/m4a1/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/m4a1/reload",\
            "duration": 136,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 10},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.8 0", "time": 49},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 83},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 127},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/m4a1/empty_reload",\
            "duration": 194,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.1 0","time": 25},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 2 0","time": 64},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 2 0","time": 85},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.1 0","time": 136},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 190},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/m4a1/bolt_action",\
            "duration": 76,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.1 0","time": 25},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/m4a1/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/m4a1/swap",\
            "duration": 71,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.7 0","time": 62},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.35 1.55 0","time": 62},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/m4a1/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/m4a1/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
            {id:"eotech_xps2",cmd:"eotech_xps2",modifier:[\
                {entry:"state.ads_time",operation:"add",value:1},\
            ]}\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}