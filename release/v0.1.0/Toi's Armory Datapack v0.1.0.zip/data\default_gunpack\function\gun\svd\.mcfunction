data modify storage toisarm:import gun append value \
{\
    "id": "svd",\
    "display_name":"SVD",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"SEMI","value":2}],\
        "ammo_type": "7.62x54mmR",\
        "ammo_capacity": 10,\
        "ammo_count": 10,\
        "chamber": 1,\
        "round_per_minute": 260,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.7.62x54mmr",\
        "trail_id": "trail.default_gunpack.large",\
        "bullet_velocity": 22,\
        "bullet_drag": 0.1,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.006,\
        "damage_by_distance": [\
            {"distance":12,"damage":8.5,"crit_damage":11},\
            {"distance":35,"damage":8.35,"crit_damage":11.21},\
            {"distance":80,"damage":8.15,"crit_damage":10.6},\
            {"distance":400,"damage":7.9,"crit_damage":10.2},\
        ],\
        "max_range": 400,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.17,1.2],\
        "trail_offset": [-0.12,-0.23,1.5],\
        \
        "reload_time": 51,\
        "empty_reload_time": 76,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 28,\
        "swap_time": 26,\
        "ads_time": 10,\
        "end_ads_time": -1,\
        "sprint_time": 9,\
        "end_sprint_time": 9,\
        \
        "firing_anim": 7,\
        "bolt_move_anim": 0,\
        "bolt_hold_open": 0,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 110,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.41,\
        "bloom_max": 60,\
        "bloom_decay": 11,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.7,\
        "sway_yaw": 2.0,\
        "sway_pitch": 1.3,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0,\
        "shake_pitch": -0.58,\
        "shake_yaw_random": 0.18,\
        "shake_pitch_random": 0.06,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": -0.66, "pitch": -2.6},\
            {"yaw": -0.58, "pitch": -2.73},\
            {"yaw": 0.63, "pitch": -2.46},\
            {"yaw": 0.64, "pitch": -2.56},\
            {"yaw": 0.71, "pitch": -2.76},\
            {"yaw": 0.63, "pitch": -2.6, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 1.2,\
        "pitch_recoil_multiplier": 2.6,\
        "recoil_apply_tick": 4,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/svd/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/svd/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/svd/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/svd/reload",\
            "duration": 206,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 12},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.25 0", "time": 92},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.45 0", "time": 128},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 201},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/svd/empty_reload",\
            "duration": 291,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 28},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0","time": 69},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.35 0","time": 180},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.65 0.85 0","time": 232},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 273},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/svd/bolt_action",\
            "duration": 76,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.55 0.85 0","time": 24},\
            ]\
        },\
        "swap":{\
            "pass": "toisarm:gun/svd/swap",\
            "duration": 91,\
            "commands":[\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.4 0","time": 78},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/svd/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/svd/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
            {id:"pso_1",cmd:"pso_1",modifier:[\
                {entry:"state.zoom",operation:"replace",value:2},\
                {entry:"state.zoom_ads_progress",operation:"replace",value:0.8},\
                {entry:"state.ads_time",operation:"add",value:2},\
                {entry:"state.trail_pos[2]",operation:"replace",value:0}\
            ]}\
        ]},\
        {slot:"barrel", list: [\
            {id:"svd_long_barrel",cmd:"long",modifier:[\
                {entry:"state.ads_time",operation:"add",value:1},\
                {entry:"state.end_sprint_time",operation:"add_base_scale",value:0.1},\
                {entry:"state.pitch_recoil_multiplier",operation:"add_base_scale",value:-0.15},\
                {entry:"state.yaw_recoil_multiplier",operation:"add_base_scale",value:-0.2}\
            ]}\
        ]},\
        {slot:"muzzle", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"handguard", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
    ]\
}