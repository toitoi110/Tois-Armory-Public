scoreboard players operation @s toisarm.animation = @s toisarm.state.swap
scoreboard players operation @s toisarm.animation -= @s toisarm.timer.swap
execute unless score @s toisarm.animation_id matches 8 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 8
