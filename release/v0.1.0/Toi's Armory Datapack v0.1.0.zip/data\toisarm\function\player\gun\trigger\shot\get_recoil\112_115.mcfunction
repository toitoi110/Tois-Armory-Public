execute if score @s toisarm.recoil.pattern_index matches 112..113 run function toisarm:player/gun/trigger/shot/get_recoil/112_113
execute if score @s toisarm.recoil.pattern_index matches 114..115 run function toisarm:player/gun/trigger/shot/get_recoil/114_115
