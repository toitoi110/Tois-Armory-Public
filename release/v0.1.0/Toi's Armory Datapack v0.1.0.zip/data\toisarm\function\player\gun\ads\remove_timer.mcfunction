    execute if entity @s[scores={toisarm.input.change_fire_mode=..0},tag=!toisarm.input.reload,tag=toisarm.input.lclick] if score @s toisarm.timer.bolt_action_delay matches -1 run return 0
    execute if score @s toisarm.timer.bolt_action_delay matches 0.. if score @s toisarm.timer.bolt_action_delay > @s toisarm.state.end_ads_time run return 0
    scoreboard players operation @s toisarm.timer.ads -= @s toisarm.state.end_ads
    scoreboard players set @s toisarm.after_sprint_ads_speed 0
