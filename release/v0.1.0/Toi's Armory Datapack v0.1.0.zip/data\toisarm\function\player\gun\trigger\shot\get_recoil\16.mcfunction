execute store result score @s _ run data get storage toisarm:temp this_player.data.gun.state.recoil_pattern[16].yaw 100
scoreboard players operation @s _ *= @s toisarm.state.yaw_recoil_multiplier
scoreboard players operation @s _ /= 1000 num
scoreboard players operation @s toisarm.recoil.total_yaw += @s _
execute store result score @s _ run data get storage toisarm:temp this_player.data.gun.state.recoil_pattern[16].pitch 100
scoreboard players operation @s _ *= @s toisarm.state.pitch_recoil_multiplier
scoreboard players operation @s _ /= 1000 num
scoreboard players operation @s toisarm.recoil.total_pitch += @s _
execute if data storage toisarm:temp this_player.data.gun.state.recoil_pattern[16].repeat run scoreboard players set @s toisarm.recoil.pattern_index -1
