execute if score @s toisarm.recoil.pattern_index matches 10 run function toisarm:player/gun/trigger/shot/get_recoil/10
execute if score @s toisarm.recoil.pattern_index matches 11 run function toisarm:player/gun/trigger/shot/get_recoil/11
