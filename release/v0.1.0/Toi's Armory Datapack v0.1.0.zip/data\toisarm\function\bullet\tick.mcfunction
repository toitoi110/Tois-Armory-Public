    tag @s add BULLET
    execute unless entity @s[tag=toisarm.bullet.trail_fixed] run return run function toisarm:bullet/first_tick/
    execute store result score @s toisarm.util.tp_z store result score @s toisarm.bullet.velocity_remaining run scoreboard players operation @s toisarm.bullet.velocity -= @s toisarm.bullet.drag
    execute store result score @s toisarm.util.tp_y run scoreboard players operation @s toisarm.bullet.gravity += @s toisarm.bullet.weight
    scoreboard players set #raycast.dm toisarm.util.raycast 10
    scoreboard players operation #raycast.dm toisarm.util.raycast *= @s toisarm.bullet.velocity
    function toisarm:bullet/raycast
    execute if entity @n[type=marker,tag=ENTRY_POINT] run function toisarm:bullet/hit_ground
    execute if score @s toisarm.bullet.velocity_remaining matches 30.. positioned ^ ^ ^0.30 run function toisarm:bullet/move/
    execute if entity @s[tag=HIT_ENTITY] run function toisarm:bullet/damage with entity @s data
    execute if entity @n[type=marker,tag=ENTRY_POINT] run function toisarm:bullet/impact
    execute if entity @s[tag=OUT_OF_RANGE] run return run function toisarm:util/kill/
    tag @s remove BULLET
    data remove storage toisarm:temp bullet
