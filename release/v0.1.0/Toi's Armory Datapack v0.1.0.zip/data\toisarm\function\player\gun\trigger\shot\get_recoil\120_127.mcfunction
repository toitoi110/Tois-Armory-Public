execute if score @s toisarm.recoil.pattern_index matches 120..123 run function toisarm:player/gun/trigger/shot/get_recoil/120_123
execute if score @s toisarm.recoil.pattern_index matches 124..127 run function toisarm:player/gun/trigger/shot/get_recoil/124_127
