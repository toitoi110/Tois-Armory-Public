attribute @s minecraft:movement_speed modifier add toisarm:sprint_blocked -0.25 add_multiplied_total
tag @s add toisarm.sprint_blocked_sprinting
