tag @s add HIT
execute positioned ~ ~0.45 ~ unless entity @s[dx=0] run tag @s add CRIT_HIT
tag @n[tag=BULLET] add HIT_ENTITY
