$function toisarm:dialog/get_gun_with_id/with_trigger_count/with_id/ with storage toisarm:dialog gun_data[$(count)]
