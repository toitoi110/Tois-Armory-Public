execute if score @s toisarm.recoil.pattern_index matches 112..119 run function toisarm:player/gun/trigger/shot/get_recoil/112_119
execute if score @s toisarm.recoil.pattern_index matches 120..127 run function toisarm:player/gun/trigger/shot/get_recoil/120_127
