attribute @s minecraft:movement_speed modifier remove toisarm:sprint_blocked
tag @s remove toisarm.sprint_blocked_sprinting
