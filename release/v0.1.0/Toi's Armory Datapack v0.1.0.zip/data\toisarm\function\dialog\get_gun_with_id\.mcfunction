data modify storage toisarm:dialog gun_list set from storage toisarm:temp this_player.dialog.gun_list
data modify storage toisarm:dialog gun_data set from storage toisarm:temp this_player.dialog.gun_data
data modify storage toisarm:dialog gun set from storage toisarm:temp this_player.dialog.gun
data remove storage toisarm:temp this_player.dialog.gun
execute store result storage toisarm:dialog temp.count int 1 run scoreboard players get @s toisarm.trigger.get_gun
function toisarm:dialog/get_gun_with_id/with_trigger_count/ with storage toisarm:dialog temp
scoreboard players set @s toisarm.trigger.op_input 1
data remove storage toisarm:dialog temp
scoreboard players set @s toisarm.trigger.get_gun -1
