execute unless entity @e[type=item,tag=toisarm.casing] run return 0
execute as @e[tag=toisarm.casing] at @s run function toisarm:casing/tick
schedule function toisarm:casing/schedule 1t replace
