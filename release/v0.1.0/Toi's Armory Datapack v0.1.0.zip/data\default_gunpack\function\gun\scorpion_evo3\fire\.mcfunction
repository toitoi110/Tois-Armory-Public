#data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
#{id:"minecraft:item.shield.block",volume:0.175,pitch:0.5},\
#{id:"minecraft:item.flintandsteel.use",volume:0.4,pitch:1.25},\
#{id:"minecraft:entity.hoglin.step",volume:0.6,pitch:1.2},\
#{id:"minecraft:entity.firework_rocket.blast",volume:0.2,pitch:0.45},\
#]}
#execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
#data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
#{id:"minecraft:block.copper_door.close",volume:0.25,pitch:1.1},\
#{id:"minecraft:block.wooden_door.open",volume:0.2,pitch:1.7},\
#]}

data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:item.shield.block",volume:0.15,pitch:1.35},\
{id:"minecraft:item.flintandsteel.use",volume:0.3,pitch:1.2},\
{id:"minecraft:entity.hoglin.step",volume:0.7,pitch:1.235},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.25,pitch:0.4},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
{id:"minecraft:block.wooden_door.close",volume:0.6,pitch:1.9},\
{id:"minecraft:block.wooden_door.open",volume:0.2,pitch:1.8},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage 
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.42,0.08,0],item_model:"toisarm:other/small_casing",offset:[-0.2,-0.14,0.2],pos:[-0.15,-0.22,0.52]}
function toisarm:util/ejection/ 
execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{toisarm:{state:{chamber:0b}}}}}}] anchored eyes positioned ^-0.1 ^ ^0.1 run playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.4 1.4 0
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 5 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 1 force @a
