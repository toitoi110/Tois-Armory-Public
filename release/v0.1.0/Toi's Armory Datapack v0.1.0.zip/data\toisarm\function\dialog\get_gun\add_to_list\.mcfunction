$data modify storage toisarm:dialog gun_list append value {label:{text:"$(display_name)"},width:150,action:{type:"minecraft:run_command",command:"trigger toisarm.trigger.get_gun set $(count)"}}
$data modify storage toisarm:dialog gun_data append value {id:"$(id)"}
data remove storage toisarm:dialog gun[0]
execute store result storage toisarm:dialog gun[0].count int 1 run scoreboard players add #toisarm.temp _ 1
execute if data storage toisarm:dialog gun[0] run function toisarm:dialog/get_gun/add_to_list/ with storage toisarm:dialog gun[0]
