execute if score @s toisarm.recoil.pattern_index matches 114 run function toisarm:player/gun/trigger/shot/get_recoil/114
execute if score @s toisarm.recoil.pattern_index matches 115 run function toisarm:player/gun/trigger/shot/get_recoil/115
