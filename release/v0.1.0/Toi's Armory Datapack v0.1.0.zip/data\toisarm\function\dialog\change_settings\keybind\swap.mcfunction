execute if score @s toisarm.settings.keybind.swap matches 2.. run return run scoreboard players set @s toisarm.settings.keybind.swap 1
scoreboard players add @s toisarm.settings.keybind.swap 1
