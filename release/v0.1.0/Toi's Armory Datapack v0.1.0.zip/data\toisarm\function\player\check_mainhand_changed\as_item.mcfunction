execute on origin unless entity @s[predicate=toisarm:match_id] run return 0
tag @s add MATCH_ID
tag @s add toisarm.checked_item
