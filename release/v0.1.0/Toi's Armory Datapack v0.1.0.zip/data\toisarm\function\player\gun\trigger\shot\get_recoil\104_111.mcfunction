execute if score @s toisarm.recoil.pattern_index matches 104..107 run function toisarm:player/gun/trigger/shot/get_recoil/104_107
execute if score @s toisarm.recoil.pattern_index matches 108..111 run function toisarm:player/gun/trigger/shot/get_recoil/108_111
