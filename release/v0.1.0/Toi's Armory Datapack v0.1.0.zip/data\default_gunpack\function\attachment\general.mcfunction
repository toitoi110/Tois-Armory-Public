# 汎用
data modify storage toisarm:import attachment append value \
{\
    "id":"eotech_xps2",\
    "slot": "sight",\
    "item_model":"minecraft:spyglass",\
    "display_name":{"translate": "item.toisarm.eotech_xps2","fallback": "Eotech XPS2"},\
}
data modify storage toisarm:import attachment append value \
{\
    "id":"2_stage_suppressor",\
    "slot": "muzzle",\
    "item_model":"minecraft:stick",\
    "display_name":{"translate": "item.toisarm.2_stage_suppressor","fallback": "2 Stage Suppressor"},\
}
data modify storage toisarm:import attachment append value \
{\
    "id":"pso_1",\
    "slot": "sight",\
    "item_model":"minecraft:spyglass",\
    "display_name":{"translate": "item.toisarm.pso_1","fallback": "PSO-1"},\
}
data modify storage toisarm:import attachment append value \
{\
    "id":"9x39mm_30round_magazine",\
    "slot": "magazine",\
    "item_model":"minecraft:iron_ingot",\
    "display_name":{"translate": "item.toisarm.9x39mm_30round_magazine","fallback": "9x39mm 30round Magazine"},\
}

# デバッグ
data modify storage toisarm:import attachment append value \
{\
    "id":"infinity_magazine",\
    "slot": "magazine",\
    "item_model":"minecraft:iron_ingot",\
    "display_name":{"translate": "item.toisarm.infinity_magazine","fallback": "Infinity Magazine"},\
}

data modify storage toisarm:import attachment append value \
{\
    "id":"no_recoil_grip",\
    "slot": "rear_grip",\
    "item_model":"minecraft:stick",\
    "display_name":{"translate": "item.toisarm.no_recoil_grip","fallback": "SUPER NO RECOIL GRIP"},\
}
