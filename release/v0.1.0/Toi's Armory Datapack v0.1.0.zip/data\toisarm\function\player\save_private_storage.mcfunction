$data modify storage toisarm:private $(id) set from storage toisarm:temp this_player
