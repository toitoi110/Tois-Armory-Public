    execute if score @s toisarm.timer.swap matches 0.. run return run function toisarm:player/gun/animation/get/swap/
    execute if score @s toisarm.timer.ads matches 1.. run return run function toisarm:player/gun/animation/get/ads/
    execute if score @s toisarm.timer.sprint matches 1.. run return run function toisarm:player/gun/animation/get/sprint/
    execute if score @s toisarm.timer.reload_loop matches 0.. run return run function toisarm:player/gun/animation/get/reload_loop/
    execute if score @s toisarm.timer.empty_reload matches 0.. run return run function toisarm:player/gun/animation/get/empty_reload/
    execute if score @s toisarm.timer.reload matches 0.. run return run function toisarm:player/gun/animation/get/reload/
    execute if score @s toisarm.timer.bolt_action matches 0.. run return run function toisarm:player/gun/animation/get/bolt_action/
    execute if score @s toisarm.timer.change_fire_mode matches 0.. run return run function toisarm:player/gun/animation/get/change_fire_mode/
    execute positioned 0.0 0.0 0.0 run function toisarm:player/gun/animation/get/idle/
