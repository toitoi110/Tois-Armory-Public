execute if score @s toisarm.recoil.pattern_index matches 116..117 run function toisarm:player/gun/trigger/shot/get_recoil/116_117
execute if score @s toisarm.recoil.pattern_index matches 118..119 run function toisarm:player/gun/trigger/shot/get_recoil/118_119
