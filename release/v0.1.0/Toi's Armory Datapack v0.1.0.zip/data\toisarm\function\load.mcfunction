    tellraw @a "ロード完了"
    gamerule max_command_forks 2147483647
    execute in minecraft:overworld run forceload add -1 -1 1 1
    scoreboard objectives add _ dummy
    scoreboard objectives add num dummy
    scoreboard objectives add toisarm.id dummy
    scoreboard objectives add toisarm.food dummy
    scoreboard objectives add toisarm.prev_food dummy
    scoreboard objectives add toisarm.foodsat_remove_queue dummy
    scoreboard objectives add toisarm.exhaustion dummy
    scoreboard objectives add toisarm.exhaustion_remaining dummy
    scoreboard objectives add toisarm.sprint_distance minecraft.custom:minecraft.sprint_one_cm
    scoreboard objectives add toisarm.drop minecraft.custom:minecraft.drop
    scoreboard objectives add toisarm.selected_slot dummy
    scoreboard objectives add toisarm.ads_progress dummy
    scoreboard objectives add toisarm.after_sprint_ads_speed dummy
    scoreboard objectives add toisarm.chamber dummy
    scoreboard objectives add toisarm.ammo_remaining dummy
    scoreboard objectives add toisarm.fire_rate dummy
    scoreboard objectives add toisarm.max_accuracy dummy
    scoreboard objectives add toisarm.min_accuracy dummy
    scoreboard objectives add toisarm.accuracy dummy
    scoreboard objectives add toisarm.accuracy_value dummy
    scoreboard objectives add toisarm.shootable dummy
    scoreboard objectives add toisarm.animation_changed dummy
    scoreboard objectives add toisarm.animation_interrupted dummy
    scoreboard objectives add toisarm.input.change_fire_mode dummy
    scoreboard objectives add toisarm.fire_mode dummy
    scoreboard objectives add toisarm.distance dummy
    scoreboard objectives add toisarm.smooth_diff_distance dummy
    scoreboard objectives add toisarm.smooth_diff_y dummy
    scoreboard objectives add toisarm.smooth_diff_p dummy
    scoreboard objectives add toisarm.accuracy dummy
    scoreboard objectives add toisarm.bloom dummy
    scoreboard objectives add toisarm.bloom_decay dummy
    scoreboard objectives add toisarm.sway_speed dummy
    scoreboard objectives add toisarm.sway_yaw_progress dummy
    scoreboard objectives add toisarm.sway_pitch_progress dummy
    scoreboard objectives add toisarm.shake_yaw dummy
    scoreboard objectives add toisarm.shake_pitch dummy
    scoreboard objectives add toisarm.shake_yaw_flip dummy
    scoreboard objectives add toisarm.shake_yaw_decay dummy
    scoreboard objectives add toisarm.shake_pitch_decay dummy
    scoreboard objectives add toisarm.shake_yaw_decaying dummy
    scoreboard objectives add toisarm.shake_pitch_decaying dummy
    scoreboard objectives add toisarm.shake_yaw_decay_remain dummy
    scoreboard objectives add toisarm.shake_pitch_decay_remain dummy
    scoreboard objectives add toisarm.recoil.total_yaw dummy
    scoreboard objectives add toisarm.recoil.total_pitch dummy
    scoreboard objectives add toisarm.recoil.apply_yaw dummy
    scoreboard objectives add toisarm.recoil.apply_pitch dummy
    scoreboard objectives add toisarm.recoil.progress_per_tick dummy
    scoreboard objectives add toisarm.recoil.progress dummy
    scoreboard objectives add toisarm.recoil.pattern_index dummy
    scoreboard objectives add toisarm.rotate_yaw_queue dummy
    scoreboard objectives add toisarm.rotate_pitch_queue dummy
    scoreboard objectives add toisarm.impact_mark.color dummy
    scoreboard objectives add toisarm.impact_mark.r dummy
    scoreboard objectives add toisarm.impact_mark.g dummy
    scoreboard objectives add toisarm.impact_mark.b dummy
    scoreboard objectives add toisarm.impact_mark.alpha dummy
    scoreboard objectives add toisarm.impact_mark.age dummy
    scoreboard objectives add toisarm.settings.keybind.drop dummy
    scoreboard objectives add toisarm.settings.keybind.swap dummy
    scoreboard objectives add toisarm.settings.reload_disable_ads dummy
    scoreboard objectives add toisarm.settings.rotate_comp.enable dummy
    scoreboard objectives add toisarm.settings.rotate_comp.rate dummy
    scoreboard objectives add toisarm.settings.rotate_comp.noise_sup dummy
    scoreboard objectives add toisarm.settings.rotate_comp.max dummy
    scoreboard objectives add toisarm.settings.rotate_comp.enable_semi dummy
    scoreboard objectives add toisarm.settings.move_comp.enable dummy
    scoreboard objectives add toisarm.settings.move_comp.rate dummy
    scoreboard objectives add toisarm.trigger.close trigger
    scoreboard objectives add toisarm.trigger.input trigger
    scoreboard objectives add toisarm.trigger.op_input trigger
    scoreboard objectives add toisarm.trigger.get_gun trigger
    scoreboard objectives add toisarm.trigger.get_attachment trigger
    scoreboard objectives add toisarm.trigger.change_attachment_slot trigger
    scoreboard objectives add toisarm.trigger.operate_attachment trigger
    scoreboard objectives add toisarm.trigger.settings.keybind.swap trigger
    scoreboard objectives add toisarm.trigger.settings.keybind.drop trigger
    scoreboard objectives add toisarm.trigger.settings.reload_disable_ads trigger
    scoreboard objectives add toisarm.trigger.settings.rotate_comp.enable trigger
    scoreboard objectives add toisarm.trigger.settings.rotate_comp.rate trigger
    scoreboard objectives add toisarm.trigger.settings.rotate_comp.noise_sup trigger
    scoreboard objectives add toisarm.trigger.settings.rotate_comp.max trigger
    scoreboard objectives add toisarm.trigger.settings.rotate_comp.enable_semi trigger
    scoreboard objectives add toisarm.trigger.settings.move_comp.enable trigger
    scoreboard objectives add toisarm.trigger.settings.move_comp.rate trigger
    scoreboard objectives add toisarm.trigger.settings.reset trigger
    scoreboard objectives add toisarm.util.rotate_yaw dummy
    scoreboard objectives add toisarm.util.rotate_pitch dummy
    scoreboard objectives add toisarm.util.tp_x dummy
    scoreboard objectives add toisarm.util.tp_y dummy
    scoreboard objectives add toisarm.util.tp_z dummy
    scoreboard objectives add toisarm.util.light_index dummy
    scoreboard objectives add toisarm.util.light_level dummy
    scoreboard objectives add toisarm.util.distance dummy
    scoreboard objectives add toisarm.util.raycast dummy
    scoreboard objectives add toisarm.util.cd_sound dummy
    scoreboard objectives add toisarm.timer.sliding dummy
    scoreboard objectives add toisarm.timer.firing dummy
    scoreboard objectives add toisarm.timer.firing_anim dummy
    scoreboard objectives add toisarm.timer.firing_anim_delay dummy
    scoreboard objectives add toisarm.timer.bolt_move_anim dummy
    scoreboard objectives add toisarm.timer.change_fire_mode dummy
    scoreboard objectives add toisarm.timer.trigger dummy
    scoreboard objectives add toisarm.timer.reload dummy
    scoreboard objectives add toisarm.timer.reload_loop dummy
    scoreboard objectives add toisarm.timer.bolt_action_delay dummy
    scoreboard objectives add toisarm.timer.bolt_action dummy
    scoreboard objectives add toisarm.timer.swap dummy
    scoreboard objectives add toisarm.timer.ads dummy
    scoreboard objectives add toisarm.timer.sprint dummy
    scoreboard objectives add toisarm.timer.empty_reload dummy
    scoreboard objectives add toisarm.timer.reset_recoil_pattern dummy
    scoreboard objectives add toisarm.timer.recoil_apply_tick dummy
    scoreboard objectives add toisarm.state.default_change_fire_mode dummy
    scoreboard objectives add toisarm.state.change_fire_mode dummy
    scoreboard objectives add toisarm.state.ads dummy
    scoreboard objectives add toisarm.state.end_ads dummy
    scoreboard objectives add toisarm.state.end_ads_time dummy
    scoreboard objectives add toisarm.state.sprint dummy
    scoreboard objectives add toisarm.state.end_sprint dummy
    scoreboard objectives add toisarm.state.swap dummy
    scoreboard objectives add toisarm.state.reload dummy
    scoreboard objectives add toisarm.state.empty_reload dummy
    scoreboard objectives add toisarm.state.prioritize_bolt_action dummy
    scoreboard objectives add toisarm.state.reload_loop dummy
    scoreboard objectives add toisarm.state.reload_loop_success dummy
    scoreboard objectives add toisarm.state.reload_loop_start dummy
    scoreboard objectives add toisarm.state.empty_reload_loop_start dummy
    scoreboard objectives add toisarm.state.bolt_action_delay dummy
    scoreboard objectives add toisarm.state.bolt_action dummy
    scoreboard objectives add toisarm.state.zoom dummy   
    scoreboard objectives add toisarm.state.zoom_ads_progress dummy   
    scoreboard objectives add toisarm.state.firing_anim dummy
    scoreboard objectives add toisarm.state.firing_anim_delay dummy
    scoreboard objectives add toisarm.state.bolt_move_anim dummy
    scoreboard objectives add toisarm.state.bolt_hold_open dummy
    scoreboard objectives add toisarm.state.projectiles_per_shot dummy
    scoreboard objectives add toisarm.state.rpm dummy
    scoreboard objectives add toisarm.state.fire_rate dummy
    scoreboard objectives add toisarm.state.chamber dummy
    scoreboard objectives add toisarm.state.manual_bolt_action dummy
    scoreboard objectives add toisarm.state.ammo_capacity dummy
    scoreboard objectives add toisarm.state.modes_index dummy
    scoreboard objectives add toisarm.state.modes_array_length dummy
    scoreboard objectives add toisarm.state.yaw_recoil_multiplier dummy
    scoreboard objectives add toisarm.state.pitch_recoil_multiplier dummy
    scoreboard objectives add toisarm.state.recoil_apply_tick dummy
    scoreboard objectives add toisarm.state.accuracy_ads dummy
    scoreboard objectives add toisarm.state.accuracy_idle dummy
    scoreboard objectives add toisarm.state.accuracy_multiplier_move dummy
    scoreboard objectives add toisarm.state.bloom_increase_rate dummy
    scoreboard objectives add toisarm.state.bloom_max dummy
    scoreboard objectives add toisarm.state.bloom_decay dummy
    scoreboard objectives add toisarm.state.move_sway dummy
    scoreboard objectives add toisarm.state.sway_multiplier dummy
    scoreboard objectives add toisarm.state.sway_yaw dummy
    scoreboard objectives add toisarm.state.sway_pitch dummy
    scoreboard objectives add toisarm.state.shake_multiplier dummy
    scoreboard objectives add toisarm.state.shake_yaw dummy
    scoreboard objectives add toisarm.state.shake_pitch dummy
    scoreboard objectives add toisarm.state.shake_yaw_random dummy
    scoreboard objectives add toisarm.state.shake_pitch_random dummy
    scoreboard objectives add toisarm.state.shake_yaw_decay dummy
    scoreboard objectives add toisarm.state.shake_pitch_decay dummy
    scoreboard objectives add toisarm.animation dummy
    scoreboard objectives add toisarm.animation_id dummy
    scoreboard objectives add toisarm.animation.ads dummy
    scoreboard objectives add toisarm.animation.sprint dummy
    scoreboard objectives add toisarm.animation.reload dummy
    scoreboard objectives add toisarm.animation.empty_reload dummy
    scoreboard objectives add toisarm.animation.reload_loop dummy
    scoreboard objectives add toisarm.animation.change_fire_mode dummy
    scoreboard objectives add toisarm.animation.bolt_action dummy
    scoreboard objectives add toisarm.animation.swap dummy
    scoreboard objectives add toisarm.animation.inspect dummy
    scoreboard objectives add toisarm.bullet.owner dummy
    scoreboard objectives add toisarm.bullet.velocity_remaining dummy
    scoreboard objectives add toisarm.bullet.distance_traveled dummy
    scoreboard objectives add toisarm.bullet.distance_damage_index dummy
    scoreboard objectives add toisarm.bullet.distance_damage_max_index dummy
    scoreboard objectives add toisarm.bullet.distance dummy
    scoreboard objectives add toisarm.bullet.shots dummy
    scoreboard objectives add toisarm.bullet.max_range dummy
    scoreboard objectives add toisarm.bullet.velocity dummy
    scoreboard objectives add toisarm.bullet.gravity dummy
    scoreboard objectives add toisarm.bullet.weight dummy
    scoreboard objectives add toisarm.bullet.drag dummy
    scoreboard objectives add toisarm.bullet.penetration dummy
    scoreboard objectives add toisarm.bullet.trail_offset_x dummy
    scoreboard objectives add toisarm.bullet.trail_offset_y dummy
    scoreboard objectives add toisarm.bullet.trail_offset_z dummy
    scoreboard players set -10000000 num -10000000
    scoreboard players set -200 num -200
    scoreboard players set -108 num -108
    scoreboard players set -100 num -100
    scoreboard players set -91 num -91
    scoreboard players set -67 num -67
    scoreboard players set -46 num -46
    scoreboard players set -29 num -29
    scoreboard players set -1 num -1
    scoreboard players set 0 num 0
    scoreboard players set 1 num 1
    scoreboard players set 2 num 2
    scoreboard players set 3 num 3
    scoreboard players set 4 num 4
    scoreboard players set 5 num 5
    scoreboard players set 6 num 6
    scoreboard players set 7 num 7
    scoreboard players set 8 num 8
    scoreboard players set 9 num 9
    scoreboard players set 10 num 10
    scoreboard players set 25 num 25
    scoreboard players set 40 num 40
    scoreboard players set 60 num 60
    scoreboard players set 92 num 92
    scoreboard players set 95 num 95
    scoreboard players set 100 num 100
    scoreboard players set 160 num 160
    scoreboard players set 120 num 120
    scoreboard players set 200 num 200
    scoreboard players set 250 num 250
    scoreboard players set 256 num 256
    scoreboard players set 300 num 300
    scoreboard players set 500 num 500
    scoreboard players set 1000 num 1000
    scoreboard players set 10000 num 10000
    scoreboard players set 65536 num 65536
    scoreboard players set 100000 num 100000
    scoreboard players set 625000 num 625000
    scoreboard players set 1000000 num 1000000
    scoreboard players set 10000000 num 10000000
    scoreboard players set 16777216 num 16777216
    scoreboard players set 2147483647 num 2147483647
    data modify storage toisarm:temp num.1000 set value 1000
    scoreboard players set #toisarm.fire_mode.auto _ 1
    scoreboard players set #toisarm.fire_mode.semi _ 2
    scoreboard players set #toisarm.fire_mode.3_burst _ 3
    scoreboard players set #toisarm.fire_mode.4_burst _ 4
    schedule function toisarm:import 1t replace
