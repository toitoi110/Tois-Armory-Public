execute if score @s toisarm.recoil.pattern_index matches 126 run function toisarm:player/gun/trigger/shot/get_recoil/126
execute if score @s toisarm.recoil.pattern_index matches 127 run function toisarm:player/gun/trigger/shot/get_recoil/127
