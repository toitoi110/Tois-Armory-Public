
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:entity.breeze.wind_burst",volume:0.1,pitch:0.95},\
{id:"minecraft:block.wooden_trapdoor.open",volume:0.2,pitch:0.9},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.22,pitch:0.2},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
{id:"minecraft:block.netherite_block.place",volume:0.7,pitch:0.4},\
{id:"minecraft:entity.hoglin.step",volume:0.65,pitch:1.1},\
{id:"minecraft:block.wooden_trapdoor.open",volume:0.3,pitch:0.9},\
{id:"minecraft:block.copper_grate.hit",volume:0.5,pitch:1.85},\
{id:"minecraft:block.lever.click",volume:0.12,pitch:1.9},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.37,0.07,-0.08],item_model:"toisarm:other/medium_casing",offset:[-0.2,-0.07,0.1],pos:[-0.2,-0.35,0.55]}
function toisarm:util/ejection/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 2 force @a
