#> default_gunpack:impact_mark/set_color

# ( A * 16777216 ) + ( R * 65536 ) + ( G * 256 ) + B
scoreboard players set @s toisarm.impact_mark.r 255
scoreboard players set @s toisarm.impact_mark.g 90
scoreboard players set @s toisarm.impact_mark.b 0
scoreboard players set @s toisarm.impact_mark.alpha 180

tag @s remove THIS


# 3面検知(6面検知じゃない)なら無効化
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.6} ^ ^ ^0.1 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.65} ^ ^ ^0.2 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.7} ^ ^ ^0.3 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.75} ^ ^ ^0.4 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.8} ^ ^ ^0.5 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.85} ^ ^ ^0.6 0 0 0 0 1 force
#execute rotated as @s run particle dust{color:[0.6,0.6,0.6],scale:0.9} ^ ^ ^0.7 0 0 0 0 1 force

#execute unless block ^ ^ ^-0.015 air run particle minecraft:falling_dust{block_state:andesite} ^ ^ ^0.1 0.05 0.05 0.05 0 1 force

execute unless block ^ ^ ^-0.015 air run particle white_smoke ^ ^ ^0.16 0.16 0.16 0.16 1000000 8 force

tp @s ^ ^ ^0.0005