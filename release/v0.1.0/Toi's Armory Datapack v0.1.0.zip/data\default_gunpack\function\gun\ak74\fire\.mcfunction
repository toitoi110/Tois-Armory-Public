
data modify storage toisarm:sound {} merge value {max_distance:64,sounds:[\
{id:"minecraft:item.shield.block",volume:0.24,pitch:0.75},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.24,pitch:0.7},\
{id:"minecraft:entity.iron_golem.repair",volume:0.195,pitch:0.73},\
{id:"minecraft:entity.hoglin.step",volume:0.4,pitch:0.97},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.06,pitch:0.95}\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:32,sounds:[\
{id:"minecraft:entity.hoglin.step",volume:0.24,pitch:0.8},\
{id:"minecraft:block.iron_trapdoor.close",volume:0.34,pitch:1.8},\
{id:"minecraft:block.stone_button.click_on",volume:0.84,pitch:1.5},\
{id:"minecraft:block.copper_grate.hit",volume:0.54,pitch:1.85},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.43,0.1,-0.05],item_model:"toisarm:other/medium_casing",offset:[-0.12,-0.03,0.05],pos:[-0.25,-0.26,0.5]}
function toisarm:util/ejection/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 2 force @a
