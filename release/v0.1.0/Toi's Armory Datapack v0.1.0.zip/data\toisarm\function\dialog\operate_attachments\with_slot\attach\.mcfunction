data modify entity 0-0-0-0-1ae1e item.components."minecraft:custom_data".toisarm.attachment append from storage toisarm:dialog attachment_item_slot
function toisarm:dialog/operate_attachments/with_slot/attach/clear_item/ with storage toisarm:dialog attachment_item_slot
