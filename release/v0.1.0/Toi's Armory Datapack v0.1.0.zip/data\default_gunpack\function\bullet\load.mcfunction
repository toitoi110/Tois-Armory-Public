
# fireでよくなった
# 特殊な弾を作るときは弾丸のロード時にこのfunctionが呼ばれるので使う
#execute if entity @s[tag=bullet.default_gunpack.12gauge] run return run function default_gunpack:bullet/12gauge/load
#execute if entity @s[tag=bullet.default_gunpack.9x18mm] run return run function default_gunpack:bullet/9x18mm/load
#execute if entity @s[tag=bullet.default_gunpack.9x19mm] run return run function default_gunpack:bullet/9x19mm/load
#execute if entity @s[tag=bullet.default_gunpack.4.6x30mm] run return run function default_gunpack:bullet/4.6x30mm/load
#execute if entity @s[tag=bullet.default_gunpack.45acp] run return run function default_gunpack:bullet/45acp/load
#execute if entity @s[tag=bullet.default_gunpack.5.7x28mm] run return run function default_gunpack:bullet/5.7x28mm/load
#execute if entity @s[tag=bullet.default_gunpack.5.45x39mm] run return run function default_gunpack:bullet/5.45x39mm/load
#execute if entity @s[tag=bullet.default_gunpack.9x39mm] run return run function default_gunpack:bullet/9x39mm/load
#execute if entity @s[tag=bullet.default_gunpack.5.56x45mm] run return run function default_gunpack:bullet/5.56x45mm/load
#execute if entity @s[tag=bullet.default_gunpack.6.8x51mm] run return run function default_gunpack:bullet/6.8x51mm/load
#execute if entity @s[tag=bullet.default_gunpack.7.62x39mm] run return run function default_gunpack:bullet/7.62x39mm/load
#execute if entity @s[tag=bullet.default_gunpack.7.62x51mm] run return run function default_gunpack:bullet/7.62x51mm/load
#execute if entity @s[tag=bullet.default_gunpack.357magnum] run return run function default_gunpack:bullet/357magnum/load
#execute if entity @s[tag=bullet.default_gunpack.7.62x54mmr] run return run function default_gunpack:bullet/7.62x54mmr/load
#execute if entity @s[tag=bullet.default_gunpack.50ae] run return run function default_gunpack:bullet/50ae/load
#execute if entity @s[tag=bullet.default_gunpack.12.7x55mm] run return run function default_gunpack:bullet/12.7x55mm/load
#execute if entity @s[tag=bullet.default_gunpack.50bmg] run return run function default_gunpack:bullet/50bmg/load
