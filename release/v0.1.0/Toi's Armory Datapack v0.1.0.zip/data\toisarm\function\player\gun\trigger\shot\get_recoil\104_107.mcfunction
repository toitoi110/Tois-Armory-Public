execute if score @s toisarm.recoil.pattern_index matches 104..105 run function toisarm:player/gun/trigger/shot/get_recoil/104_105
execute if score @s toisarm.recoil.pattern_index matches 106..107 run function toisarm:player/gun/trigger/shot/get_recoil/106_107
