data modify storage toisarm:import gun append value \
{\
    "id": "uzi",\
    "display_name":"UZI",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"SEMI","value":2}],\
        "ammo_type": ".45acp",\
        "ammo_capacity": 32,\
        "ammo_count": 32,\
        "chamber": -1,\
        "round_per_minute": 600,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.45acp",\
        "trail_id": "trail.default_gunpack.medium",\
        "bullet_velocity": 15,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.004,\
        "damage_by_distance": [\
            {"distance":16,"damage":5.1,"crit_damage":6.6},\
            {"distance":26,"damage":4.8,"crit_damage":6.2},\
            {"distance":50,"damage":4.3,"crit_damage":5.6},\
            {"distance":70,"damage":3.5,"crit_damage":4.5},\
        ],\
        "max_range": 80,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.12,0.8],\
        "trail_offset": [-0.15,-0.23,0.9],\
        \
        "reload_time": 42,\
        "empty_reload_time": 76,\
        "prioritize_bolt_action": true,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 26,\
        "swap_time": 14,\
        "ads_time": 7,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 5,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 2,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 80,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.38,\
        "bloom_max": 90,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.75,\
        "sway_yaw": 1.3,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.59,\
        "shake_pitch": -0.1,\
        "shake_yaw_random": 0.1,\
        "shake_pitch_random": 0.07,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.2, "pitch": -0.45},\
            {"yaw": 0.3, "pitch": -0.46},\
            {"yaw": 0.1, "pitch": -0.45},\
            {"yaw": -0.2, "pitch": -0.45},\
            {"yaw": -0.4, "pitch": -0.47},\
            {"yaw": -0.5, "pitch": -0.47},\
            {"yaw": -0.3, "pitch": -0.48},\
            {"yaw": 0.0, "pitch": -0.49},\
            {"yaw": 0.4, "pitch": -0.50},\
            {"yaw": 0.7, "pitch": -0.50},\
            {"yaw": 0.9, "pitch": -0.51},\
            {"yaw": 1.0, "pitch": -0.52},\
            {"yaw": 0.8, "pitch": -0.54},\
            {"yaw": 0.5, "pitch": -0.55},\
            {"yaw": 0.2, "pitch": -0.53},\
            {"yaw": -0.1, "pitch": -0.54},\
            {"yaw": -0.3, "pitch": -0.54},\
            {"yaw": -0.4, "pitch": -0.56},\
            {"yaw": -0.3, "pitch": -0.57},\
            {"yaw": -0.1, "pitch": -0.56},\
            {"yaw": 0.1, "pitch": -0.58},\
            {"yaw": 0.2, "pitch": -0.60},\
            {"yaw": 0.1, "pitch": -0.62},\
            {"yaw": -0.1, "pitch": -0.63},\
            {"yaw": -0.2, "pitch": -0.62},\
            {"yaw": -0.1, "pitch": -0.61},\
            {"yaw": 0.1, "pitch": -0.62},\
            {"yaw": 0.2, "pitch": -0.63},\
            {"yaw": 0.0, "pitch": -0.63, "repeat": {} }\
        ],\
        "yaw_recoil_multiplier": 1.25,\
        "pitch_recoil_multiplier":4.45,\
        "recoil_apply_tick": 2,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/uzi/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/uzi/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/uzi/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/uzi/reload",\
            "duration": 176,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 33},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.15 2 0", "time": 85},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 135},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.15 0", "time": 182},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/uzi/empty_reload",\
            "duration": 274,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.5 0","time": 12},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.5 0", "time": 55},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.6 0","time": 87},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.15 2 0", "time": 115},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.2 2 0", "time": 160},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.2 2 0", "time": 200},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 2 0", "time": 224},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 267},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 274},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/uzi/bolt_action",\
            "duration": 89,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.1 0","time": 25},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 67},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/uzi/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/uzi/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.25 1.9 0","time": 49},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 49},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/uzi/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/uzi/sprint",\
            "duration": 34,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
            {id:"uzi_mini_barrel",cmd:"mini_barrel",modifier:[\
                {entry:"state.trail_offset[0]",operation:"add",value:"-0.01"},\
                {entry:"state.trail_offset[1]",operation:"add",value:"-0.01"},\
                {entry:"state.trail_offset[2]",operation:"add",value:"-0.06"},\
                {entry:"state.trail_pos[2]",operation:"add",value:"-0.06"},\
                {entry:"state.ads_time",operation:"add",value:-1},\
                {entry:"state.end_sprint_time",operation:"add_base_scale",value:-0.1},\
                {entry:"state.pitch_recoil_multiplier",operation:"add_base_scale",value:0.15},\
                {entry:"state.yaw_recoil_multiplier",operation:"add_base_scale",value:0.1}\
            ]}\
        ]},\
        {slot:"muzzle", list: [\
            {id:"2_stage_suppressor",cmd:"2_stage_suppressor",modifier:[\
                {entry:"state.trail_offset[0]",operation:"add",value:"0.04"},\
                {entry:"state.trail_pos[2]",operation:"add",value:"0.16"},\
                {entry:"state.trail_offset[2]",operation:"add",value:"0.16"},\
                {entry:"state.fire_cmd",operation:"strings",value:"function default_gunpack:gun/uzi/fire/suppressed"},\
                {entry:"state.ads_time",operation:"add",value:1},\
                {entry:"state.end_sprint_time",operation:"add_base_scale",value:0.1},\
                {entry:"state.pitch_recoil_multiplier",operation:"add_base_scale",value:-0.1},\
                {entry:"state.yaw_recoil_multiplier",operation:"add_base_scale",value:-0.1}\
            ]}\
        ]},\
        {slot:"magazine", list: [\
            {id:"uzi_short_magazine",cmd:"short_magazine",modifier:[\
                {entry:"state.reload_time",operation:"add_base_scale",value:-0.1},\
                {entry:"state.empty_reload_time",operation:"add_base_scale",value:-0.08},\
                {entry:"state.ammo_capacity",operation:"replace",value:25}\
            ]}\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
            {id:"uzi_folded_stock",cmd:"folded_stock",modifier:[\
                {entry:"state.ads_time",operation:"add_base_scale",value:-0.15},\
                {entry:"state.sprint_time",operation:"add_base_scale",value:-0.15},\
                {entry:"state.end_sprint_time",operation:"add_base_scale",value:-0.15},\
                {entry:"state.pitch_recoil_multiplier",operation:"add_base_scale",value:0.45},\
                {entry:"state.yaw_recoil_multiplier",operation:"add_base_scale",value:0.55}\
            ]}\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}