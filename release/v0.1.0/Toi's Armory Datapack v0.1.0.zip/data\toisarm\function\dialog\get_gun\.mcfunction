data modify storage toisarm:dialog gun_list set value []
data modify storage toisarm:dialog gun_data set value []
data modify storage toisarm:dialog gun set from storage toisarm:data gun
execute store result storage toisarm:dialog gun[0].count int 1 run scoreboard players set #toisarm.temp _ 0
function toisarm:dialog/get_gun/add_to_list/ with storage toisarm:dialog gun[0]
function toisarm:dialog/get_gun/show/ with storage toisarm:dialog
data modify storage toisarm:temp this_player.dialog.gun_list set from storage toisarm:dialog gun_list
data modify storage toisarm:temp this_player.dialog.gun_data set from storage toisarm:dialog gun_data
data modify storage toisarm:temp this_player.dialog.gun set from storage toisarm:dialog gun
data remove storage toisarm:dialog gun_list
data remove storage toisarm:dialog gun_data
data remove storage toisarm:dialog gun
scoreboard players set @s toisarm.trigger.op_input -1
