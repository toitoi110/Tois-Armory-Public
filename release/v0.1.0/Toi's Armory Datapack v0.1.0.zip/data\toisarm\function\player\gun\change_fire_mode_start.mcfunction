scoreboard players remove @s toisarm.input.change_fire_mode 1
scoreboard players operation @s toisarm.timer.change_fire_mode = @s toisarm.state.change_fire_mode
