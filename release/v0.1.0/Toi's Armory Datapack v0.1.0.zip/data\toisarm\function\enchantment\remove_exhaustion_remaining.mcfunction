scoreboard players remove @s toisarm.exhaustion 1
scoreboard players remove @s[scores={toisarm.exhaustion_remaining=1..}] toisarm.exhaustion_remaining 1
execute unless score @s toisarm.exhaustion matches 1.. run item modify entity @s saddle {"type":"minecraft:set_enchantments","enchantments":{"toisarm:apply_exhaustion":0}}
