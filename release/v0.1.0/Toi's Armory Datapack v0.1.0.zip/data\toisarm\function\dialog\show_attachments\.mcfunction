data modify storage toisarm:dialog attachment_item_slot set value []
data modify storage toisarm:dialog attachment_id set value []
data modify storage toisarm:dialog attachment_item_list set value []
execute store result storage toisarm:dialog temp.count int 1 run scoreboard players get @s toisarm.trigger.change_attachment_slot
execute store result storage toisarm:dialog temp.id int 1 run scoreboard players get @s toisarm.id
function toisarm:dialog/show_attachments/with_index/ with storage toisarm:dialog temp
data modify storage toisarm:dialog attachment_id append from storage toisarm:dialog attachment_item_slot[].components."minecraft:custom_data".toisarm
execute store result storage toisarm:dialog attachment_id[0].count int 1 run scoreboard players set #toisarm.temp _ 0
function toisarm:dialog/show_attachments/add_list/ with storage toisarm:dialog attachment_id[0]
scoreboard players set @s toisarm.trigger.change_attachment_slot -1
execute unless data storage toisarm:dialog attachment_item_list[] run return run function toisarm:dialog/show_attachments/fail/
function toisarm:dialog/show_attachments/show/ with storage toisarm:dialog
scoreboard players enable @s toisarm.trigger.operate_attachment
data modify storage toisarm:temp this_player.dialog.attachment_item_list set from storage toisarm:dialog attachment_item_list
data remove storage toisarm:dialog attachment_item_slot
data remove storage toisarm:dialog attachment_item_list
data remove storage toisarm:dialog attachment_id
