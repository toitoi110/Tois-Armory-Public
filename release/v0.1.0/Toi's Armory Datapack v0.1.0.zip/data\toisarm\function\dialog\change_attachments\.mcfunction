scoreboard players set @s toisarm.trigger.input -1
execute unless predicate toisarm:has_gun_mainhand run return run function toisarm:dialog/change_attachments/fail/
execute unless entity @s[gamemode=creative] if score #toisarm.settings.attachment_operation_requires_gunsmith_table _ matches 1 unless entity @e[tag=toisarm.gunsmith_table,distance=..4.5] run return run function toisarm:dialog/change_attachments/fail/
data modify storage toisarm:dialog temp.id set from entity @s SelectedItem.components."minecraft:custom_data".toisarm.id
function toisarm:dialog/change_attachments/macro/ with storage toisarm:dialog temp
data remove storage toisarm:dialog attachment[{list:[]}]
data modify storage toisarm:dialog attachment_data set value []
data modify storage toisarm:dialog attachment_slot_list set value []
execute store result storage toisarm:dialog attachment[0].count int 1 run scoreboard players set #toisarm.temp _ 0
function toisarm:dialog/change_attachments/add_list/ with storage toisarm:dialog attachment[0]
data modify storage toisarm:temp this_player.dialog.attachment_data set from storage toisarm:dialog attachment_data
function toisarm:dialog/change_attachments/show/ with storage toisarm:dialog
scoreboard players enable @s toisarm.trigger.change_attachment_slot
data remove storage toisarm:dialog attachment
data remove storage toisarm:dialog attachment_data
data remove storage toisarm:dialog attachment_slot_list
data remove storage toisarm:dialog temp
