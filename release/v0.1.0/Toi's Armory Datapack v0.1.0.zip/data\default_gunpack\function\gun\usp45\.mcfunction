data modify storage toisarm:import gun append value \
{\
    "id": "usp45",\
    "display_name":"USP 45",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"SEMI","value":2}],\
        "ammo_type": ".45acp",\
        "ammo_capacity": 12,\
        "ammo_count": 12,\
        "chamber": 1,\
        "round_per_minute": 360,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.45acp",\
        "trail_id": "trail.default_gunpack.medium",\
        "bullet_velocity": 15,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.004,\
        "damage_by_distance": [\
            {"distance":12,"damage":4.8,"crit_damage":5.8},\
            {"distance":24,"damage":4.3,"crit_damage":5.2},\
            {"distance":44,"damage":3.6,"crit_damage":4.3},\
            {"distance":80,"damage":2.8,"crit_damage":3.4},\
        ],\
        "max_range": 80,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.06,0.75],\
        "trail_offset": [-0.03,-0.195,0.9],\
        \
        "reload_time": 33,\
        "empty_reload_time": 53,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 16,\
        "swap_time": 10,\
        "ads_time": 5,\
        "end_ads_time": -1,\
        "sprint_time": 4,\
        "end_sprint_time": 5,\
        \
        "firing_anim": 3,\
        "bolt_move_anim": 3,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 50,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.20,\
        "bloom_max": 80,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.7,\
        "sway_yaw": 1.3,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.12,\
        "shake_pitch": -0.05,\
        "shake_yaw_random": 0.05,\
        "shake_pitch_random": 0.02,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.2, "pitch": -1.1},\
            {"yaw": 0.175, "pitch": -1.14},\
            {"yaw": 0.12, "pitch": -1.1},\
            {"yaw": -0.15, "pitch": -0.9},\
            {"yaw": -0.05, "pitch": -0.85},\
            {"yaw": -0.13, "pitch": -0.87},\
            {"yaw": -0.17, "pitch": -0.86},\
            {"yaw": -0.2, "pitch": -0.98},\
            {"yaw": -0.15, "pitch": -1.12},\
            {"yaw": -0.05, "pitch": -1.12},\
            {"yaw": 0.1, "pitch": -1.05},\
            {"yaw": 0.18, "pitch": -0.97, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 3.5,\
        "pitch_recoil_multiplier":3.15,\
        "recoil_apply_tick": 3,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/usp45/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/usp45/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/usp45/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/usp45/reload",\
            "duration": 181,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 63},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.15 2 0", "time": 85},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 125},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 172},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/usp45/empty_reload",\
            "duration": 231,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.6 0", "time": 25},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.15 2 0", "time": 94},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 125},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.1 1.8 0", "time": 162},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0", "time": 190},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 222},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 222},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/usp45/bolt_action",\
            "duration": 72,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.1 0","time": 25},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 67},\
            ]\
        },\
        "swap":{\
            "pass": "toisarm:gun/usp45/swap",\
            "duration": 61,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.25 1.9 0","time": 49},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 49},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/usp45/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/usp45/sprint",\
            "duration": 34,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"slide", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
    ]\
}