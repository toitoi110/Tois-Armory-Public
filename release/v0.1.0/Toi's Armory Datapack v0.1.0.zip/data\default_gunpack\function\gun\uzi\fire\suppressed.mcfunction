
data modify storage toisarm:sound {} merge value {max_distance:36,sounds:[\
{id:"minecraft:item.shield.block",volume:0.05,pitch:0.95},\
{id:"minecraft:item.flintandsteel.use",volume:0.55,pitch:1.2},\
{id:"minecraft:entity.hoglin.step",volume:0.1,pitch:1.2},\
{id:"minecraft:block.packed_mud.break",volume:0.6,pitch:0.15},\
{id:"minecraft:block.sweet_berry_bush.break",volume:0.4,pitch:1.85},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.1,pitch:0.35},\
{id:"minecraft:block.wooden_door.open",volume:0.15,pitch:1.8},\
{id:"minecraft:block.wooden_trapdoor.open",volume:0.6,pitch:1.6},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:18,sounds:[\
{id:"minecraft:block.packed_mud.break",volume:1,pitch:0.15},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.05,pitch:0.35},\
{id:"minecraft:block.wooden_door.close",volume:0.6,pitch:1.3},\
{id:"minecraft:block.lever.click",volume:0.4,pitch:1.4},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.38,0.08,0],item_model:"toisarm:other/small_casing",offset:[-0.12,-0.17,0.2],pos:[-0.18,-0.1,0.47]}
function toisarm:util/ejection/
execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{toisarm:{state:{chamber:0b}}}}}}] anchored eyes positioned ^-0.1 ^ ^0.1 run playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.4 1.4 0
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.015 0.015 0.015 0 2 force @a
particle minecraft:white_smoke ^ ^ ^ 0.05 0.05 0.05 10000000000 3 force @a
