    execute if score @s toisarm.drop matches 1.. if data storage toisarm:temp this_player.prev_mainhand_item.components."minecraft:custom_data".toisarm{type:gun} unless items entity @s weapon * run function toisarm:player/check_mainhand_changed/drop
    item replace entity 0-0-0-0-1ae1e container.0 from entity @s weapon
    data modify storage toisarm:temp mainhand_item set from entity 0-0-0-0-1ae1e item
    data remove storage toisarm:temp mainhand_item.components."minecraft:custom_data".toisarm.state
    data remove storage toisarm:temp mainhand_item.components."minecraft:custom_model_data"
    data remove storage toisarm:temp mainhand_item.components."minecraft:item_model"
    data remove storage toisarm:temp mainhand_item.components."minecraft:item_name"
    data remove storage toisarm:temp mainhand_item.components."minecraft:charged_projectiles"
    data remove storage toisarm:temp mainhand_item.components."minecraft:attribute_modifiers"
    execute unless items entity @s weapon * run data modify storage toisarm:temp mainhand_item set value {id:"minecraft:air",count:1}
    execute store success score @s _ run data modify storage toisarm:temp this_player.prev_mainhand_item set from storage toisarm:temp mainhand_item
    execute if score @s _ matches 1 run return 1
    return 0
