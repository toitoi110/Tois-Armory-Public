attribute @s minecraft:jump_strength modifier add toisarm:jump_blocked -1 add_multiplied_total
tag @s add toisarm.jump_blocked
