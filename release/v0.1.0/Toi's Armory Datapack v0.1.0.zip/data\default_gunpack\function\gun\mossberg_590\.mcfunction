data modify storage toisarm:import gun append value \
{\
    "id": "mossberg_590",\
    "display_name":"Mossberg 590",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"SEMI","value":2}],\
        "ammo_type": "12ga",\
        "ammo_capacity": 5,\
        "ammo_count": 5,\
        "chamber": 1,\
        "manual_bolt_action": true,\
        "round_per_minute": 500,\
        \
        "projectiles_per_shot": 12,\
        "bullet_id": "bullet.default_gunpack.12gauge",\
        "trail_id": "trail.default_gunpack.small",\
        "bullet_velocity": 13,\
        "bullet_drag": 0.000,\
        "bullet_gravity": 0.03,\
        "bullet_weight": 0.045,\
        "damage_by_distance": [\
            {"distance":9,"damage":25.3,"crit_damage":27.8},\
            {"distance":16,"damage":19.4,"crit_damage":21.3},\
            {"distance":30,"damage":15.2,"crit_damage":16.7},\
            {"distance":55,"damage":13.2,"crit_damage":14.5},\
        ],\
        "shots_divide_damage": true,\
        "max_range": 80,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.05,0.6],\
        "trail_offset": [-0.08,-0.06,0.6],\
        \
        "reload_time": 22,\
        "empty_reload_time": 48,\
        \
        "reload_loop_time": 12,\
        "reload_loop_success": 8,\
        "reload_loop_start": 12,\
        "empty_reload_loop_start": 9,\
        \
        "bolt_action_delay": 10,\
        "bolt_action_time": 9,\
        "swap_time": 16,\
        "ads_time": 9,\
        "end_ads_time": -1,\
        "sprint_time": 6,\
        "end_sprint_time": 7,\
        \
        "firing_anim": 8,\
        "bolt_move_anim": 0,\
        "bolt_hold_open": 0,\
        \
        "accuracy_ads": 65,\
        "accuracy_idle": 15,\
        "accuracy_multiplier_move": 0.06,\
        "bloom_increase_rate": 0.31,\
        "bloom_max": 20,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 1.2,\
        "sway_yaw": 1.8,\
        "sway_pitch": 1.4,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0,\
        "shake_pitch": -1.59,\
        "shake_yaw_random": 0.9,\
        "shake_pitch_random": 0.3,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": -0.66, "pitch": -2.6},\
            {"yaw": -0.58, "pitch": -2.73},\
            {"yaw": 0.63, "pitch": -2.46},\
            {"yaw": 0.64, "pitch": -2.56},\
            {"yaw": 0.71, "pitch": -2.76},\
            {"yaw": 0.63, "pitch": -2.6, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 1,\
        "pitch_recoil_multiplier": 2.5,\
        "recoil_apply_tick": 3,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/mossberg_590/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/mossberg_590/change_fire_mode/",\
        "reload_loop_success_cmd": "function default_gunpack:gun/mossberg_590/reload_loop_success/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/mossberg_590/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/mossberg_590/reload",\
            "duration": 61,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.15 0", "time": 58},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/mossberg_590/empty_reload",\
            "duration": 211,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.1 0","time": 17},\
                {"command": "data modify storage toisarm:ejection {} merge value {offset:[0,0,0],pos:[-0.35,-0.25,0.6],motion:[-0.35,0.15,-0.08],item_model:\"toisarm:other/shotshell\"}","time": 21},\
                {"command": "function toisarm:util/ejection/","time": 21},\
                {"command": "scoreboard players set @s toisarm.chamber 1","time": 100},\
                {"command": "item modify entity @s weapon toisarm:gun/set_chamber/1","time": 100},\
                {"command": "tag @s add toisarm.update_item_name","time": 100},\
                {"command": "scoreboard players set @s toisarm.shootable 1","time": 100},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.45 1.95 0","time": 100},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0","time": 130},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.15 0", "time": 207},\
            ]\
        },\
        "reload_loop":{\
            "pass": "toisarm:gun/mossberg_590/reload_loop",\
            "duration": 51,\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/mossberg_590/bolt_action",\
            "duration": 39,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.2 1.6 0","time": 6},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0","time": 22},\
                {"command": "data modify storage toisarm:ejection {} merge value {offset:[0,0,0],pos:[-0.4,-0.25,0.6],motion:[-0.35,0.15,-0.08],item_model:\"toisarm:other/shotshell\"}","time": 24},\
                {"command": "function toisarm:util/ejection/","time": 24},\
            ]\
        },\
        "swap":{\
            "pass": "toisarm:gun/mossberg_590/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0","time": 62}\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/mossberg_590/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/mossberg_590/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"handguard", list: [\
        ]},\
        {slot:"shell", list: [\
        ]},\
    ]\
}