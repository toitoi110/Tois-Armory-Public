    execute store result storage toisarm:temp bullet.velocity float 0.01 store result score @s toisarm.bullet.velocity_remaining run scoreboard players operation @s toisarm.bullet.velocity -= @s toisarm.bullet.drag
    execute store result storage toisarm:temp bullet.gravity float 0.01 run scoreboard players operation @s toisarm.bullet.gravity += @s toisarm.bullet.weight
    execute store result storage toisarm:temp bullet.offset_x float 0.000001 run scoreboard players get @s toisarm.bullet.trail_offset_x
    execute store result storage toisarm:temp bullet.offset_y float 0.000001 run scoreboard players get @s toisarm.bullet.trail_offset_y
    execute store result storage toisarm:temp bullet.offset_z float 0.000001 run scoreboard players get @s toisarm.bullet.trail_offset_z
    data modify storage toisarm:temp bullet.fire_cmd set from entity @s data.fire_cmd
    scoreboard players operation #id _ = @s toisarm.bullet.owner
    scoreboard players set #raycast.dm toisarm.util.raycast 10
    scoreboard players operation #raycast.dm toisarm.util.raycast *= @s toisarm.bullet.velocity
    function toisarm:bullet/first_tick/macro with storage toisarm:temp bullet
    execute if entity @n[type=marker,tag=ENTRY_POINT] at @s run function toisarm:bullet/first_tick/hit_ground
    execute if entity @n[type=marker,tag=ENTRY_POINT] at @s run rotate @s facing entity @n[type=marker,tag=ENTRY_POINT] feet
    execute unless entity @n[type=marker,tag=ENTRY_POINT] at @s run rotate @s facing entity 0-0-0-0-1ae1e feet
    tp 0-0-0-0-1ae1e 0.0 0.0 0.0
    tag @s add toisarm.bullet.trail_fixed
    execute if score @s toisarm.bullet.velocity_remaining matches 30.. at @s positioned ^ ^ ^0.30 run function toisarm:bullet/move/
        execute if entity @s[tag=HIT_ENTITY] run function toisarm:bullet/damage with entity @s data
        execute if entity @s[tag=HIT_GROUND] run function toisarm:bullet/impact
        kill @e[type=marker,tag=ENTRY_POINT]
        execute if entity @s[tag=OUT_OF_RANGE] run return run function toisarm:util/kill/
        tag @s remove BULLET
    rotate @s ~ ~
