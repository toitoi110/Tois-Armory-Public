execute if score @s toisarm.bullet.distance_damage_index matches 1 run return run function toisarm:bullet/move/update_damage/shots_divide_damage/1
function toisarm:bullet/move/update_damage/shots_divide_damage/2
