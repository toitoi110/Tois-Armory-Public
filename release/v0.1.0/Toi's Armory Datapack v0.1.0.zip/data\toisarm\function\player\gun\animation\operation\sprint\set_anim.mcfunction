    scoreboard players set @s toisarm.animation_changed 0
    data modify storage toisarm:temp this_player.temp.commands set from storage toisarm:temp this_player.data.gun.animation.sprint.commands
    execute if score @s toisarm.animation_interrupted matches 1 run function toisarm:player/gun/animation/operation/pass
    item replace entity 0-0-0-0-1ae1e container.0 from entity @s weapon
    data modify entity 0-0-0-0-1ae1e item.components."minecraft:item_model" set from storage toisarm:temp this_player.data.gun.animation.sprint.pass
    item replace entity @s weapon from entity 0-0-0-0-1ae1e container.0
