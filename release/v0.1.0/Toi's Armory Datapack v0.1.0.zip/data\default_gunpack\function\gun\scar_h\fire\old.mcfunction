
data modify storage toisarm:sound {} merge value {max_distance:64,sounds:[\
{id:"minecraft:entity.hoglin.step",volume:0.65,pitch:0.65},\
{id:"minecraft:item.shield.block",volume:0.2,pitch:0.4},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.3,pitch:0.1},\
{id:"minecraft:entity.iron_golem.repair",volume:0.12,pitch:0.95},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:32,sounds:[\
{id:"minecraft:block.copper_grate.hit",volume:0.2,pitch:1.15},\
{id:"minecraft:block.wooden_door.close",volume:0.42,pitch:1.45},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {offset:[-0.2,-0.15,0.2],pos:[-0.25,-0.3,0.55],motion:[-0.36,0.1,-0.2],item_model:"toisarm:other/medium_casing"}
function toisarm:util/ejection/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 2 force @a
