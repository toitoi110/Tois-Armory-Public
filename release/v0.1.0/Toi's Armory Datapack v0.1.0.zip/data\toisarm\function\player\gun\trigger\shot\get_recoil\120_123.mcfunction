execute if score @s toisarm.recoil.pattern_index matches 120..121 run function toisarm:player/gun/trigger/shot/get_recoil/120_121
execute if score @s toisarm.recoil.pattern_index matches 122..123 run function toisarm:player/gun/trigger/shot/get_recoil/122_123
