execute if score @s toisarm.recoil.pattern_index matches 106 run function toisarm:player/gun/trigger/shot/get_recoil/106
execute if score @s toisarm.recoil.pattern_index matches 107 run function toisarm:player/gun/trigger/shot/get_recoil/107
