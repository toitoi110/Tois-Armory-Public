execute if score @s toisarm.recoil.pattern_index matches 12..13 run function toisarm:player/gun/trigger/shot/get_recoil/12_13
execute if score @s toisarm.recoil.pattern_index matches 14..15 run function toisarm:player/gun/trigger/shot/get_recoil/14_15
