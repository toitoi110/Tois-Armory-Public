execute store result score @s _ run data get entity @s SelectedItem.components."minecraft:custom_data".toisarm.state.ammo_remaining
execute unless entity @s[scores={toisarm.timer.reload=-1,toisarm.timer.reload=-1}] unless score @s _ = @s toisarm.state.ammo_capacity run return run data modify storage toisarm:temp update_name append value "ᴿ"
data modify storage toisarm:temp update_name append value ""
