    scoreboard players operation @s toisarm.timer.reload = @s toisarm.state.reload
    execute if score @s toisarm.settings.reload_disable_ads matches 1 run tag @s remove toisarm.input.lclick
