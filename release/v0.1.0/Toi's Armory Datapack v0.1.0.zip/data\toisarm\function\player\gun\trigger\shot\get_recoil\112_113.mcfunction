execute if score @s toisarm.recoil.pattern_index matches 112 run function toisarm:player/gun/trigger/shot/get_recoil/112
execute if score @s toisarm.recoil.pattern_index matches 113 run function toisarm:player/gun/trigger/shot/get_recoil/113
