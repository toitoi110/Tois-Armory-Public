execute if score @s toisarm.recoil.pattern_index matches 100 run function toisarm:player/gun/trigger/shot/get_recoil/100
execute if score @s toisarm.recoil.pattern_index matches 101 run function toisarm:player/gun/trigger/shot/get_recoil/101
