#> default_gunpack:impact_mark/medium

summon text_display ~ ~ ~ {Rotation:[0.0f,0.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
execute if score $raycast.hit_face toisarm.util.raycast matches 0 run rotate @n[type=text_display,tag=THIS] 0 90
execute if score $raycast.hit_face toisarm.util.raycast matches 1 run rotate @n[type=text_display,tag=THIS] 0 -90
execute if score $raycast.hit_face toisarm.util.raycast matches 2 run rotate @n[type=text_display,tag=THIS] 180 0
execute if score $raycast.hit_face toisarm.util.raycast matches 3 run rotate @n[type=text_display,tag=THIS] 0 0
execute if score $raycast.hit_face toisarm.util.raycast matches 4 run rotate @n[type=text_display,tag=THIS] 90 0
execute if score $raycast.hit_face toisarm.util.raycast matches 5 run rotate @n[type=text_display,tag=THIS] 270 0
execute as @n[type=text_display,distance=..0.1,tag=THIS] at @s run function default_gunpack:impact_mark/set_color

#execute if score $raycast.hit_face toisarm.util.raycast matches 1 run summon text_display ~ ~ ~ {Rotation:[90.0f,0.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute if score $raycast.hit_face toisarm.util.raycast matches 1 run summon text_display ~ ~ ~ {Rotation:[270.0f,0.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute if score $raycast.hit_face toisarm.util.raycast matches 2 run summon text_display ~ ~ ~ {Rotation:[0.0f,0.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute if score $raycast.hit_face toisarm.util.raycast matches 2 run summon text_display ~ ~ ~ {Rotation:[180.0f,0.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute if score $raycast.hit_face toisarm.util.raycast matches 3 run summon text_display ~ ~ ~ {Rotation:[0.0f,90.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute if score $raycast.hit_face toisarm.util.raycast matches 3 run summon text_display ~ ~ ~ {Rotation:[0.0f,-90.0f],Tags:["toisarm.impact_mark","THIS"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.0125f,-0.0625f,0f],scale:[1f,0.5f,1f]},text:" ",background:-65536}
#execute as @e[type=text_display,distance=..0.1,tag=THIS] run function default_gunpack:impact_mark/set_color

execute store result score @s _ if entity @e[type=text_display,tag=toisarm.impact_mark]
execute if score @s _ matches 256.. run function toisarm:util/reduce_impact_mark/

schedule function toisarm:impact_mark/schedule 1t replace