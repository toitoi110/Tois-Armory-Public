scoreboard players operation @s toisarm.animation = @s toisarm.state.bolt_action
scoreboard players operation @s toisarm.animation -= @s toisarm.timer.bolt_action
execute unless score @s toisarm.animation_id matches 2 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 2
