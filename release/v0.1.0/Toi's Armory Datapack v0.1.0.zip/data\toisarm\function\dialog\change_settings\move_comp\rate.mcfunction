execute if score @s toisarm.settings.move_comp.rate matches 150.. run return run scoreboard players set @s toisarm.settings.move_comp.rate 10
scoreboard players add @s toisarm.settings.move_comp.rate 10
