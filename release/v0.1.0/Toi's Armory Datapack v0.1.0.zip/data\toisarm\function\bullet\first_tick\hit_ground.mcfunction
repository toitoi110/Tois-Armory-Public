data modify storage toisarm:temp transformation set value [0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,1.0f]
execute store result score #target_x _ run data get entity @n[type=marker,tag=ENTRY_POINT] Pos[0] 100
execute store result score #target_y _ run data get entity @n[type=marker,tag=ENTRY_POINT] Pos[1] 100
execute store result score #target_z _ run data get entity @n[type=marker,tag=ENTRY_POINT] Pos[2] 100
execute store result score @s _ run data get entity @s Pos[0] 100
execute store result storage toisarm:temp transformation[0] float 0.01 run scoreboard players operation @s _ -= #target_x _
execute store result score @s _ run data get entity @s Pos[1] 100
execute store result storage toisarm:temp transformation[4] float 0.01 run scoreboard players operation @s _ -= #target_y _
execute store result score @s _ run data get entity @s Pos[2] 100
execute store result storage toisarm:temp transformation[8] float 0.01 run scoreboard players operation @s _ -= #target_z _
data modify entity 0-0-0-0-1ae1e transformation set from storage toisarm:temp transformation
data remove storage toisarm:temp transformation
execute store result score @s toisarm.bullet.velocity_remaining run data get entity 0-0-0-0-1ae1e transformation.scale[0] 100
tag @s add HIT_GROUND
