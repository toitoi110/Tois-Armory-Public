data modify storage toisarm:import gun append value \
{\
    "id": "scorpion_evo3",\
    "display_name":"Scorpion Evo 3",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"BURST","value":3},{"display":"SEMI","value":2}],\
        "ammo_type": "9x19mm",\
        "ammo_capacity": 30,\
        "ammo_count": 30,\
        "chamber": 1,\
        "round_per_minute": 1150,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.9x19mm",\
        "trail_id": "trail.default_gunpack.small",\
        "bullet_velocity": 18,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.004,\
        "damage_by_distance": [\
            {"distance":7,"damage":2.9,"crit_damage":3.8},\
            {"distance":24,"damage":2.3,"crit_damage":3.0},\
            {"distance":40,"damage":1.8,"crit_damage":2.4},\
            {"distance":60,"damage":1.4,"crit_damage":1.8},\
        ],\
        "max_range": 80,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.15,0.9],\
        "trail_offset": [-0.12,-0.255,0.9],\
        \
        "reload_time": 45,\
        "empty_reload_time": 70,\
        "prioritize_bolt_action": 0,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 26,\
        "swap_time": 18,\
        "ads_time": 7,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 5,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 4,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 80,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.20,\
        "bloom_max": 100,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.75,\
        "sway_yaw": 1.6,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.06,\
        "shake_pitch": -0.05,\
        "shake_yaw_random": 0.1,\
        "shake_pitch_random": 0.02,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.02, "pitch": -1.05},\
            {"yaw": 0.03, "pitch": -1.08},\
            {"yaw": 0.01, "pitch": -1.09},\
            {"yaw": -0.02, "pitch": -1.09},\
            {"yaw": -0.04, "pitch": -1.08},\
            {"yaw": -0.05, "pitch": -1.06},\
            {"yaw": -0.03, "pitch": -1.02},\
            {"yaw": 0.00, "pitch": -1.02},\
            {"yaw": 0.04, "pitch": -1.03},\
            {"yaw": 0.07, "pitch": -1.05},\
            {"yaw": 0.09, "pitch": -1.07},\
            {"yaw": 0.10, "pitch": -1.08},\
            {"yaw": 0.08, "pitch": -1.09},\
            {"yaw": 0.05, "pitch": -1.10},\
            {"yaw": 0.02, "pitch": -1.12},\
            {"yaw": -0.01, "pitch": -1.15},\
            {"yaw": -0.03, "pitch": -1.17},\
            {"yaw": -0.02, "pitch": -1.16},\
            {"yaw": 0.04, "pitch": -1.13},\
            {"yaw": 0.05, "pitch": -1.11},\
            {"yaw": 0.06, "pitch": -1.09},\
            {"yaw": 0.06, "pitch": -1.07},\
            {"yaw": 0.07, "pitch": -1.08},\
            {"yaw": 0.00, "pitch": -1.10},\
            {"yaw": 0.06, "pitch": -1.12},\
            {"yaw": 0.07, "pitch": -1.11},\
            {"yaw": 0.08, "pitch": -1.09},\
            {"yaw": 0.08, "pitch": -1.08},\
            {"yaw": 0.07, "pitch": -1.08, "repeat": {} }\
        ],\
        "yaw_recoil_multiplier": 6.95,\
        "pitch_recoil_multiplier":0.6,\
        "recoil_apply_tick": 1,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/scorpion_evo3/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/scorpion_evo3/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/scorpion_evo3/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/scorpion_evo3/reload",\
            "duration": 156,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.5 0", "time": 28},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.8 0", "time": 60},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.15 2 0", "time": 70},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.9 0", "time": 95},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.5 0", "time": 150},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/scorpion_evo3/empty_reload",\
            "duration": 269,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.4 1.5 0","time": 15},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.2 1.15 0", "time": 56},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 2 0", "time": 80},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.8 0", "time": 166},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.8 0", "time": 210},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.5 0","time": 261},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 261},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/scorpion_evo3/bolt_action",\
            "duration": 89,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.1 0","time": 25},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 67},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/scorpion_evo3/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/scorpion_evo3/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.25 1.9 0","time": 69},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.7 0","time": 69},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/scorpion_evo3/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/scorpion_evo3/sprint",\
            "duration": 34,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"muzzle", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}