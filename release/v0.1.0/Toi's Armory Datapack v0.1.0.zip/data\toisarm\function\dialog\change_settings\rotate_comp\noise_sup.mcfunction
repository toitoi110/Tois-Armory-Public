execute if score @s toisarm.settings.rotate_comp.noise_sup matches 90.. run return run scoreboard players set @s toisarm.settings.rotate_comp.noise_sup 0
scoreboard players add @s toisarm.settings.rotate_comp.noise_sup 10
