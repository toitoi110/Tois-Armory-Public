    scoreboard players operation @s _ = @s toisarm.animation.idle
    scoreboard players operation @s _ *= 1000 num
    scoreboard players operation @s _ /= @s toisarm.state.idle
    scoreboard players operation @s toisarm.animation *= @s _
    execute store result storage toisarm:temp animation_frame int 0.001 run scoreboard players get @s toisarm.animation
    item modify entity @s weapon toisarm:gun/set_custom_model_data/0
    execute if score @s toisarm.animation_changed matches 1 run function toisarm:player/gun/animation/operation/idle/set_anim
    execute unless data storage toisarm:temp this_player.temp.commands[0] run return 0
    execute store result score @s _ run data get storage toisarm:temp this_player.temp.commands[0].time 1000
    execute if score @s toisarm.animation >= @s _ run function toisarm:player/gun/animation/operation/check_timer
