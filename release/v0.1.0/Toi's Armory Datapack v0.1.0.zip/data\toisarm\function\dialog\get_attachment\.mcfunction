data modify storage toisarm:dialog attachment_list set value []
data modify storage toisarm:dialog attachment_data set value []
data modify storage toisarm:dialog attachment set from storage toisarm:data attachment
execute store result storage toisarm:dialog attachment[0].count int 1 run scoreboard players set #toisarm.temp _ 0
function toisarm:dialog/get_attachment/add_to_list/ with storage toisarm:dialog attachment[0]
function toisarm:dialog/get_attachment/show/ with storage toisarm:dialog
data modify storage toisarm:temp this_player.dialog.attachment_list set from storage toisarm:dialog attachment_list
data modify storage toisarm:temp this_player.dialog.attachment_data set from storage toisarm:dialog attachment_data
data modify storage toisarm:temp this_player.dialog.attachment set from storage toisarm:dialog attachment
data remove storage toisarm:dialog attachment_list
data remove storage toisarm:dialog attachment_data
data remove storage toisarm:dialog attachment
scoreboard players set @s toisarm.trigger.op_input -1
