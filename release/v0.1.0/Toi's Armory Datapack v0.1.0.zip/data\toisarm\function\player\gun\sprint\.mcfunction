    execute if entity @s[predicate=toisarm:is_sprinting,predicate=!toisarm:is_sneaking,tag=!toisarm.input.reload,scores={toisarm.timer.reload=-1,toisarm.timer.reload=-1,toisarm.timer.empty_reload=-1,toisarm.timer.bolt_action_delay=-1,toisarm.input.change_fire_mode=..0,toisarm.timer.change_fire_mode=-1}] run return run function toisarm:player/gun/sprint/advance_timer
    execute if score @s toisarm.timer.sprint matches 0 run return 0
    execute as @s[scores={toisarm.after_sprint_ads_speed=..100}] run return run scoreboard players operation @s toisarm.timer.sprint -= @s toisarm.state.end_sprint
    scoreboard players operation @s _ = @s toisarm.state.end_sprint
    scoreboard players operation @s _ *= @s toisarm.after_sprint_ads_speed
    scoreboard players operation @s _ /= 10000 num
    scoreboard players operation @s toisarm.timer.sprint -= @s _
