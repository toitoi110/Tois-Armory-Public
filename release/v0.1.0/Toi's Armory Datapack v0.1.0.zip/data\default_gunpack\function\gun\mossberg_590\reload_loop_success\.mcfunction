
playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.45 1.95 0