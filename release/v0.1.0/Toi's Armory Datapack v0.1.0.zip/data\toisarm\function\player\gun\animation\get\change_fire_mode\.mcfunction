scoreboard players operation @s toisarm.animation = @s toisarm.state.change_fire_mode
scoreboard players operation @s toisarm.animation -= @s toisarm.timer.change_fire_mode
execute unless score @s toisarm.animation_id matches 3 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 3
