execute if score @s toisarm.recoil.pattern_index matches 118 run function toisarm:player/gun/trigger/shot/get_recoil/118
execute if score @s toisarm.recoil.pattern_index matches 119 run function toisarm:player/gun/trigger/shot/get_recoil/119
