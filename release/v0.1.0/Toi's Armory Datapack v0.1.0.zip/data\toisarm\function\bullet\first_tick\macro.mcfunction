$execute positioned ^ ^ ^$(velocity) run tp 0-0-0-0-1ae1e ~ ~$(gravity) ~
execute facing entity 0-0-0-0-1ae1e feet summon marker run function toisarm:util/raycast/init
$execute rotated as @p[predicate=toisarm:match_id] run tp @s ^$(offset_x) ^$(offset_y) ^$(offset_z)
$execute positioned as @s as @p[predicate=toisarm:match_id] rotated as @s run $(fire_cmd)
$execute positioned ^ ^ ^$(velocity) run tp 0-0-0-0-1ae1e ~ ~$(gravity) ~
