execute if score @s toisarm.bullet.distance_damage_index matches 3 run return run function toisarm:bullet/move/update_damage/3
function toisarm:bullet/move/update_damage/4
