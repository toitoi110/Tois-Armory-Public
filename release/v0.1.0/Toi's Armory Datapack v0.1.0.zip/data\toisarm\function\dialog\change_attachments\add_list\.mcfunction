$data modify storage toisarm:dialog attachment_slot_list append value {label:{translate:"attachment_slot.toisarm.$(slot)",fallback:"$(slot)"},width:150,action:{type:"minecraft:run_command",command:"trigger toisarm.trigger.change_attachment_slot set $(count)"}}
data modify storage toisarm:dialog attachment_data append from storage toisarm:dialog attachment[0]
data remove storage toisarm:dialog attachment[0]
execute unless data storage toisarm:dialog attachment[0] run return 0
execute store result storage toisarm:dialog attachment[0].count int 1 run scoreboard players add #toisarm.temp _ 1
function toisarm:dialog/change_attachments/add_list/ with storage toisarm:dialog attachment[0]
