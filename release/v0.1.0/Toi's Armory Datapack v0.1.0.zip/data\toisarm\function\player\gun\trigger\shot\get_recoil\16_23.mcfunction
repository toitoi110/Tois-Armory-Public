execute if score @s toisarm.recoil.pattern_index matches 16..19 run function toisarm:player/gun/trigger/shot/get_recoil/16_19
execute if score @s toisarm.recoil.pattern_index matches 20..23 run function toisarm:player/gun/trigger/shot/get_recoil/20_23
