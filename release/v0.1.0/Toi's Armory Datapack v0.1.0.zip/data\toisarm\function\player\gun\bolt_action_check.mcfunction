    execute unless score @s toisarm.chamber matches 0 run return 0
    execute if score @s toisarm.ammo_remaining matches 0 run return 0
    scoreboard players operation @s toisarm.timer.bolt_action = @s toisarm.state.bolt_action
