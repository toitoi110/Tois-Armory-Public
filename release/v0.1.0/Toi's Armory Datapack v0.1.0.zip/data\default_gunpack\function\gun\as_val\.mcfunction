data modify storage toisarm:import gun append value \
{\
    "id": "as_val",\
    "display_name":"AS VAL",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"SEMI","value":2}],\
        "ammo_type": "9x39mm",\
        "ammo_capacity": 15,\
        "ammo_count": 15,\
        "chamber": 1,\
        "round_per_minute": 900,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.9x39mm",\
        "trail_id": "trail.default_gunpack.medium",\
        "bullet_velocity": 15,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.005,\
        "damage_by_distance": [\
            {"distance":8,"damage":4.1,"crit_damage":5.3},\
            {"distance":18,"damage":3.5,"crit_damage":4.5},\
            {"distance":30,"damage":3,"crit_damage":3.9},\
            {"distance":80,"damage":2.6,"crit_damage":3.4},\
        ],\
        "max_range": 95,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.225,0.9],\
        "trail_offset": [-0.16,-0.25,1.2],\
        \
        "reload_time": 38,\
        "empty_reload_time": 55,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 25,\
        "swap_time": 17,\
        "ads_time": 8,\
        "end_ads_time": -1,\
        "sprint_time": 6,\
        "end_sprint_time": 6,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 1,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 87,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.28,\
        "bloom_max": 120,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.85,\
        "sway_yaw": 1.7,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.02,\
        "shake_pitch": -0.15,\
        "shake_yaw_random": 0.3,\
        "shake_pitch_random": 0.06,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 1.0, "pitch": -1.6},\
            {"yaw": 1.6, "pitch": -1.1},\
            {"yaw": 1.9, "pitch": -1.2},\
            {"yaw": 2.1, "pitch": -1.3},\
            {"yaw": 2.4, "pitch": -1.3},\
            {"yaw": 2.3, "pitch": -1.2},\
            {"yaw": 1.0, "pitch": -1.2},\
            {"yaw": -0.5, "pitch": -1.1},\
            {"yaw": -0.7, "pitch": -1.0},\
            {"yaw": -1.2, "pitch": -0.98},\
            {"yaw": -1.5, "pitch": -0.91},\
            {"yaw": -1.7, "pitch": -0.92},\
            {"yaw": -1.9, "pitch": -0.92},\
            {"yaw": 0.8, "pitch": -0.94},\
            {"yaw": 1.0, "pitch": -0.96},\
            {"yaw": 1.2, "pitch": -0.98},\
            {"yaw": 1.7, "pitch": -1.11},\
            {"yaw": -1.1, "pitch": -1.15},\
            {"yaw": -0.8, "pitch": -1.17},\
            {"yaw": -0.7, "pitch": -1.11},\
            {"yaw": -0.7, "pitch": -1.0},\
            {"yaw": -0.8, "pitch": -0.96},\
            {"yaw": -0.9, "pitch": -0.91, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 0.5,\
        "pitch_recoil_multiplier":0.85,\
        "recoil_apply_tick": 1,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/as_val/fire/suppressed",\
        "change_fire_mode_cmd": "function default_gunpack:gun/as_val/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/as_val/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/as_val/reload",\
            "duration": 146,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 13},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.65 0", "time": 49},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.85 0", "time": 87},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 142},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/as_val/empty_reload",\
            "duration": 176,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 15},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.65 0","time": 25},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.85 0","time": 87},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.15 0","time": 128},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 172},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/as_val/bolt_action",\
            "duration": 76,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.15 0","time": 25},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/as_val/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/as_val/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.7 0","time": 62},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.35 1.55 0","time": 62},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/as_val/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/as_val/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
            {id:"eotech_xps2",cmd:"eotech_xps2",modifier:[\
                {entry:"state.ads_time",operation:"add",value:1},\
            ]}\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
            {id:"9x39mm_30round_magazine",cmd:"30round",modifier:[\
                {entry:"state.ammo_capacity",operation:"replace",value:30},\
            ]}\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}