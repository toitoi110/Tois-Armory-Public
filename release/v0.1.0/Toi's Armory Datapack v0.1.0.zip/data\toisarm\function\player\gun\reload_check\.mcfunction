    execute unless score @s toisarm.ammo_remaining = @s toisarm.state.ammo_capacity run tag @s add HAS_CAPACITY
    execute if score #toisarm.settings.reload_requires_ammo _ matches 1 run function toisarm:player/gun/reload_check/check_ammo_item
    execute unless score #toisarm.settings.reload_requires_ammo _ matches 1 run tag @s add ENOUGH_AMMO
    execute unless entity @s[tag=HAS_CAPACITY] run return run tag @s remove ENOUGH_AMMO
    tag @s remove HAS_CAPACITY
    execute unless entity @s[tag=ENOUGH_AMMO] run return 0
    tag @s remove ENOUGH_AMMO
    tag @s add toisarm.update_item_name
    execute if score @s toisarm.state.chamber matches 0 run return run function toisarm:player/gun/reload_check/start_normal_reload
    execute if score @s toisarm.chamber matches 0 run return run function toisarm:player/gun/reload_check/start_empty_reload
    scoreboard players operation @s toisarm.timer.reload = @s toisarm.state.reload
    execute if score @s toisarm.settings.reload_disable_ads matches 1 run tag @s remove toisarm.input.lclick
