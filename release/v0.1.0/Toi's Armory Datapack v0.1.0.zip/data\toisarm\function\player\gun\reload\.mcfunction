    execute if score @s toisarm.state.reload_loop matches 0.. run function toisarm:player/gun/reload/check_loop_reload
    execute if score @s toisarm.timer.reload_loop matches 0.. run return run function toisarm:player/gun/reload/loop
    scoreboard players set @s toisarm.timer.trigger -1
    execute if score @s toisarm.timer.reload matches 0 unless score @s toisarm.state.reload_loop matches 0.. run function toisarm:player/gun/reload/complete
    execute unless entity @s[scores={toisarm.timer.bolt_action=0..,toisarm.state.prioritize_bolt_action=1}] run scoreboard players remove @s[scores={toisarm.timer.reload=0..}] toisarm.timer.reload 1
    scoreboard players remove @s[scores={toisarm.timer.empty_reload=0..}] toisarm.timer.empty_reload 1
