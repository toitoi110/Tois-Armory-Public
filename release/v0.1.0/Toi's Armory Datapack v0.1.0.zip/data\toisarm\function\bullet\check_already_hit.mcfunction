$execute if data entity @n[tag=BULLET] data{hit_entity:["$(UUID)"]} run return run tag @s remove HIT
$data modify entity @n[tag=BULLET] data.hit_entity append value "$(UUID)"
