$$(command)
