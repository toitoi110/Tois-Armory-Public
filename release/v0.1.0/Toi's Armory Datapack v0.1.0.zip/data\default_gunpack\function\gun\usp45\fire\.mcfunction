
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:block.netherite_block.place",volume:0.76,pitch:0.5},\
{id:"minecraft:entity.hoglin.step",volume:0.8,pitch:0.73},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.05,pitch:0.75},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.4,pitch:0.2},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
{id:"minecraft:block.wooden_door.close",volume:0.6,pitch:1.3},\
{id:"minecraft:block.lever.click",volume:0.3,pitch:1.4},\
{id:"minecraft:block.wooden_trapdoor.open",volume:0.6,pitch:1.4},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.32,0.08,0],item_model:"toisarm:other/small_casing",offset:[-0.06,-0.17,0],pos:[-0.1,-0.01,0.55]}
function toisarm:util/ejection/
execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{toisarm:{state:{chamber:0b}}}}}}] anchored eyes positioned ^-0.1 ^ ^0.1 run playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.4 1.4 0
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.02 0.02 0.02 10000000000 1 force @a
