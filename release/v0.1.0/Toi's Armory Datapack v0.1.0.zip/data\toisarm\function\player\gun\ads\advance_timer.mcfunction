execute if score @s toisarm.timer.bolt_action_delay matches 0.. if score @s toisarm.timer.bolt_action_delay <= @s toisarm.state.end_ads_time run return 0
execute if score @s toisarm.after_sprint_ads_speed matches ..100 run return run scoreboard players add @s toisarm.timer.ads 100
scoreboard players operation @s _ = @s toisarm.after_sprint_ads_speed
scoreboard players operation @s _ /= 100 num
scoreboard players operation @s toisarm.timer.ads += @s _
