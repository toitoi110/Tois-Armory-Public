execute store result score @s toisarm.bullet.distance run data get entity @s data.damage_by_distance[5].distance 100
data modify entity @s data.damage set from entity @s data.damage_by_distance[5].damage
data modify entity @s data.crit_damage set from entity @s data.damage_by_distance[5].crit_damage
