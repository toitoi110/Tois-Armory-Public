    execute if predicate toisarm:is_sneaking run return run scoreboard players operation @s _ = @s toisarm.state.max_accuracy.sneak
    execute if predicate toisarm:is_proning run return run scoreboard players operation @s _ = @s toisarm.state.max_accuracy.prone
    scoreboard players operation @s _ = @s toisarm.state.max_accuracy.idle
