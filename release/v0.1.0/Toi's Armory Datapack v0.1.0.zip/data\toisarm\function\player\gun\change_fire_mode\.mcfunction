execute store result storage toisarm:temp fire_mode.index int 1 run scoreboard players add @s toisarm.state.modes_index 1
execute if score @s toisarm.state.modes_index >= @s toisarm.state.modes_array_length store result storage toisarm:temp fire_mode.index int 1 run scoreboard players set @s toisarm.state.modes_index 0
item modify entity @s weapon toisarm:gun/apply_modes_index
data modify storage toisarm:temp fire_mode.cmd set from storage toisarm:temp this_player.data.gun.state.change_fire_mode_cmd
function toisarm:player/gun/change_fire_mode/macro with storage toisarm:temp fire_mode
item modify entity @s weapon toisarm:gun/set_custom_model_data/6
tag @s add toisarm.update_item_name
