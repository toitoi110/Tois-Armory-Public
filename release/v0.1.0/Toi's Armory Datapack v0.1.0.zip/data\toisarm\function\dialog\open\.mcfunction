dialog show @s toisarm:menu
scoreboard players set @s toisarm.trigger.input -1
