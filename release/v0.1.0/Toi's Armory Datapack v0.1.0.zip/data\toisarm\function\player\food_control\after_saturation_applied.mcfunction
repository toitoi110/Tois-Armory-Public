effect clear @s saturation
tag @s remove toisarm.remove_saturation_queue
item replace entity @s[scores={toisarm.exhaustion=1..}] saddle with saddle[enchantments={vanishing_curse:1,binding_curse:1,"toisarm:apply_exhaustion":1},equippable={slot:"saddle",equip_sound:"intentionally_empty",dispensable:false,swappable:false,damage_on_hurt:false}]
