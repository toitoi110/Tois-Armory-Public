    execute if score @s toisarm.timer.ads matches 1.. run return run scoreboard players set @s toisarm.accuracy 1
    execute unless score @s toisarm.timer.ads matches 1.. run return run scoreboard players set @s toisarm.accuracy 200
    function toisarm:player/gun/set_accuracy/get_max/
    scoreboard players operation @s toisarm.max_accuracy += @s _
    execute store result score @s toisarm.min_accuracy run scoreboard players operation @s toisarm.max_accuracy /= 2 num
    execute if entity @s[predicate=toisarm:is_moving] run scoreboard players operation @s _ += @s toisarm.state.accuracy_delta.move
    execute if entity @s[predicate=!toisarm:is_moving,predicate=toisarm:is_sprinting] run scoreboard players operation @s _ += @s toisarm.state.accuracy_delta.sprint
    execute if entity @s[predicate=toisarm:is_jumping] run scoreboard players operation @s _ += @s toisarm.state.accuracy_delta.jump
    execute if score @s toisarm.timer.firing matches 0.. run scoreboard players operation @s _ += @s toisarm.state.accuracy_delta.fire
    scoreboard players operation @s toisarm.min_accuracy += @s _
    scoreboard players operation @s toisarm.min_accuracy /= 2 num
    execute if score @s toisarm.timer.ads matches 1.. run function toisarm:player/gun/set_accuracy/calcuate_ads_progress/
    execute if entity @s[predicate=toisarm:is_moving] run scoreboard players operation @s toisarm.accuracy_value += @s toisarm.state.accuracy_delta_rate.move
    execute if entity @s[predicate=!toisarm:is_moving,predicate=toisarm:is_sprinting] run scoreboard players operation @s toisarm.accuracy_value += @s toisarm.state.accuracy_delta_rate.sprint
    execute if entity @s[predicate=toisarm:is_jumping] run scoreboard players operation @s toisarm.accuracy_value += @s toisarm.state.accuracy_delta_rate.jump
    execute if score @s toisarm.accuracy_value < @s toisarm.max_accuracy run scoreboard players operation @s toisarm.accuracy_value = @s toisarm.max_accuracy
    execute if score @s toisarm.accuracy_value > @s toisarm.min_accuracy run scoreboard players operation @s toisarm.accuracy_value = @s toisarm.min_accuracy
    scoreboard players operation @s toisarm.accuracy = @s toisarm.accuracy_value
    scoreboard players operation @s toisarm.accuracy /= #num.10000 _
