$data modify storage toisarm:dialog attachment_item_slot append from entity @s Inventory[{components:{"minecraft:custom_data":{toisarm:{type:"attachment",id:"$(id)"}}}}] 
