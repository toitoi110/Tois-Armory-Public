execute if score @s toisarm.settings.rotate_comp.enable_semi matches 1 run return run scoreboard players set @s toisarm.settings.rotate_comp.enable_semi 0
scoreboard players set @s toisarm.settings.rotate_comp.enable_semi 1
