    data modify storage toisarm:data gun set from storage toisarm:import gun
    data modify storage toisarm:data attachment set from storage toisarm:import attachment
    data remove storage toisarm:import gun
    data remove storage toisarm:import attachment
    execute if entity @a[predicate=toisarm:has_gun_mainhand] run tag @a[predicate=toisarm:has_gun_mainhand] add CHANGED_SELECTED_SLOT
