advancement revoke @s only toisarm:placed_gun_crafting_slot
execute if predicate toisarm:placed_gun_crafting_slot/0 run function toisarm:advancement/placed_gun_crafting_slot/drop/0
execute if predicate toisarm:placed_gun_crafting_slot/1 run function toisarm:advancement/placed_gun_crafting_slot/drop/1
execute if predicate toisarm:placed_gun_crafting_slot/2 run function toisarm:advancement/placed_gun_crafting_slot/drop/2
execute if predicate toisarm:placed_gun_crafting_slot/3 run function toisarm:advancement/placed_gun_crafting_slot/drop/3
