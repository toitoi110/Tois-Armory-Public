execute if entity @e[distance=..1.5,type=hopper_minecart] run return run function toisarm:util/kill/
execute if block ~0.5 ~-0.5 ~0.5 hopper run return run function toisarm:util/kill/
execute if block ~-0.5 ~-0.5 ~0.5 hopper run return run function toisarm:util/kill/
execute if block ~0.5 ~-0.5 ~-0.5 hopper run return run function toisarm:util/kill/
execute if block ~-0.5 ~-0.5 ~-0.5 hopper run return run function toisarm:util/kill/
execute if block ~0.5 ~-1.5 ~0.5 hopper run return run function toisarm:util/kill/
execute if block ~-0.5 ~-1.5 ~0.5 hopper run return run function toisarm:util/kill/
execute if block ~0.5 ~-1.5 ~-0.5 hopper run return run function toisarm:util/kill/
execute if block ~-0.5 ~-1.5 ~-0.5 hopper run return run function toisarm:util/kill/
