data modify storage toisarm:import gun append value \
{\
    "id": "m700",\
    "display_name":"M700",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"SEMI","value":2}],\
        "ammo_type": "7.62x51mm",\
        "ammo_capacity": 6,\
        "ammo_count": 6,\
        "chamber": 1,\
        "manual_bolt_action": true,\
        "round_per_minute": 500,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.7.62x51mm",\
        "trail_id": "trail.default_gunpack.large",\
        "bullet_velocity": 27,\
        "bullet_drag": 0.1,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.006,\
        "damage_by_distance": [\
            {"distance":26,"damage":16.8,"crit_damage":21.8},\
            {"distance":48,"damage":20.0,"crit_damage":24.6},\
            {"distance":70,"damage":17.6,"crit_damage":22.4},\
            {"distance":180,"damage":16.2,"crit_damage":21.4},\
            {"distance":400,"damage":15.4,"crit_damage":20.8},\
        ],\
        "max_range": 400,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.225,1.2],\
        "trail_offset": [-0.12,-0.285,1.5],\
        \
        "reload_time": 48,\
        "empty_reload_time": 70,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 10,\
        "bolt_action_time": 14,\
        "swap_time": 26,\
        "ads_time": 10,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 8,\
        \
        "zoom": 2.5,\
        "zoom_ads_progress": 0.8,\
        "firing_anim": 8,\
        "bolt_move_anim": 0,\
        "bolt_hold_open": 0,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 115,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.51,\
        "bloom_max": 90,\
        "bloom_decay": 11,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.6,\
        "sway_yaw": 2.1,\
        "sway_pitch": 1.5,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0,\
        "shake_pitch": -0.15,\
        "shake_yaw_random": 0.12,\
        "shake_pitch_random": 0.02,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": -0.66, "pitch": -2.6},\
            {"yaw": -0.58, "pitch": -2.73},\
            {"yaw": 0.63, "pitch": -2.46},\
            {"yaw": 0.64, "pitch": -2.56},\
            {"yaw": 0.71, "pitch": -2.76},\
            {"yaw": 0.63, "pitch": -2.6, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 2,\
        "pitch_recoil_multiplier": 4,\
        "recoil_apply_tick": 3,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/m700/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/m700/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/m700/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/m700/reload",\
            "duration": 221,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.25 0", "time": 44},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.2 0", "time": 155},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.5 1.35 0", "time": 205},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/m700/empty_reload",\
            "duration": 314,\
            "commands": [\
                {"command": "data modify storage toisarm:ejection {} merge value {offset:[0,0,0],pos:[0.08,-0.2,0.45],motion:[-0.2,0.3,-0.03],item_model:\"toisarm:other/large_casing\"}","time": 36},\
                {"command": "function toisarm:util/ejection/","time": 36},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.65 0.8 0","time": 32},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0","time": 87},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.35 0","time": 199},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.65 0.8 0","time": 247},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.5 1.35 0", "time": 310},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/m700/bolt_action",\
            "duration": 76,\
            "commands":[\
                {"command": "data modify storage toisarm:ejection {} merge value {motion:[-0.20,0.21,-0.03],item_model:\"toisarm:other/large_casing\",offset:[0.0,0.0,0.0],pos:[-0.24,-0.31,0.6]}","time": 24},\
                {"command": "function toisarm:util/ejection/","time": 24},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.55 0.8 0","time": 24},\
            ]\
        },\
        "swap":{\
            "pass": "toisarm:gun/m700/swap",\
            "duration": 91,\
            "commands":[\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.5 1.35 0","time": 69},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/m700/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/m700/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
    ]\
}