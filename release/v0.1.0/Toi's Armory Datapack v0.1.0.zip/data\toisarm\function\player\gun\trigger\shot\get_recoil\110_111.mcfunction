execute if score @s toisarm.recoil.pattern_index matches 110 run function toisarm:player/gun/trigger/shot/get_recoil/110
execute if score @s toisarm.recoil.pattern_index matches 111 run function toisarm:player/gun/trigger/shot/get_recoil/111
