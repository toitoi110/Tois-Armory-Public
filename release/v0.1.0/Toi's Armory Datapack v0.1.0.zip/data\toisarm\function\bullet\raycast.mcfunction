execute if score @s toisarm.util.tp_z matches 2048.. positioned as @s run tp @s ^ ^ ^20.48
execute if score @s toisarm.util.tp_z matches 2048.. run scoreboard players remove @s toisarm.util.tp_z 2048
execute if score @s toisarm.util.tp_z matches 1024.. positioned as @s run tp @s ^ ^ ^10.24
execute if score @s toisarm.util.tp_z matches 1024.. run scoreboard players remove @s toisarm.util.tp_z 1024
execute if score @s toisarm.util.tp_z matches 512.. positioned as @s run tp @s ^ ^ ^5.12
execute if score @s toisarm.util.tp_z matches 512.. run scoreboard players remove @s toisarm.util.tp_z 512
execute if score @s toisarm.util.tp_z matches 256.. positioned as @s run tp @s ^ ^ ^2.56
execute if score @s toisarm.util.tp_z matches 256.. run scoreboard players remove @s toisarm.util.tp_z 256
execute if score @s toisarm.util.tp_z matches 128.. positioned as @s run tp @s ^ ^ ^1.28
execute if score @s toisarm.util.tp_z matches 128.. run scoreboard players remove @s toisarm.util.tp_z 128
execute if score @s toisarm.util.tp_z matches 64.. positioned as @s run tp @s ^ ^ ^0.64
execute if score @s toisarm.util.tp_z matches 64.. run scoreboard players remove @s toisarm.util.tp_z 64
execute if score @s toisarm.util.tp_z matches 32.. positioned as @s run tp @s ^ ^ ^0.32
execute if score @s toisarm.util.tp_z matches 32.. run scoreboard players remove @s toisarm.util.tp_z 32
execute if score @s toisarm.util.tp_z matches 16.. positioned as @s run tp @s ^ ^ ^0.16
execute if score @s toisarm.util.tp_z matches 16.. run scoreboard players remove @s toisarm.util.tp_z 16
execute if score @s toisarm.util.tp_z matches 8.. positioned as @s run tp @s ^ ^ ^0.08
execute if score @s toisarm.util.tp_z matches 8.. run scoreboard players remove @s toisarm.util.tp_z 8
execute if score @s toisarm.util.tp_z matches 4.. positioned as @s run tp @s ^ ^ ^0.04
execute if score @s toisarm.util.tp_z matches 4.. run scoreboard players remove @s toisarm.util.tp_z 4
execute if score @s toisarm.util.tp_z matches 2.. positioned as @s run tp @s ^ ^ ^0.02
execute if score @s toisarm.util.tp_z matches 2.. run scoreboard players remove @s toisarm.util.tp_z 2
execute if score @s toisarm.util.tp_z matches 1.. positioned as @s run tp @s ^ ^ ^0.01
execute if score @s toisarm.util.tp_z matches 1.. run scoreboard players remove @s toisarm.util.tp_z 1
execute if score @s toisarm.util.tp_y matches 1024.. positioned as @s run tp @s ~ ~-10.24 ~
execute if score @s toisarm.util.tp_y matches 1024.. run scoreboard players remove @s toisarm.util.tp_y 1024
execute if score @s toisarm.util.tp_y matches 512.. positioned as @s run tp @s ~ ~-5.12 ~
execute if score @s toisarm.util.tp_y matches 512.. run scoreboard players remove @s toisarm.util.tp_y 512
execute if score @s toisarm.util.tp_y matches 256.. positioned as @s run tp @s ~ ~-2.56 ~
execute if score @s toisarm.util.tp_y matches 256.. run scoreboard players remove @s toisarm.util.tp_y 256
execute if score @s toisarm.util.tp_y matches 128.. positioned as @s run tp @s ~ ~-1.28 ~
execute if score @s toisarm.util.tp_y matches 128.. run scoreboard players remove @s toisarm.util.tp_y 128
execute if score @s toisarm.util.tp_y matches 64.. positioned as @s run tp @s ~ ~-0.64 ~
execute if score @s toisarm.util.tp_y matches 64.. run scoreboard players remove @s toisarm.util.tp_y 64
execute if score @s toisarm.util.tp_y matches 32.. positioned as @s run tp @s ~ ~-0.32 ~
execute if score @s toisarm.util.tp_y matches 32.. run scoreboard players remove @s toisarm.util.tp_y 32
execute if score @s toisarm.util.tp_y matches 16.. positioned as @s run tp @s ~ ~-0.16 ~
execute if score @s toisarm.util.tp_y matches 16.. run scoreboard players remove @s toisarm.util.tp_y 16
execute if score @s toisarm.util.tp_y matches 8.. positioned as @s run tp @s ~ ~-0.08 ~
execute if score @s toisarm.util.tp_y matches 8.. run scoreboard players remove @s toisarm.util.tp_y 8
execute if score @s toisarm.util.tp_y matches 4.. positioned as @s run tp @s ~ ~-0.04 ~
execute if score @s toisarm.util.tp_y matches 4.. run scoreboard players remove @s toisarm.util.tp_y 4
execute if score @s toisarm.util.tp_y matches 2.. positioned as @s run tp @s ~ ~-0.02 ~
execute if score @s toisarm.util.tp_y matches 2.. run scoreboard players remove @s toisarm.util.tp_y 2
execute if score @s toisarm.util.tp_y matches 1.. positioned as @s run tp @s ~ ~-0.01 ~
execute if score @s toisarm.util.tp_y matches 1.. run scoreboard players remove @s toisarm.util.tp_y 1
execute facing entity @s feet positioned ~ ~ ~ summon marker run function toisarm:util/raycast/init
tp @s ~ ~ ~
