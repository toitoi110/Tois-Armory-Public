
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:item.shield.block",volume:0.1,pitch:0.8},\
{id:"minecraft:entity.hoglin.step",volume:0.3,pitch:0.75},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.04,pitch:0.65},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.5,pitch:0.5},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
{id:"minecraft:item.flintandsteel.use",volume:0.55,pitch:1.35},\
{id:"minecraft:block.scaffolding.break",volume:0.6,pitch:1.8},\
{id:"minecraft:block.wooden_door.close",volume:0.5,pitch:1.6},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.38,0.08,0],item_model:"toisarm:other/small_casing",offset:[-0.12,-0.17,0.2],pos:[-0.18,-0.22,0.6]}
function toisarm:util/ejection/
execute if entity @s[scores={toisarm.chamber=0}] anchored eyes positioned ^-0.1 ^ ^0.1 run playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.4 1.4 0
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 1 force @a
