
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:block.sweet_berry_bush.break",volume:0.5,pitch:1.84},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.2,pitch:0.6},\
{id:"minecraft:item.shield.block",volume:0.05,pitch:0.95},\
{id:"minecraft:entity.hoglin.step",volume:0.1,pitch:1.2},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:24,sounds:[\
{id:"minecraft:block.wooden_trapdoor.open",volume:0.5,pitch:0.9},\
{id:"minecraft:block.wooden_door.open",volume:0.5,pitch:1.8},\
{id:"minecraft:block.wooden_door.close",volume:0.6,pitch:1.4},\
]}

execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.37,0.07,-0.08],item_model:"toisarm:other/medium_casing",offset:[-0.2,-0.07,0.1],pos:[-0.2,-0.35,0.55]}
function toisarm:util/ejection/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.04 0.04 0.04 10000000000 2 force @a
