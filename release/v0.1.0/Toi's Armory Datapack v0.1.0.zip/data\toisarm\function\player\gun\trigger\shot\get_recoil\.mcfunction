execute if score @s toisarm.recoil.pattern_index matches -1 run function toisarm:player/gun/trigger/shot/get_recoil/-1
execute if score @s toisarm.recoil.pattern_index matches 0..63 run function toisarm:player/gun/trigger/shot/get_recoil/0_63
execute if score @s toisarm.recoil.pattern_index matches 64..127 run function toisarm:player/gun/trigger/shot/get_recoil/64_127
