summon marker ^ ^ ^ {Tags:["toisarm.bullet","BULLET_INIT"]}
scoreboard players remove @s _ 1
execute if score @s _ matches 1.. run function toisarm:player/gun/trigger/shot/generate_bullet
