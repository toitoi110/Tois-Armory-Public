$data modify storage toisarm:temp this_player.mode_display set from storage toisarm:temp this_player.data.gun.state.modes[$(index)].display
$execute store result score @s toisarm.fire_mode run data get storage toisarm:temp this_player.data.gun.state.modes[$(index)].value
scoreboard players operation @s toisarm.state.change_fire_mode = @s toisarm.state.default_change_fire_mode
$execute if data storage toisarm:temp this_player.data.gun.state.modes[$(index)].change_time store result score @s toisarm.state.change_fire_mode run data get storage toisarm:temp this_player.data.gun.state.modes[$(index)].change_time
$$(cmd)
