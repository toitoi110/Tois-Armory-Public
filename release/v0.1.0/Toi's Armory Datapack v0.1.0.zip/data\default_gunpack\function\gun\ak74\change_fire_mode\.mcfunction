

playsound minecraft:item.flintandsteel.use master @a ~ ~ ~ 1 1.6 0
playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 2 0