execute if score @s toisarm.settings.rotate_comp.max matches ..9 run return run scoreboard players add @s toisarm.settings.rotate_comp.max 1
execute if score @s toisarm.settings.rotate_comp.max matches 60.. run return run scoreboard players set @s toisarm.settings.rotate_comp.max 1
scoreboard players add @s toisarm.settings.rotate_comp.max 5
