data modify storage toisarm:dialog temp.slot set value {id:"minecraft:air"}
$data modify storage toisarm:dialog temp.slot set from entity @s Inventory[{Slot:$(Slot)b}]
execute store success score #toisarm.temp _ run data modify storage toisarm:dialog temp.slot set from storage toisarm:dialog attachment_item_slot
