execute if score @s toisarm.recoil.pattern_index matches 0 run function toisarm:player/gun/trigger/shot/get_recoil/0
execute if score @s toisarm.recoil.pattern_index matches 1 run function toisarm:player/gun/trigger/shot/get_recoil/1
