    item modify entity @s weapon toisarm:gun/set_chamber/1
    scoreboard players set @s toisarm.chamber 1
    tag @s add toisarm.update_item_name
    scoreboard players set @s toisarm.timer.bolt_action_delay -1
    execute if score @s toisarm.ammo_remaining matches 1.. if score @s toisarm.chamber matches 1 run scoreboard players set @s toisarm.shootable 1
