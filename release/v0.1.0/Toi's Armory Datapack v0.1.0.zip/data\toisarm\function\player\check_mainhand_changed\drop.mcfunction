tag @s add toisarm.input.drop
tag @s add toisarm.input
execute as @e[distance=..64,type=item,tag=!toisarm.checked_item,nbt={Item:{components:{"minecraft:custom_data":{"toisarm":{"type":"gun"}}}}}] if data entity @s Thrower run function toisarm:player/check_mainhand_changed/as_item
tag @n[distance=..64,type=item,tag=MATCH_ID] add THIS_ITEM
item replace entity @s weapon from entity @n[distance=..64,type=item,tag=THIS_ITEM] container.0
kill @n[distance=..64,type=item,tag=THIS_ITEM]
tag @e[distance=..64,type=item,tag=MATCH_ID] remove MATCH_ID
