execute if score @s toisarm.recoil.pattern_index matches 116 run function toisarm:player/gun/trigger/shot/get_recoil/116
execute if score @s toisarm.recoil.pattern_index matches 117 run function toisarm:player/gun/trigger/shot/get_recoil/117
