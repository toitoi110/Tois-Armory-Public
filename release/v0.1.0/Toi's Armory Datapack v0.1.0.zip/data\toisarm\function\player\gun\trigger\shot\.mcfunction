    scoreboard players remove @s toisarm.fire_rate 100
    scoreboard players add @s _ 1
    execute if score @s toisarm.state.chamber matches ..0 run function toisarm:player/gun/trigger/shot/remove_ammo/no_chambered/
    execute if score @s toisarm.state.chamber matches 1 run function toisarm:player/gun/trigger/shot/remove_ammo/chambered/
    execute if score @s toisarm.recoil.pattern_index matches 0.. run scoreboard players add @s toisarm.recoil.pattern_index 1
    execute if entity @s[scores={toisarm.state.manual_bolt_action=0,toisarm.fire_rate=100..,toisarm.shootable=1}] run return run function toisarm:player/gun/trigger/shot/
    tag @s add toisarm.update_item_name
    scoreboard players set @s toisarm.timer.firing 1
    scoreboard players set @s toisarm.timer.reset_recoil_pattern 20
    scoreboard players operation @s _ *= @s toisarm.state.projectiles_per_shot
    execute if score @s _ matches 1.. run function toisarm:player/gun/trigger/shot/generate_bullet
    execute as @e[distance=..0.1,type=marker,tag=BULLET_INIT] at @s run function toisarm:player/gun/trigger/shot/bullet_initialize
        function toisarm:player/gun/trigger/shot/get_recoil/
        scoreboard players set @s toisarm.recoil.progress_per_tick 1000
        scoreboard players operation @s toisarm.recoil.progress_per_tick /= @s toisarm.state.recoil_apply_tick
        scoreboard players operation @s toisarm.recoil.progress = @s toisarm.recoil.progress_per_tick
        scoreboard players operation @s toisarm.recoil.progress *= -1 num
        scoreboard players add @s toisarm.recoil.progress 1000
        scoreboard players operation @s toisarm.timer.recoil_apply_tick = @s toisarm.state.recoil_apply_tick
    scoreboard players operation @s _ = @s toisarm.state.bloom_max
    scoreboard players operation @s _ -= @s toisarm.bloom
    scoreboard players operation @s _ *= @s toisarm.state.bloom_increase_rate
    scoreboard players operation @s _ /= 100 num
    scoreboard players operation @s toisarm.bloom += @s _
    scoreboard players set @s toisarm.bloom_decay 100
    execute unless score @s toisarm.shake_yaw_flip matches 1 run scoreboard players set @s toisarm.shake_yaw_flip 2
    execute if score @s toisarm.shake_yaw_flip matches 1 run scoreboard players set @s toisarm.shake_yaw_flip 0
    scoreboard players remove @s toisarm.shake_yaw_flip 1
    execute store result score @s _ run random value -10000..10000
    execute if score @s _ matches ..-1 run tag @s add FLIP
    scoreboard players operation @s _ %= @s toisarm.state.shake_yaw_random
    execute if entity @s[tag=FLIP] run scoreboard players operation @s _ *= -1 num
    scoreboard players operation @s _ += @s toisarm.state.shake_yaw
    scoreboard players operation @s _ *= @s toisarm.shake_yaw_flip
    scoreboard players operation @s toisarm.shake_yaw += @s _
    tag @s remove FLIP
    execute store result score @s _ run random value -10000..10000
    execute if score @s _ matches ..-1 run tag @s add FLIP
    scoreboard players operation @s _ %= @s toisarm.state.shake_pitch_random
    execute if entity @s[tag=FLIP] run scoreboard players operation @s _ *= -1 num
    scoreboard players operation @s _ += @s toisarm.state.shake_pitch
    scoreboard players operation @s toisarm.shake_pitch += @s _
    tag @s remove FLIP
    scoreboard players set @s toisarm.shake_yaw_decay 100
    scoreboard players set @s toisarm.shake_pitch_decay 100
    scoreboard players set @s toisarm.shake_yaw_decaying 0
    scoreboard players set @s toisarm.shake_pitch_decaying 0
    scoreboard players operation @s toisarm.timer.bolt_move_anim = @s toisarm.state.bolt_move_anim
    execute if score @s toisarm.timer.firing_anim_delay matches ..-1 run scoreboard players operation @s toisarm.timer.firing_anim = @s toisarm.state.firing_anim
    execute if score @s toisarm.timer.firing_anim_delay matches ..-1 run scoreboard players operation @s toisarm.timer.firing_anim_delay = @s toisarm.state.firing_anim_delay
    data remove storage toisarm:temp bullet_state
