    scoreboard players set @s toisarm.after_sprint_ads_speed 10000
    scoreboard players operation @s toisarm.after_sprint_ads_speed *= @s toisarm.timer.sprint
    scoreboard players operation @s toisarm.after_sprint_ads_speed /= @s toisarm.state.sprint
    scoreboard players add @s toisarm.after_sprint_ads_speed 10000
    scoreboard players operation @s toisarm.after_sprint_ads_speed *= 7 num
    scoreboard players operation @s toisarm.after_sprint_ads_speed /= 10 num
