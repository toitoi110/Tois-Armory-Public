$data modify storage toisarm:temp this_player set from storage toisarm:private $(id)
