execute if score @s toisarm.settings.reload_disable_ads matches 0 run return run scoreboard players set @s toisarm.settings.reload_disable_ads 1
scoreboard players set @s toisarm.settings.reload_disable_ads 0
