data modify storage toisarm:import gun append value \
{\
    "id": "ak74",\
    "display_name":"AK-74M",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"SEMI","value":2}],\
        "ammo_type": "5.45x39mm",\
        "ammo_capacity": 30,\
        "ammo_count": 30,\
        "chamber": 1,\
        "round_per_minute": 650,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.5.45x39mm",\
        "trail_id": "trail.default_gunpack.medium",\
        "bullet_velocity": 30,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.005,\
        "damage_by_distance": [\
            {"distance":12,"damage":5.2,"crit_damage":6.76},\
            {"distance":22,"damage":4.8,"crit_damage":6.24},\
            {"distance":38,"damage":4.3,"crit_damage":5.6},\
            {"distance":80,"damage":3.5,"crit_damage":4.55},\
            {"distance":400,"damage":3,"crit_damage":3.9},\
        ],\
        "max_range": 125,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.195,0.9],\
        "trail_offset": [-0.12,-0.255,1.2],\
        \
        "reload_time": 38,\
        "empty_reload_time": 52,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 18,\
        "swap_time": 12,\
        "ads_time": 8,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 6,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 0,\
        "bolt_hold_open": 0,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 82,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.3,\
        "bloom_max": 120,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.9,\
        "sway_yaw": 1.6,\
        "sway_pitch": 1.1,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.15,\
        "shake_pitch": -0.1,\
        "shake_yaw_random": 0.04,\
        "shake_pitch_random": 0.04,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": -0.125, "pitch": -1.375},\
            {"yaw": -0.25, "pitch": -1.338},\
            {"yaw": -0.25, "pitch": -1.212},\
            {"yaw": -0.125, "pitch": -1.175},\
            {"yaw": 0.125, "pitch": -0.95},\
            {"yaw": 0.1, "pitch": -0.775},\
            {"yaw": 0.12, "pitch": -0.69},\
            {"yaw": 0.17, "pitch": -0.708},\
            {"yaw": 0.16, "pitch": -0.775},\
            {"yaw": 0.12, "pitch": -0.85},\
            {"yaw": 0.1, "pitch": -0.95},\
            {"yaw": 0.075, "pitch": -1.0},\
            {"yaw": 0.225, "pitch": -1.078},\
            {"yaw": 0.15, "pitch": -1.05},\
            {"yaw": 0.15, "pitch": -0.99},\
            {"yaw": 0.15, "pitch": -0.98},\
            {"yaw": 0.15, "pitch": -0.96, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 6.2,\
        "pitch_recoil_multiplier": 2.05,\
        "recoil_apply_tick": 2,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/ak74/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/ak74/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/ak74/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/ak74/reload",\
            "duration": 144,\
            "commands": [\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.55 0", "time": 28},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.1 1.1 0", "time": 81},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.5 0", "time": 94},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 131},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/ak74/empty_reload",\
            "duration": 186,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 35},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.1 0","time": 38},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.4 0","time": 41},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.35 0","time": 83},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.3 0","time": 140},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.1 0","time": 146},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.3 1.5 0", "time": 160},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 182},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/ak74/bolt_action",\
            "duration": 69,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 0.75 0","time": 25},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/ak74/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/ak74/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.35 1.45 0","time": 62},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.25 1.45 0","time": 63},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/ak74/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/ak74/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
        ]},\
        {slot:"rear_grip", list: [\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}