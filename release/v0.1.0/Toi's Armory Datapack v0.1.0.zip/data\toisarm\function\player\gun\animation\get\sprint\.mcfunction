scoreboard players operation @s toisarm.animation = @s toisarm.timer.sprint
execute unless score @s toisarm.animation_id matches 7 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 7
