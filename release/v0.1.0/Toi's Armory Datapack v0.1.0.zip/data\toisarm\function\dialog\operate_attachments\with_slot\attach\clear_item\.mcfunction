$item replace entity @s container.$(Slot) with air
