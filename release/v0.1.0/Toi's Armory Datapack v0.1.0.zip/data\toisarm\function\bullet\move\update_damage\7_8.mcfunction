execute if score @s toisarm.bullet.distance_damage_index matches 7 run return run function toisarm:bullet/move/update_damage/7
function toisarm:bullet/move/update_damage/8
