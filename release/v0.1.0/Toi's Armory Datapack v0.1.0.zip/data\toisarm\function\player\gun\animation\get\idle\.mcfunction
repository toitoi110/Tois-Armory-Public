    execute unless score @s toisarm.animation_id matches 0 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 0
    tag @s add IDLE
    execute unless score @s toisarm.animation_changed matches 1 run return 0
    data modify storage toisarm:temp animation_frame set value 0
    item modify entity @s weapon toisarm:gun/set_custom_model_data/0
    item replace entity 0-0-0-0-1ae1e container.0 from entity @s weapon
    data modify entity 0-0-0-0-1ae1e item.components."minecraft:item_model" set from storage toisarm:temp this_player.data.gun.animation.idle.pass
    item replace entity @s weapon from entity 0-0-0-0-1ae1e container.0
