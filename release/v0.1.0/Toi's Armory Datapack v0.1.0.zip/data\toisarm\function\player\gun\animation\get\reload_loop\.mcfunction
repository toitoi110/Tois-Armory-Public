scoreboard players operation @s toisarm.animation = @s toisarm.state.reload_loop
scoreboard players operation @s toisarm.animation -= @s toisarm.timer.reload_loop
execute unless score @s toisarm.animation_id matches 6 store success score @s toisarm.animation_changed run scoreboard players set @s toisarm.animation_id 6
