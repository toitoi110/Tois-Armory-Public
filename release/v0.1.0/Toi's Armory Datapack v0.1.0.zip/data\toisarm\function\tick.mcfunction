    execute as @a[predicate=!toisarm:has_id] run function toisarm:initialize
    execute unless entity 0-0-0-0-1ae1e run summon item_display 0.0 0.0 0.0 {Tags:["toisarm.util_display"],UUID:[I;0,0,0,110110]}
    execute as @e[type=item_display,tag=toisarm.sliding_pull_entity,tag=KILL] at @s run function toisarm:util/void_kill_passenger/
    tag @e[type=item_display,tag=toisarm.sliding_pull_entity] add KILL
    tag @a remove toisarm.sprint_blocked
    execute as @a at @s run function toisarm:player/tick
    execute as @e[type=marker,tag=toisarm.bullet] at @s run function toisarm:bullet/tick
    execute as @a[tag=toisarm.hit_own_bullet] at @s as @n[limit=2] run playsound minecraft:block.packed_mud.break master @p ~ ~ ~ 2 1.17
    tag @a remove toisarm.hit_own_bullet
    tag @a remove FUNCTION_EXECUTED
    execute if entity @n[type=marker,tag=!KEEP,tag=toisarm.delay_marker] run kill @n[type=marker,tag=!KEEP,tag=toisarm.delay_marker]
    tag @e[type=marker,tag=KEEP,tag=toisarm.delay_marker] remove KEEP
