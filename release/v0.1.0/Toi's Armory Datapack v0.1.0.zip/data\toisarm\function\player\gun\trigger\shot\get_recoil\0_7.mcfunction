execute if score @s toisarm.recoil.pattern_index matches 0..3 run function toisarm:player/gun/trigger/shot/get_recoil/0_3
execute if score @s toisarm.recoil.pattern_index matches 4..7 run function toisarm:player/gun/trigger/shot/get_recoil/4_7
