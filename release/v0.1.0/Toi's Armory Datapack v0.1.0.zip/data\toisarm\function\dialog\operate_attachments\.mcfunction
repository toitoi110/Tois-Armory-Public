execute store result storage toisarm:dialog temp.count int 1 run scoreboard players get @s toisarm.trigger.operate_attachment
execute if score @s toisarm.trigger.operate_attachment matches 1000 run data modify storage toisarm:dialog temp.count set value 0
function toisarm:dialog/operate_attachments/with_index/ with storage toisarm:dialog temp
function toisarm:dialog/operate_attachments/with_slot/ with storage toisarm:dialog attachment_item_slot
data remove storage toisarm:dialog temp
data remove storage toisarm:dialog attachment_item_slot
scoreboard players set @s toisarm.trigger.operate_attachment -1
scoreboard players set @s toisarm.trigger.input 1
