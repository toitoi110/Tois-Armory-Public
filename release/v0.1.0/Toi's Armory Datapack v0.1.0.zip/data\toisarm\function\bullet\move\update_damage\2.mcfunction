execute store result score @s toisarm.bullet.distance run data get entity @s data.damage_by_distance[2].distance 100
data modify entity @s data.damage set from entity @s data.damage_by_distance[2].damage
data modify entity @s data.crit_damage set from entity @s data.damage_by_distance[2].crit_damage
