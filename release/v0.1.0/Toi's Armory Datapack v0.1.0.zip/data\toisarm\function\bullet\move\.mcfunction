    scoreboard players add @s toisarm.bullet.distance_traveled 30
    execute if score @s toisarm.bullet.distance_traveled >= @s toisarm.bullet.max_range run return run tag @s add OUT_OF_RANGE
    execute if score @s toisarm.bullet.distance_traveled >= @s toisarm.bullet.distance run function toisarm:bullet/move/update_damage/
    execute positioned ~-0.1 ~-0.1 ~-0.1 if entity @n[type=!#toisarm:unhurtable,dx=0,tag=!HIT] as @e[type=!#toisarm:unhurtable,dx=0,tag=!HIT] positioned ~-0.8 ~-0.8 ~-0.8 if entity @s[dx=0] positioned ~0.9 ~0.9 ~0.9 run function toisarm:bullet/move/check_hit
    scoreboard players remove @s toisarm.bullet.velocity_remaining 30
    function #toisarm:bullet/trail
    execute if score @s toisarm.bullet.velocity_remaining matches 30.. positioned ^ ^ ^0.30 run return run function toisarm:bullet/move/
    tp @s ~ ~ ~ ~ ~
