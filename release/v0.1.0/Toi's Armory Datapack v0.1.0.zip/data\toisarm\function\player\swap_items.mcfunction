item replace entity 0-0-0-0-1ae1e container.0 from entity @s weapon.offhand
item replace entity @s weapon.offhand from entity @s weapon.mainhand
item replace entity @s weapon.mainhand from entity 0-0-0-0-1ae1e container.0
tag @s add toisarm.input.swap
tag @s add toisarm.input
