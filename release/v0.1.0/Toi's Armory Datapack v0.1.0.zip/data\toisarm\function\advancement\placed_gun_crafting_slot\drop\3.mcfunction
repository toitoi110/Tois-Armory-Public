summon item ~ ~ ~ {Tags:["THIS"],Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_data":{toisarm:error}}}}
item replace entity @n[distance=..1,type=item,tag=THIS] container.0 from entity @s player.crafting.3
item replace entity @s player.crafting.3 with air
tag @n[distance=..1,type=item,tag=THIS] remove THIS
