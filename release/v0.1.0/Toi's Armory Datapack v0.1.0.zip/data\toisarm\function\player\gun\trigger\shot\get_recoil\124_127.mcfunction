execute if score @s toisarm.recoil.pattern_index matches 124..125 run function toisarm:player/gun/trigger/shot/get_recoil/124_125
execute if score @s toisarm.recoil.pattern_index matches 126..127 run function toisarm:player/gun/trigger/shot/get_recoil/126_127
