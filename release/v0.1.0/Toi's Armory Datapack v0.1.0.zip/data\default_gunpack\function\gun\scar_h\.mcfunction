data modify storage toisarm:import gun append value \
{\
    "id": "scar_h",\
    "display_name":"SCAR-H",\
    "state": {\
        \
        "default_change_fire_mode_time": 4,\
        "modes": [{"display":"AUTO","value":1},{"display":"SEMI","value":2}],\
        "ammo_type": "7.62x51mm",\
        "ammo_capacity": 25,\
        "ammo_count": 25,\
        "chamber": 1,\
        "round_per_minute": 550,\
        \
        "projectiles_per_shot": 1,\
        "bullet_id": "bullet.default_gunpack.7.62x51mm",\
        "trail_id": "trail.default_gunpack.large",\
        "bullet_velocity": 25,\
        "bullet_drag": 0.2,\
        "bullet_gravity": 0,\
        "bullet_weight": -0.005,\
        "damage_by_distance": [\
            {"distance":12,"damage":5.2,"crit_damage":6.76},\
            {"distance":22,"damage":4.8,"crit_damage":6.24},\
            {"distance":38,"damage":4.3,"crit_damage":5.6},\
            {"distance":80,"damage":3.5,"crit_damage":4.55},\
            {"distance":400,"damage":3,"crit_damage":3.9},\
        ],\
        "max_range": 125,\
        "bullet_penetration": 0,\
        "trail_pos": [0,-0.28,1.2],\
        "trail_offset": [-0.13,-0.29,1.2],\
        \
        "reload_time": 44,\
        "empty_reload_time": 64,\
        \
        "reload_loop_time": -1,\
        \
        "bolt_action_delay": 0,\
        "bolt_action_time": 18,\
        "swap_time": 14,\
        "ads_time": 9,\
        "end_ads_time": -1,\
        "sprint_time": 7,\
        "end_sprint_time": 8,\
        \
        "firing_anim": 4,\
        "firing_anim_delay": 1,\
        "bolt_move_anim": 1,\
        "bolt_hold_open": 1,\
        \
        "accuracy_ads": 0,\
        "accuracy_idle": 95,\
        "accuracy_multiplier_move": 0.15,\
        "bloom_increase_rate": 0.31,\
        "bloom_max": 120,\
        "bloom_decay": 15,\
        \
        "move_sway": 0,\
        \
        "sway_multiplier": 0.6,\
        "sway_yaw": 1.7,\
        "sway_pitch": 1.3,\
        \
        "shake_multiplier": 1,\
        "shake_yaw": 0.52,\
        "shake_pitch": -0.15,\
        "shake_yaw_random": 0.14,\
        "shake_pitch_random": 0.04,\
        "shake_yaw_decay": 0.1,\
        "shake_pitch_decay": 0.1,\
        \
        "recoil_pattern": [\
            {"yaw": 0.16, "pitch": -0.58},\
            {"yaw": 0.2, "pitch": -0.6},\
            {"yaw": 0.0, "pitch": -0.62},\
            {"yaw": -0.14, "pitch": -0.63},\
            {"yaw": -0.21, "pitch": -0.64},\
            {"yaw": -0.2, "pitch": -0.66},\
            {"yaw": -0.12, "pitch": -0.67},\
            {"yaw": 0.16, "pitch": -0.64},\
            {"yaw": 0.22, "pitch": -0.61},\
            {"yaw": 0.36, "pitch": -0.59},\
            {"yaw": 0.49, "pitch": -0.59},\
            {"yaw": 0.5, "pitch": -0.58},\
            {"yaw": 0.46, "pitch": -0.57},\
            {"yaw": 0.27, "pitch": -0.57},\
            {"yaw": 0.15, "pitch": -0.56},\
            {"yaw": -0.14, "pitch": -0.55},\
            {"yaw": -0.21, "pitch": -0.55},\
            {"yaw": -0.22, "pitch": -0.54},\
            {"yaw": -0.18, "pitch": -0.53},\
            {"yaw": 0.0, "pitch": -0.52},\
            {"yaw": 0.12, "pitch": -0.51},\
            {"yaw": 0.26, "pitch": -0.50},\
            {"yaw": 0.33, "pitch": -0.48},\
            {"yaw": 0.23, "pitch": -0.45},\
            {"yaw": 0.18, "pitch": -0.41},\
            {"yaw": -0.26, "pitch": -0.37},\
            {"yaw": -0.31, "pitch": -0.32, "repeat":{} }\
        ],\
        "yaw_recoil_multiplier": 2.8,\
        "pitch_recoil_multiplier": 3.8,\
        "recoil_apply_tick": 2,\
        \
        "movement_speed": 0.93,\
        "ads_movement_speed": 0.85,\
        \
        "fire_cmd": "function default_gunpack:gun/scar_h/fire/",\
        "change_fire_mode_cmd": "function default_gunpack:gun/scar_h/change_fire_mode/",\
    },\
    "animation": {\
        "idle":{\
            "pass": "toisarm:gun/scar_h/idle"\
        },\
        "reload":{\
            "pass": "toisarm:gun/scar_h/reload",\
            "duration": 176,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 15},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.5 0", "time": 74},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.6 0", "time": 110},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 169},\
            ]\
        },\
        "empty_reload":{\
            "pass": "toisarm:gun/scar_h/empty_reload",\
            "duration": 221,\
            "commands": [\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.1 0", "time": 7},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.35 1.7 0","time": 33},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.6 0","time": 91},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 1.6 0","time": 118},\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 0.9 0","time": 169},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.4 1.2 0", "time": 210},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 210},\
            ]\
        },\
        "bolt_action":{\
            "pass": "toisarm:gun/scar_h/bolt_action",\
            "duration": 76,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.5 0.9 0","time": 32},\
                {"command": "scoreboard players set @s toisarm.timer.bolt_move_anim 0","time": 32},\
            ]\
        },\
        "change_fire_mode":{\
            "pass": "toisarm:gun/scar_h/change_fire_mode",\
            "duration": 10,\
        },\
        "swap":{\
            "pass": "toisarm:gun/scar_h/swap",\
            "duration": 74,\
            "commands":[\
                {"command": "playsound minecraft:block.iron_door.open master @a ~ ~ ~ 0.3 1.7 0","time": 62},\
                {"command": "playsound minecraft:item.armor.equip_generic master @a ~ ~ ~ 0.35 1.55 0","time": 62},\
            ]\
        },\
        "ads":{\
            "pass": "toisarm:gun/scar_h/ads",\
            "duration": 61,\
        },\
        "sprint":{\
            "pass": "toisarm:gun/scar_h/sprint",\
            "duration": 31,\
        },\
    },\
    "attachment": [\
        {slot:"receiver", list: [\
        ]},\
        {slot:"sight", list: [\
            {id:"eotech_xps2",cmd:"eotech_xps2",modifier:[\
                {entry:"state.ads_time",operation:"add",value:1},\
            ]},\
        ]},\
        {slot:"barrel", list: [\
        ]},\
        {slot:"magazine", list: [\
            {id:"scar_h_drum_magazine",cmd:"scar_h_drum_magazine",modifier:[\
                {entry:"state.ads_time",operation:"add",value:1},\
                {entry:"state.ammo_capacity",operation:"replace",value:50}\
            ]},\
            {id:"infinity_magazine",cmd:"default",modifier:[\
                {entry:"state.ammo_capacity",operation:"replace",value:9999}\
            ]},\
        ]},\
        {slot:"rear_grip", list: [\
            {id:"no_recoil_grip",cmd:"default",modifier:[\
                {entry:"state.yaw_recoil_multiplier",operation:"scaling",value:0},\
                {entry:"state.pitch_recoil_multiplier",operation:"scaling",value:0},\
                {entry:"state.round_per_minute",operation:"replace",value:5000}\
            ]},\
        ]},\
        {slot:"stock", list: [\
        ]},\
        {slot:"underbarrel", list: [\
        ]},\
        {slot:"accessory", list: [\
        ]},\
    ]\
}