
data modify storage toisarm:sound {} merge value {max_distance:96,sounds:[\
{id:"minecraft:item.shield.block",volume:0.4,pitch:0.2},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.35,pitch:0.05},\
{id:"minecraft:entity.hoglin.step",volume:0.8,pitch:0.3},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.055,pitch:0.8},\
{id:"minecraft:entity.iron_golem.death",volume:0.03,pitch:1.1},\
{id:"minecraft:block.pointed_dripstone.land",volume:1,pitch:1.75},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:48,sounds:[\
{id:"minecraft:block.pointed_dripstone.land",volume:0.5,pitch:1.75},\
{id:"minecraft:block.copper_grate.hit",volume:0.26,pitch:1.05},\
{id:"minecraft:entity.iron_golem.repair",volume:0.3,pitch:0.7},\
{id:"minecraft:block.wooden_door.close",volume:0.6,pitch:1.45},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 13
execute at @s run function toisarm:util/flash/
data modify storage toisarm:ejection {} merge value {motion:[-0.38,0.05,-0.05],item_model:"toisarm:other/large_casing",offset:[-0.12,-0.05,0.05],pos:[-0.22,-0.16,0.65]}
function toisarm:util/ejection/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.06 0.06 0.06 10000000000 6 force @a
