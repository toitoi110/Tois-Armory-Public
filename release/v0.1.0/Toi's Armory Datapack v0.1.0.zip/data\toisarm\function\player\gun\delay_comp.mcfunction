    execute store result score #prev_y _ run data get entity @n[type=marker,tag=DELAY_MARKER] Rotation[0] 100
    execute store result score #prev_p _ run data get entity @n[type=marker,tag=DELAY_MARKER] Rotation[1] 100
    execute rotated as @s run rotate @n[type=marker,tag=DELAY_MARKER] ~ ~
    execute store result score #this_y _ run data get entity @n[type=marker,tag=DELAY_MARKER] Rotation[0] 100
    execute store result score #this_p _ run data get entity @n[type=marker,tag=DELAY_MARKER] Rotation[1] 100
    scoreboard players operation #this_y _ -= #prev_y _
    scoreboard players operation #this_p _ -= #prev_p _
    execute if score #this_y _ matches 18000.. run scoreboard players remove #this_y _ 36000
    execute if score #prev_y _ matches 18000.. run scoreboard players remove #prev_y _ 36000
    execute if score #this_y _ matches ..-18000 run scoreboard players add #this_y _ 36000
    execute if score #prev_y _ matches ..-18000 run scoreboard players add #prev_y _ 36000
    scoreboard players set @s _ 100
    scoreboard players operation @s _ -= @s toisarm.settings.rotate_comp.noise_sup
    scoreboard players operation #this_y _ *= @s _
    scoreboard players operation #this_p _ *= @s _
    scoreboard players operation @s toisarm.smooth_diff_y *= @s toisarm.settings.rotate_comp.noise_sup
    scoreboard players operation @s toisarm.smooth_diff_p *= @s toisarm.settings.rotate_comp.noise_sup
    scoreboard players operation @s toisarm.smooth_diff_y += #this_y _
    scoreboard players operation @s toisarm.smooth_diff_p += #this_p _
    scoreboard players operation @s toisarm.smooth_diff_y /= 100 num
    scoreboard players operation @s toisarm.smooth_diff_p /= 100 num
