    scoreboard players operation @s toisarm.min_accuracy -= @s toisarm.state.max_accuracy.ads
    scoreboard players set @s[scores={toisarm.min_accuracy=..0}] toisarm.min_accuracy 1
    scoreboard players operation @s toisarm.min_accuracy /= #num.10000 _
    scoreboard players operation @s toisarm.min_accuracy *= @s toisarm.ads_progress
    scoreboard players operation @s toisarm.min_accuracy += @s toisarm.state.max_accuracy.ads
