scoreboard players set #toisarm.temp _ 0
$execute unless score @s toisarm.trigger.operate_attachment matches 1000 run function toisarm:dialog/operate_attachments/with_slot/check_consistence/ {Slot:$(Slot)}
execute if score #toisarm.temp _ matches 1 run return run tellraw @s {"translate":"message.toisarm.error","color":"red","fallback":"An error has occurred."}
item replace entity 0-0-0-0-1ae1e container.0 from entity @s weapon
function toisarm:dialog/operate_attachments/with_slot/remove_attachment/ with storage toisarm:dialog attachment_item_slot.components."minecraft:custom_data".toisarm
execute unless score @s toisarm.trigger.operate_attachment matches 1000 run function toisarm:dialog/operate_attachments/with_slot/attach/
item replace entity @s weapon from entity 0-0-0-0-1ae1e container.0
