execute if entity @s[tag=FUNCTION_EXECUTED] run return 0
tag @s add FUNCTION_EXECUTED
data modify storage toisarm:sound {} merge value {max_distance:64,sounds:[\
{id:"minecraft:item.shield.block",volume:0.3,pitch:0.17},\
{id:"minecraft:entity.breeze.wind_burst",volume:0.17,pitch:0.85},\
{id:"minecraft:entity.firework_rocket.blast",volume:0.33,pitch:0.3},\
{id:"minecraft:entity.iron_golem.repair",volume:0.16,pitch:0.2},\
{id:"minecraft:entity.hoglin.step",volume:1,pitch:0.4},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
data modify storage toisarm:sound {} merge value {max_distance:32,sounds:[\
{id:"minecraft:entity.hoglin.step",volume:0.6,pitch:0.4},\
{id:"minecraft:item.shield.block",volume:0.2,pitch:0.17},\
{id:"minecraft:block.wooden_door.close",volume:0.85,pitch:0.35},\
{id:"minecraft:block.wooden_trapdoor.open",volume:1.15,pitch:0.6},\
{id:"minecraft:block.copper_grate.hit",volume:0.8,pitch:1.75},\
{id:"minecraft:block.lever.click",volume:0.55,pitch:1.8},\
]}
execute positioned ^ ^ ^1 run function toisarm:util/custom_distance_sound/with_storage
scoreboard players set @s toisarm.util.light_level 10
execute at @s run function toisarm:util/flash/
particle dust_color_transition{from_color:[1.0,0.75,0.3],to_color:[0.9,0.9,0.9],scale:0.2} ^ ^ ^ 0.025 0.025 0.025 0 10 force @a
particle minecraft:white_smoke ^ ^ ^ 0.02 0.02 0.02 0.025 2 force @a
