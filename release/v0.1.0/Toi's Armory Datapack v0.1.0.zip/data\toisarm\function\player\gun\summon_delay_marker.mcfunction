summon marker ~ ~ ~ {Tags:["toisarm.delay_marker"]}
scoreboard players operation @n[tag=toisarm.delay_marker] toisarm.id = @s toisarm.id
