$give @s knowledge_book[!minecraft:rarity,item_model="$(item_model)",item_name=$(display_name),custom_data={toisarm:{type:attachment,id:"$(id)",slot:$(slot)}}]
