$data modify storage toisarm:dialog attachment_list append value {label:$(display_name),width:150,action:{type:"minecraft:run_command",command:"trigger toisarm.trigger.get_attachment set $(count)"}}
$data modify storage toisarm:dialog attachment_data append value {id:"$(id)"}
data remove storage toisarm:dialog attachment[0]
execute store result storage toisarm:dialog attachment[0].count int 1 run scoreboard players add #toisarm.temp _ 1
execute if data storage toisarm:dialog attachment[0] run function toisarm:dialog/get_attachment/add_to_list/ with storage toisarm:dialog attachment[0]
