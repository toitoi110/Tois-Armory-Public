execute positioned as @n[type=marker,tag=ENTRY_POINT] run tp @s ~ ~ ~
execute at @s run function #toisarm:bullet/impact
function toisarm:util/kill/
kill @e[type=marker,tag=ENTRY_POINT]
