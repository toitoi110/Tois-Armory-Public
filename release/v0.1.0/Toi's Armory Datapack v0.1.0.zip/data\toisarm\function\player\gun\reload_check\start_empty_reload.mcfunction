    execute store result score @s toisarm.timer.reload run scoreboard players operation @s toisarm.timer.empty_reload = @s toisarm.state.empty_reload
    scoreboard players operation @s toisarm.timer.reload -= @s toisarm.state.bolt_action
    execute if score @s toisarm.state.prioritize_bolt_action matches 1 run scoreboard players operation @s toisarm.timer.bolt_action = @s toisarm.state.bolt_action
    scoreboard players add @s toisarm.timer.empty_reload 1
    execute if score @s toisarm.settings.reload_disable_ads matches 1 run tag @s remove toisarm.input.lclick
