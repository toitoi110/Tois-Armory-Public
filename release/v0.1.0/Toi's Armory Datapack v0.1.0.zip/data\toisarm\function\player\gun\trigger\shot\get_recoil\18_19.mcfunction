execute if score @s toisarm.recoil.pattern_index matches 18 run function toisarm:player/gun/trigger/shot/get_recoil/18
execute if score @s toisarm.recoil.pattern_index matches 19 run function toisarm:player/gun/trigger/shot/get_recoil/19
