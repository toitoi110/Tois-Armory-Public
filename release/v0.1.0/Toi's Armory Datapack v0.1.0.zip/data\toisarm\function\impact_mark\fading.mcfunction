scoreboard players operation @s toisarm.impact_mark.alpha *= 95 num
scoreboard players operation @s toisarm.impact_mark.alpha /= 100 num
execute if score @s toisarm.impact_mark.age matches 160.. run kill @s
